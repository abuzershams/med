import React from 'react';
import {
  Patient,
  Appointment,
  Consultation,
  Prescription,
  Invoice,
  Medicine,
  FollowUp,
} from '../../types';
import { WhatsAppButton } from '../common/WhatsAppButton';
import {
  Users,
  Calendar,
  Activity,
  DollarSign,
  AlertCircle,
  FileText,
  Clock,
  TrendingUp,
  Plus,
  ArrowUpRight,
  Stethoscope,
  ChevronRight,
  Package,
} from 'lucide-react';

interface DashboardViewProps {
  patients: Patient[];
  appointments: Appointment[];
  consultations: Consultation[];
  prescriptions: Prescription[];
  invoices: Invoice[];
  medicines: Medicine[];
  followUps: FollowUp[];
  onNavigateTab: (tab: string) => void;
  onQuickAction: (action: 'patient' | 'appointment' | 'consultation' | 'prescription' | 'invoice') => void;
  onStartConsultationForAppointment: (apt: Appointment) => void;
  onSelectPatient: (patient: Patient) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  patients,
  appointments,
  consultations,
  prescriptions,
  invoices,
  medicines,
  followUps,
  onNavigateTab,
  onQuickAction,
  onStartConsultationForAppointment,
  onSelectPatient,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];

  // Calculated real metrics
  const totalPatients = patients.length;
  const todayAppointments = appointments.filter((a) => a.date === todayStr);
  const todayConsultations = consultations.filter((c) => c.createdAt.startsWith(todayStr));

  // Revenue metrics
  const totalRevenue = invoices.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);
  const totalOutstanding = invoices.reduce((sum, inv) => sum + (inv.dueAmount || 0), 0);
  const pendingInvoicesCount = invoices.filter((inv) => inv.status !== 'paid').length;

  // Inventory & Follow-ups
  const lowStockMeds = medicines.filter((m) => m.currentStock <= m.minStockLevel);
  const upcomingFollowUps = followUps.filter((f) => f.status === 'scheduled').slice(0, 5);

  // 7-day appointments breakdown
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const dateKey = d.toISOString().split('T')[0];
    const label = d.toLocaleDateString('en-US', { weekday: 'short', month: 'numeric', day: 'numeric' });
    const count = appointments.filter((a) => a.date === dateKey).length;
    return { dateKey, label, count };
  });

  const max7DayCount = Math.max(...last7Days.map((d) => d.count), 1);

  // Invoice statuses
  const paidCount = invoices.filter((i) => i.status === 'paid').length;
  const partialCount = invoices.filter((i) => i.status === 'partial').length;
  const pendingCount = invoices.filter((i) => i.status === 'pending').length;
  const totalInvoices = invoices.length || 1;

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome & Quick Actions */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 rounded-2xl p-6 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-white/20 text-blue-100 uppercase tracking-wider">
            Today: {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </span>
          <h2 className="text-2xl font-bold tracking-tight mt-1">Clinical Operations Center</h2>
          <p className="text-xs text-blue-100 mt-0.5">
            Real-time status of patients, active consultation queues, digital Rx, and revenue.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => onQuickAction('patient')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white text-blue-700 hover:bg-blue-50 text-xs font-bold shadow transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Patient</span>
          </button>
          <button
            onClick={() => onQuickAction('appointment')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold backdrop-blur-sm border border-white/20 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Appointment</span>
          </button>
          <button
            onClick={() => onQuickAction('consultation')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-900 text-xs font-bold shadow transition"
          >
            <Stethoscope className="w-3.5 h-3.5" />
            <span>+ Start OPD</span>
          </button>
        </div>
      </div>

      {/* Key Stats Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Patients */}
        <div
          onClick={() => onNavigateTab('patients')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-blue-400 shadow-xs hover:shadow transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500">Total Patients</span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">{totalPatients}</span>
            <span className="text-xs text-emerald-600 font-semibold flex items-center">
              <TrendingUp className="w-3 h-3 mr-0.5" /> EMR Active
            </span>
          </div>
        </div>

        {/* Today's Appointments */}
        <div
          onClick={() => onNavigateTab('appointments')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-indigo-400 shadow-xs hover:shadow transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500">Today's Appointments</span>
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">{todayAppointments.length}</span>
            <span className="text-xs text-indigo-600 font-semibold">
              {todayConsultations.length} Consulted
            </span>
          </div>
        </div>

        {/* Revenue Collected */}
        <div
          onClick={() => onNavigateTab('billing')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-emerald-400 shadow-xs hover:shadow transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500">Revenue Collected</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              ${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
        </div>

        {/* Outstanding Dues */}
        <div
          onClick={() => onNavigateTab('billing')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-rose-400 shadow-xs hover:shadow transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500">Outstanding Dues</span>
            <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition">
              <AlertCircle className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              ${totalOutstanding.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-xs text-rose-600 font-semibold">
              {pendingInvoicesCount} Invoices
            </span>
          </div>
        </div>
      </div>

      {/* Analytics Charts & Graphs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Appointments 7-day Bar Trend */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Appointment Volume (Last 7 Days)</h3>
              <p className="text-xs text-slate-500">Daily appointment load distribution</p>
            </div>
            <button
              onClick={() => onNavigateTab('appointments')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Bar Chart Container */}
          <div className="h-44 flex items-end justify-between gap-2 pt-6 pb-2 border-b border-slate-100">
            {last7Days.map((day, idx) => {
              const heightPct = Math.max(12, Math.round((day.count / max7DayCount) * 100));
              const isToday = day.dateKey === todayStr;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group">
                  <span className="text-[10px] font-bold text-slate-600 mb-1 opacity-0 group-hover:opacity-100 transition">
                    {day.count}
                  </span>
                  <div
                    style={{ height: `${heightPct}%` }}
                    className={`w-full max-w-[42px] rounded-t-xl transition-all duration-300 ${
                      isToday
                        ? 'bg-gradient-to-t from-blue-700 to-cyan-500 shadow-sm'
                        : 'bg-blue-100 group-hover:bg-blue-300'
                    }`}
                  />
                  <span className={`text-[10px] mt-2 font-medium truncate max-w-[48px] ${isToday ? 'text-blue-700 font-bold' : 'text-slate-500'}`}>
                    {day.label}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="mt-3 flex items-center justify-between text-xs text-slate-500">
            <span>Peak load: {max7DayCount} patient(s)/day</span>
            <span className="text-emerald-600 font-medium">Synced with Firestore database</span>
          </div>
        </div>

        {/* Invoice & Payment Status Breakdown */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">Invoice Collection Breakdown</h3>
            <p className="text-xs text-slate-500 mb-4">Payment compliance status</p>

            <div className="space-y-3.5">
              {/* Paid */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-700 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    Paid Invoices
                  </span>
                  <span className="text-slate-900">
                    {paidCount} ({Math.round((paidCount / totalInvoices) * 100)}%)
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 rounded-full"
                    style={{ width: `${(paidCount / totalInvoices) * 100}%` }}
                  />
                </div>
              </div>

              {/* Partial */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-700 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                    Partially Paid
                  </span>
                  <span className="text-slate-900">
                    {partialCount} ({Math.round((partialCount / totalInvoices) * 100)}%)
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className="h-full bg-amber-500 rounded-full"
                    style={{ width: `${(partialCount / totalInvoices) * 100}%` }}
                  />
                </div>
              </div>

              {/* Pending */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-700 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                    Pending Dues
                  </span>
                  <span className="text-slate-900">
                    {pendingCount} ({Math.round((pendingCount / totalInvoices) * 100)}%)
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className="h-full bg-rose-500 rounded-full"
                    style={{ width: `${(pendingCount / totalInvoices) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Total Invoices: {invoices.length}</span>
            <button
              onClick={() => onNavigateTab('billing')}
              className="font-semibold text-blue-600 hover:text-blue-800"
            >
              Open Billing &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Two Column Section: Today's Schedule + Alerts/Follow-ups */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Today's Appointment Queue */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Today's Appointment Schedule</h3>
              <p className="text-xs text-slate-500">
                {todayAppointments.length} patients booked for today
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('appointments')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1"
            >
              <span>Manage Appointments</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {todayAppointments.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              <Calendar className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="font-medium text-slate-500">No appointments scheduled for today.</p>
              <button
                onClick={() => onQuickAction('appointment')}
                className="mt-3 px-3 py-1.5 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 font-semibold text-xs transition"
              >
                + Book Appointment
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {todayAppointments.map((apt) => (
                <div
                  key={apt.id}
                  className="p-3.5 rounded-xl border border-slate-100 hover:border-slate-300 bg-slate-50/50 hover:bg-white transition flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center shrink-0">
                      {apt.time}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-slate-900">{apt.patientName}</span>
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full capitalize ${
                          apt.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-700'
                            : apt.status === 'in_consultation'
                            ? 'bg-blue-100 text-blue-700'
                            : apt.status === 'waiting'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {apt.status.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Reason: {apt.reason} • Type: {apt.type} • Phone: {apt.patientPhone}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <WhatsAppButton
                      phone={apt.patientPhone}
                      patientName={apt.patientName}
                      messageType="appointment"
                      size="sm"
                    />
                    {apt.status !== 'completed' && (
                      <button
                        onClick={() => onStartConsultationForAppointment(apt)}
                        className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition flex items-center gap-1 shadow-xs"
                      >
                        <Stethoscope className="w-3.5 h-3.5" />
                        <span>Start OPD</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right 1 Col: Follow-ups & Low Stock Quick Alerts */}
        <div className="space-y-6">
          {/* Upcoming Follow-ups */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900">Upcoming Follow-ups</h3>
              <button
                onClick={() => onNavigateTab('followups')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800"
              >
                View ({followUps.length})
              </button>
            </div>

            {upcomingFollowUps.length === 0 ? (
              <div className="py-6 text-center text-slate-400 text-xs">
                No pending follow-ups scheduled.
              </div>
            ) : (
              <div className="space-y-2">
                {upcomingFollowUps.map((f) => (
                  <div
                    key={f.id}
                    className="p-2.5 rounded-xl border border-slate-100 bg-slate-50/60 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-semibold text-slate-800">{f.patientName}</p>
                      <p className="text-[10px] text-slate-500">Date: {f.scheduledDate} • {f.reason}</p>
                    </div>
                    <WhatsAppButton
                      phone={f.patientPhone}
                      patientName={f.patientName}
                      messageType="followup"
                      size="sm"
                    />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Low Stock Alert Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <Package className="w-4 h-4 text-amber-500" />
                <span>Low Stock Medicines</span>
              </h3>
              <button
                onClick={() => onNavigateTab('inventory')}
                className="text-xs font-semibold text-amber-600 hover:text-amber-800"
              >
                Reorder
              </button>
            </div>

            {lowStockMeds.length === 0 ? (
              <div className="py-6 text-center text-emerald-600 text-xs font-medium">
                ✓ All medicine inventory levels are adequate.
              </div>
            ) : (
              <div className="space-y-2">
                {lowStockMeds.slice(0, 4).map((med) => (
                  <div
                    key={med.id}
                    className="p-2.5 rounded-xl border border-amber-200/60 bg-amber-50/50 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-semibold text-slate-800">{med.name} ({med.strength})</p>
                      <p className="text-[10px] text-slate-500">Min: {med.minStockLevel} {med.form}s</p>
                    </div>
                    <span className="font-bold text-rose-600 bg-rose-100 px-2 py-0.5 rounded-full text-[11px]">
                      {med.currentStock} left
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
