import React, { useState } from 'react';
import { Medicine, StockMovement, Supplier } from '../../types';
import {
  Package,
  Plus,
  AlertTriangle,
  TrendingDown,
  TrendingUp,
  History,
  X,
  Search,
  CheckCircle2,
  Calendar,
  Save,
} from 'lucide-react';

interface InventoryViewProps {
  medicines: Medicine[];
  movements: StockMovement[];
  suppliers: Supplier[];
  userName: string;
  onAdjustStock: (
    medicineId: string,
    medicineName: string,
    type: 'in' | 'out' | 'adjustment',
    quantity: number,
    reason: string,
    performedBy: string,
    batchNumber?: string,
    expiryDate?: string
  ) => Promise<void>;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  medicines,
  movements,
  suppliers,
  userName,
  onAdjustStock,
}) => {
  const [activeTab, setActiveTab] = useState<'stock' | 'movements'>('stock');
  const [searchTerm, setSearchTerm] = useState('');
  const [onlyLowStock, setOnlyLowStock] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Stock Adjustment Form
  const [selectedMedId, setSelectedMedId] = useState('');
  const [movementType, setMovementType] = useState<'in' | 'out' | 'adjustment'>('in');
  const [quantity, setQuantity] = useState<number>(50);
  const [batchNumber, setBatchNumber] = useState('BAT-' + new Date().getFullYear() + '-01');
  const [expiryDate, setExpiryDate] = useState('2028-12-31');
  const [reason, setReason] = useState('Supplier stock replenishment');
  const [loading, setLoading] = useState(false);

  // Calculated Inventory Metrics
  const totalSKUs = medicines.length;
  const lowStockCount = medicines.filter((m) => m.currentStock <= m.minStockLevel && m.currentStock > 0).length;
  const outOfStockCount = medicines.filter((m) => m.currentStock === 0).length;
  const totalValuation = medicines.reduce((sum, m) => sum + m.currentStock * (m.purchasePrice || m.price * 0.6), 0);

  const filteredMedicines = medicines.filter((m) => {
    const matchTerm =
      m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.generic.toLowerCase().includes(searchTerm.toLowerCase());
    const matchLow = onlyLowStock ? m.currentStock <= m.minStockLevel : true;
    return matchTerm && matchLow;
  });

  const handleStockSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMedId) {
      alert('Please select a medicine.');
      return;
    }
    const med = medicines.find((m) => m.id === selectedMedId);
    if (!med) return;

    setLoading(true);
    try {
      await onAdjustStock(
        med.id,
        med.name,
        movementType,
        Number(quantity),
        reason.trim() || 'Inventory adjustment',
        userName,
        batchNumber.trim() || undefined,
        expiryDate || undefined
      );
      setIsModalOpen(false);
      setSelectedMedId('');
      setQuantity(50);
    } catch (err: any) {
      alert('Stock adjustment error: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Package className="w-5 h-5 text-indigo-600" />
            <span>Pharmacy Inventory & Stock Control</span>
          </h2>
          <p className="text-xs text-slate-500">
            Track batches, real-time dispensing movements, reorder alerts, and supplier replenishments
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs hover:shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>+ Inward Stock / Adjustment</span>
        </button>
      </div>

      {/* Metrics Banner */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold">Total Formulary SKUs</span>
          <p className="text-2xl font-extrabold text-slate-900 mt-1">{totalSKUs}</p>
          <span className="text-[11px] text-emerald-600 font-medium">All active lines</span>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold">Low Stock Warnings</span>
          <p className="text-2xl font-extrabold text-amber-600 mt-1">{lowStockCount}</p>
          <span className="text-[11px] text-amber-700 font-medium">Below threshold</span>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold">Out of Stock</span>
          <p className="text-2xl font-extrabold text-rose-600 mt-1">{outOfStockCount}</p>
          <span className="text-[11px] text-rose-700 font-medium">Zero inventory units</span>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold">Estimated Valuation</span>
          <p className="text-2xl font-extrabold text-slate-900 mt-1">
            ${totalValuation.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <span className="text-[11px] text-slate-500">Current cost valuation</span>
        </div>
      </div>

      {/* Tab Switcher & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="bg-slate-100 p-1 rounded-xl flex items-center gap-1 border border-slate-200 text-xs">
            <button
              onClick={() => setActiveTab('stock')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                activeTab === 'stock' ? 'bg-white text-indigo-700 shadow-2xs font-bold' : 'text-slate-600'
              }`}
            >
              Current On-Hand Stock ({medicines.length})
            </button>
            <button
              onClick={() => setActiveTab('movements')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                activeTab === 'movements' ? 'bg-white text-indigo-700 shadow-2xs font-bold' : 'text-slate-600'
              }`}
            >
              Stock Audit Logs ({movements.length})
            </button>
          </div>

          <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={onlyLowStock}
              onChange={(e) => setOnlyLowStock(e.target.checked)}
              className="rounded text-indigo-600 h-4 w-4"
            />
            <span>Show Low Stock Only</span>
          </label>
        </div>

        <div className="w-full md:w-64 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search medicine..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* TAB 1: CURRENT STOCK TABLE */}
      {activeTab === 'stock' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[11px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Medicine Item</th>
                  <th className="py-3 px-4">Form & Strength</th>
                  <th className="py-3 px-4">Stock on Hand</th>
                  <th className="py-3 px-4">Min Reorder Level</th>
                  <th className="py-3 px-4">Status Flag</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredMedicines.map((m) => {
                  const isLow = m.currentStock <= m.minStockLevel && m.currentStock > 0;
                  const isOut = m.currentStock === 0;

                  return (
                    <tr key={m.id} className="hover:bg-slate-50 transition">
                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-900 text-sm">{m.name}</span>
                        <span className="text-[11px] text-slate-400 block italic">{m.generic}</span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-slate-800">{m.form}</span>
                        <span className="text-[11px] text-slate-500 block">{m.strength}</span>
                      </td>

                      <td className="py-3.5 px-4 font-mono font-bold text-sm">
                        <span
                          className={
                            isOut
                              ? 'text-rose-600'
                              : isLow
                              ? 'text-amber-600'
                              : 'text-emerald-700'
                          }
                        >
                          {m.currentStock} {m.form}s
                        </span>
                      </td>

                      <td className="py-3.5 px-4 font-mono text-slate-600 font-semibold">
                        {m.minStockLevel} {m.form}s
                      </td>

                      <td className="py-3.5 px-4">
                        {isOut ? (
                          <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 font-bold text-[10px] uppercase">
                            Out of Stock
                          </span>
                        ) : isLow ? (
                          <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold text-[10px] uppercase flex items-center gap-1 w-max">
                            <AlertTriangle className="w-3 h-3 text-amber-600" />
                            Low Stock
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold text-[10px] uppercase">
                            Adequate
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => {
                            setSelectedMedId(m.id);
                            setMovementType('in');
                            setIsModalOpen(true);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold text-xs transition"
                        >
                          + Inward Stock
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: STOCK MOVEMENT LOGS */}
      {activeTab === 'movements' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          {movements.length === 0 ? (
            <div className="py-16 text-center text-slate-400 text-xs">
              <History className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="font-semibold text-slate-600 text-sm">No stock movement logs recorded yet</p>
              <p className="mt-1 text-slate-400">Add an inward stock shipment or adjustment to view audit history.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[11px] border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Date & Time</th>
                    <th className="py-3 px-4">Medicine Item</th>
                    <th className="py-3 px-4">Movement Type</th>
                    <th className="py-3 px-4">Quantity Changed</th>
                    <th className="py-3 px-4">Batch & Expiry</th>
                    <th className="py-3 px-4">Reason / Notes</th>
                    <th className="py-3 px-4">Logged By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {movements.map((mov) => (
                    <tr key={mov.id} className="hover:bg-slate-50 transition">
                      <td className="py-3.5 px-4 font-mono text-slate-600">
                        {mov.createdAt.replace('T', ' ').substring(0, 16)}
                      </td>

                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        {mov.medicineName}
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`font-bold px-2 py-0.5 rounded text-[11px] uppercase ${
                            mov.type === 'in'
                              ? 'bg-emerald-100 text-emerald-800'
                              : mov.type === 'out'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {mov.type === 'in' ? '↑ Inward' : mov.type === 'out' ? '↓ Dispensed' : '↕ Adjustment'}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 font-mono font-bold text-slate-800">
                        {mov.type === 'in' ? '+' : mov.type === 'out' ? '-' : ''}
                        {mov.quantity} units
                      </td>

                      <td className="py-3.5 px-4 font-mono text-[11px] text-slate-600">
                        {mov.batchNumber || 'N/A'} {mov.expiryDate ? `(Exp: ${mov.expiryDate})` : ''}
                      </td>

                      <td className="py-3.5 px-4 text-slate-700">
                        {mov.reason}
                      </td>

                      <td className="py-3.5 px-4 text-slate-500 font-medium">
                        {mov.performedBy}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* MODAL: STOCK ADJUSTMENT / INWARD ENTRY */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-sm text-slate-900">Log Stock Movement / Purchase</h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleStockSubmit} className="p-6 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Select Medicine <span className="text-rose-500">*</span>
                </label>
                <select
                  required
                  value={selectedMedId}
                  onChange={(e) => setSelectedMedId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                >
                  <option value="">-- Choose Medicine --</option>
                  {medicines.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.strength}) - Current Stock: {m.currentStock} {m.form}s
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Movement Type</label>
                  <select
                    value={movementType}
                    onChange={(e) => setMovementType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white font-semibold"
                  >
                    <option value="in">Inward / Received (+)</option>
                    <option value="out">Dispensed / Reduced (-)</option>
                    <option value="adjustment">Stock Count Audit (=)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Quantity Units</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={quantity}
                    onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-indigo-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Batch Number</label>
                  <input
                    type="text"
                    value={batchNumber}
                    onChange={(e) => setBatchNumber(e.target.value)}
                    placeholder="e.g. B-2026-X"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Expiry Date</label>
                  <input
                    type="date"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Reason / Purchase Note</label>
                <input
                  type="text"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="e.g. Monthly order from Medico Supplier Ltd."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{loading ? 'Updating...' : 'Post Stock Entry'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
