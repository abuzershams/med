import React, { useState } from 'react';
import { Medicine, MedicineForm } from '../../types';
import { addMedicine, updateMedicine, deleteMedicine } from '../../services/db';
import { DeleteMedicineModal } from './DeleteMedicineModal';
import {
  Pill,
  Plus,
  Search,
  Filter,
  Star,
  Edit2,
  Trash2,
  AlertTriangle,
  X,
  Save,
  CheckCircle2,
} from 'lucide-react';

interface MedicinesViewProps {
  medicines: Medicine[];
  onAddMedicine?: (data: Omit<Medicine, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Medicine>;
  onUpdateMedicine?: (id: string, updates: Partial<Medicine>) => Promise<void>;
  onDeleteMedicine?: (id: string) => Promise<any>;
}

export const MedicinesView: React.FC<MedicinesViewProps> = ({
  medicines,
  onAddMedicine = addMedicine,
  onUpdateMedicine = updateMedicine,
  onDeleteMedicine = deleteMedicine,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [formFilter, setFormFilter] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMed, setEditingMed] = useState<Medicine | null>(null);

  // Delete modal state
  const [medToDelete, setMedToDelete] = useState<Medicine | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<'success' | 'error'>('success');

  // Form states
  const [name, setName] = useState('');
  const [generic, setGeneric] = useState('');
  const [strength, setStrength] = useState('500 mg');
  const [form, setForm] = useState<MedicineForm>('Tablet');
  const [defaultDosage, setDefaultDosage] = useState('1 Tablet');
  const [defaultFrequency, setDefaultFrequency] = useState('1-0-1');
  const [defaultDuration, setDefaultDuration] = useState('5 Days');
  const [foodInstruction, setFoodInstruction] = useState('After Food');
  const [instructions, setInstructions] = useState('');
  const [currentStock, setCurrentStock] = useState<number>(100);
  const [minStockLevel, setMinStockLevel] = useState<number>(20);
  const [price, setPrice] = useState<number>(10.0);
  const [purchasePrice, setPurchasePrice] = useState<number>(5.0);
  const [isFavorite, setIsFavorite] = useState(false);
  const [loading, setLoading] = useState(false);

  const openAddModal = () => {
    setEditingMed(null);
    setName('');
    setGeneric('');
    setStrength('500 mg');
    setForm('Tablet');
    setDefaultDosage('1 Tablet');
    setDefaultFrequency('1-0-1');
    setDefaultDuration('5 Days');
    setFoodInstruction('After Food');
    setInstructions('');
    setCurrentStock(100);
    setMinStockLevel(20);
    setPrice(10.0);
    setPurchasePrice(5.0);
    setIsFavorite(false);
    setIsModalOpen(true);
  };

  const openEditModal = (med: Medicine) => {
    setEditingMed(med);
    setName(med.name);
    setGeneric(med.generic);
    setStrength(med.strength);
    setForm(med.form);
    setDefaultDosage(med.defaultDosage);
    setDefaultFrequency(med.defaultFrequency);
    setDefaultDuration(med.defaultDuration);
    setFoodInstruction(med.foodInstruction);
    setInstructions(med.instructions || '');
    setCurrentStock(med.currentStock);
    setMinStockLevel(med.minStockLevel);
    setPrice(med.price);
    setPurchasePrice(med.purchasePrice || 0);
    setIsFavorite(med.isFavorite || false);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setLoading(true);
    try {
      if (editingMed) {
        await onUpdateMedicine(editingMed.id, {
          name: name.trim(),
          generic: generic.trim(),
          strength: strength.trim(),
          form,
          defaultDosage: defaultDosage.trim(),
          defaultFrequency: defaultFrequency.trim(),
          defaultDuration: defaultDuration.trim(),
          foodInstruction,
          instructions: instructions.trim() || undefined,
          currentStock: Number(currentStock) || 0,
          minStockLevel: Number(minStockLevel) || 10,
          price: Number(price) || 0,
          purchasePrice: Number(purchasePrice) || 0,
          isFavorite,
        });
      } else {
        await onAddMedicine({
          name: name.trim(),
          generic: generic.trim(),
          strength: strength.trim(),
          form,
          defaultDosage: defaultDosage.trim(),
          defaultFrequency: defaultFrequency.trim(),
          defaultDuration: defaultDuration.trim(),
          foodInstruction,
          instructions: instructions.trim() || undefined,
          currentStock: Number(currentStock) || 0,
          minStockLevel: Number(minStockLevel) || 10,
          price: Number(price) || 0,
          purchasePrice: Number(purchasePrice) || 0,
          status: 'active',
          isFavorite,
        });
      }
      setIsModalOpen(false);
    } catch (err: any) {
      alert('Error saving medicine: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const filteredMedicines = medicines.filter((m) => {
    const term = searchTerm.toLowerCase();
    const matchSearch =
      m.name.toLowerCase().includes(term) ||
      m.generic.toLowerCase().includes(term) ||
      m.strength.toLowerCase().includes(term);
    const matchForm = formFilter === 'all' || m.form === formFilter;
    return matchSearch && matchForm;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Pill className="w-5 h-5 text-blue-600" />
            <span>Medicine Master Catalog</span>
          </h2>
          <p className="text-xs text-slate-500">
            {medicines.length} formulations configured with default dosages for fast prescription writing
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs hover:shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>+ Add Medicine</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by brand name, generic composition, strength..."
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <select
          value={formFilter}
          onChange={(e) => setFormFilter(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="all">All Dosage Forms</option>
          <option value="Tablet">Tablet</option>
          <option value="Capsule">Capsule</option>
          <option value="Syrup">Syrup</option>
          <option value="Injection">Injection</option>
          <option value="Drops">Drops</option>
          <option value="Cream">Cream / Ointment</option>
          <option value="Inhaler">Inhaler</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredMedicines.length === 0 ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            <Pill className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="font-semibold text-slate-600 text-sm">No medicines found</p>
            <p className="mt-1 text-slate-400">Click "+ Add Medicine" to expand the clinic formulary.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[11px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Medicine Name</th>
                  <th className="py-3 px-4">Generic Composition</th>
                  <th className="py-3 px-4">Form & Strength</th>
                  <th className="py-3 px-4">Default Posology</th>
                  <th className="py-3 px-4">Stock Level</th>
                  <th className="py-3 px-4">Retail Price</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredMedicines.map((m) => {
                  const isLow = m.currentStock <= m.minStockLevel;
                  return (
                    <tr key={m.id} className="hover:bg-slate-50 transition">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          {m.isFavorite && (
                            <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500 shrink-0" />
                          )}
                          <span className="font-bold text-slate-900 text-sm">{m.name}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-slate-600 italic">
                        {m.generic || 'N/A'}
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-slate-800">{m.form}</span>
                        <span className="text-[11px] text-slate-500 block">{m.strength}</span>
                      </td>

                      <td className="py-3.5 px-4 text-slate-700">
                        <span className="font-semibold text-blue-700">{m.defaultDosage}</span> • {m.defaultFrequency}
                        <span className="text-[10px] text-slate-400 block">{m.foodInstruction}</span>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`font-mono font-bold px-2 py-0.5 rounded text-[11px] ${
                              isLow ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {m.currentStock} {m.form}s
                          </span>
                          {isLow && (
                            <span title="Low stock warning">
                              <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        ${m.price.toFixed(2)}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => openEditModal(m)}
                            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                            title="Edit Medicine"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setMedToDelete(m)}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 transition cursor-pointer"
                            title="Remove or Archive Medicine"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Delete / Archive Confirmation Modal */}
      <DeleteMedicineModal
        isOpen={!!medToDelete}
        onClose={() => setMedToDelete(null)}
        medicine={medToDelete}
        isLoading={isDeleting}
        onConfirm={async () => {
          if (!medToDelete) return;
          setIsDeleting(true);
          try {
            const res = await onDeleteMedicine(medToDelete.id);
            setToastType('success');
            if (res && res.archived) {
              setToastMessage(`${medToDelete.name} was safely archived to preserve clinical prescription history.`);
            } else {
              setToastMessage(`${medToDelete.name} deleted successfully.`);
            }
            setMedToDelete(null);
            setTimeout(() => setToastMessage(null), 4000);
          } catch (err: any) {
            setToastType('error');
            setToastMessage(`Failed to delete medicine: ${err.message || 'Database error'}`);
          } finally {
            setIsDeleting(false);
          }
        }}
      />

      {/* Floating Status Notification Toast */}
      {toastMessage && (
        <div
          className={`fixed bottom-6 right-6 z-50 px-4 py-3 rounded-xl shadow-lg border flex items-center gap-2.5 text-xs font-semibold animate-in fade-in slide-in-from-bottom-3 duration-200 ${
            toastType === 'success'
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
              : 'bg-rose-50 text-rose-800 border-rose-200'
          }`}
        >
          {toastType === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span>{toastMessage}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="ml-2 text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* ADD / EDIT MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Pill className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-sm text-slate-900">
                  {editingMed ? 'Edit Medicine Formulation' : 'Add Medicine to Formulary Master'}
                </h3>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Medicine Brand Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Paracetamol"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Generic / Chemical Composition
                  </label>
                  <input
                    type="text"
                    value={generic}
                    onChange={(e) => setGeneric(e.target.value)}
                    placeholder="e.g. Acetaminophen"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Strength</label>
                  <input
                    type="text"
                    value={strength}
                    onChange={(e) => setStrength(e.target.value)}
                    placeholder="e.g. 500 mg, 10 ml"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Dosage Form</label>
                  <select
                    value={form}
                    onChange={(e) => setForm(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                  >
                    <option value="Tablet">Tablet</option>
                    <option value="Capsule">Capsule</option>
                    <option value="Syrup">Syrup</option>
                    <option value="Injection">Injection</option>
                    <option value="Drops">Drops</option>
                    <option value="Cream">Cream</option>
                    <option value="Ointment">Ointment</option>
                    <option value="Inhaler">Inhaler</option>
                    <option value="Powder">Powder</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              {/* Default Prescription Settings */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <span className="font-bold text-[11px] text-slate-700 uppercase tracking-wide block">
                  Default Prescription Presets (Auto-fills on Rx)
                </span>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] text-slate-500">Dosage</label>
                    <input
                      type="text"
                      value={defaultDosage}
                      onChange={(e) => setDefaultDosage(e.target.value)}
                      placeholder="1 Tablet"
                      className="w-full px-2 py-1 rounded border border-slate-200 text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500">Frequency</label>
                    <input
                      type="text"
                      value={defaultFrequency}
                      onChange={(e) => setDefaultFrequency(e.target.value)}
                      placeholder="1-0-1"
                      className="w-full px-2 py-1 rounded border border-slate-200 text-xs bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500">Food Instruction</label>
                    <select
                      value={foodInstruction}
                      onChange={(e) => setFoodInstruction(e.target.value)}
                      className="w-full px-2 py-1 rounded border border-slate-200 text-xs bg-white"
                    >
                      <option value="After Food">After Food</option>
                      <option value="Before Food">Before Food</option>
                      <option value="With Meals">With Meals</option>
                      <option value="At Bedtime">At Bedtime</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Stock and Pricing */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Current Stock</label>
                  <input
                    type="number"
                    value={currentStock}
                    onChange={(e) => setCurrentStock(parseInt(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Min Alert Stock</label>
                  <input
                    type="number"
                    value={minStockLevel}
                    onChange={(e) => setMinStockLevel(parseInt(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-bold text-amber-700"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Selling Price ($)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={price}
                    onChange={(e) => setPrice(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs font-bold text-emerald-700"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Purchase Price ($)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={purchasePrice}
                    onChange={(e) => setPurchasePrice(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <input
                  type="checkbox"
                  id="favMed"
                  checked={isFavorite}
                  onChange={(e) => setIsFavorite(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4"
                />
                <label htmlFor="favMed" className="text-slate-700 font-semibold cursor-pointer select-none">
                  Mark as Favorite / Frequently Prescribed
                </label>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{loading ? 'Saving...' : editingMed ? 'Update Medicine' : 'Save Medicine'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
