import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  limit,
} from '../local/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  Clinic,
  UserStaff,
  Patient,
  Appointment,
  Vital,
  Consultation,
  Prescription,
  Medicine,
  StockMovement,
  Supplier,
  Invoice,
  Payment,
  MedicalDocument,
  FollowUp,
  AuditLog,
} from '../types';

// ==================== HASHING UTILITY ====================
export async function hashPassword(password: string): Promise<string> {
  const msgUint8 = new TextEncoder().encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
  const computed = await hashPassword(password);
  return computed === storedHash;
}

// ==================== FIRESTORE DATA SANITIZATION ====================
export function cleanForFirestore<T>(data: T): T {
  if (data === null || data === undefined) {
    return data;
  }
  if (Array.isArray(data)) {
    return data
      .filter((item) => item !== undefined)
      .map((item) => (typeof item === 'object' && item !== null ? cleanForFirestore(item) : item)) as unknown as T;
  }
  if (typeof data === 'object' && !(data instanceof Date)) {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(data)) {
      if (value !== undefined) {
        cleaned[key] = typeof value === 'object' && value !== null ? cleanForFirestore(value) : value;
      }
    }
    return cleaned as T;
  }
  return data;
}

// ==================== AUDIT LOGS ====================
export async function recordAudit(
  action: string,
  details: string,
  performedBy: string,
  userRole: string,
  entityType?: string,
  entityId?: string
) {
  try {
    const id = 'LOG-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
    const logData = cleanForFirestore({
      id,
      action,
      details,
      performedBy,
      userRole,
      timestamp: new Date().toISOString(),
      entityType,
      entityId,
    }) as AuditLog;
    await setDoc(doc(db, 'audit_logs', id), logData);
  } catch (err) {
    console.error('Failed to write audit log:', err);
  }
}

// ==================== CLINIC & INITIAL SETUP ====================
export async function getClinicInfo(): Promise<Clinic | null> {
  const path = 'clinics/main_clinic';
  try {
    const snap = await getDoc(doc(db, 'clinics', 'main_clinic'));
    if (snap.exists()) {
      return snap.data() as Clinic;
    }
    // Check if any clinic doc exists
    const qSnap = await getDocs(collection(db, 'clinics'));
    if (!qSnap.empty) {
      return qSnap.docs[0].data() as Clinic;
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function saveClinicInfo(clinicData: Partial<Clinic>): Promise<Clinic> {
  const path = 'clinics/main_clinic';
  try {
    const existing = await getDoc(doc(db, 'clinics', 'main_clinic'));
    const now = new Date().toISOString();
    const finalData: Clinic = {
      id: 'main_clinic',
      name: clinicData.name || 'Medical Clinic',
      doctorName: clinicData.doctorName || 'Dr. Doctor',
      qualification: clinicData.qualification || 'MBBS, MD',
      registrationNumber: clinicData.registrationNumber || 'REG-123456',
      phone: clinicData.phone || '',
      whatsapp: clinicData.whatsapp || clinicData.phone || '',
      email: clinicData.email || '',
      address: clinicData.address || '',
      workingHours: clinicData.workingHours || 'Mon-Sat: 09:00 AM - 08:00 PM',
      logoUrl: clinicData.logoUrl || '',
      setupCompleted: true,
      createdAt: existing.exists() ? (existing.data() as Clinic).createdAt : now,
      updatedAt: now,
      ...clinicData,
    };
    await setDoc(doc(db, 'clinics', 'main_clinic'), cleanForFirestore(finalData));
    return finalData;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function updatePrintingSettings(settings: {
  autoPrintOnSave: boolean;
  autoPrintPrescription?: boolean;
  autoPrintInvoice?: boolean;
}): Promise<Clinic> {
  const path = 'clinics/main_clinic';
  try {
    const existingSnap = await getDoc(doc(db, 'clinics', 'main_clinic'));
    const existing = existingSnap.exists() ? (existingSnap.data() as Clinic) : ({} as Partial<Clinic>);
    const now = new Date().toISOString();
    const updated: Clinic = {
      id: 'main_clinic',
      name: existing.name || 'Medical Clinic',
      doctorName: existing.doctorName || 'Dr. Doctor',
      qualification: existing.qualification || 'MBBS, MD',
      registrationNumber: existing.registrationNumber || 'REG-123456',
      phone: existing.phone || '',
      whatsapp: existing.whatsapp || '',
      email: existing.email || '',
      address: existing.address || '',
      workingHours: existing.workingHours || 'Mon-Sat: 09:00 AM - 08:00 PM',
      logoUrl: existing.logoUrl || '',
      setupCompleted: true,
      createdAt: existing.createdAt || now,
      updatedAt: now,
      ...existing,
      autoPrintOnSave: settings.autoPrintOnSave,
      autoPrintPrescription: settings.autoPrintPrescription ?? settings.autoPrintOnSave,
      autoPrintInvoice: settings.autoPrintInvoice ?? settings.autoPrintOnSave,
    };
    await setDoc(doc(db, 'clinics', 'main_clinic'), cleanForFirestore(updated));
    return updated;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function hasAdminAccount(): Promise<boolean> {
  const path = 'staff';
  try {
    const q = query(collection(db, 'staff'), where('role', '==', 'admin'));
    const snap = await getDocs(q);
    return !snap.empty;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

// ==================== USER / STAFF AUTH ====================
export async function getStaffByUsername(username: string): Promise<UserStaff | null> {
  const path = 'staff';
  try {
    const q = query(collection(db, 'staff'), where('username', '==', username.trim().toLowerCase()));
    const snap = await getDocs(q);
    if (snap.empty) return null;
    return snap.docs[0].data() as UserStaff;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function getAllStaff(): Promise<UserStaff[]> {
  const path = 'staff';
  try {
    const snap = await getDocs(collection(db, 'staff'));
    return snap.docs.map((d) => d.data() as UserStaff);
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

export async function createStaffUser(
  user: Omit<UserStaff, 'id' | 'createdAt'>
): Promise<UserStaff> {
  const path = 'staff';
  try {
    const id = 'STF-' + Date.now();
    const newUser: UserStaff = {
      ...user,
      id,
      username: user.username.trim().toLowerCase(),
      createdAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'staff', id), cleanForFirestore(newUser));
    return newUser;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updateStaffUser(id: string, updates: Partial<UserStaff>): Promise<void> {
  const path = `staff/${id}`;
  try {
    await updateDoc(doc(db, 'staff', id), cleanForFirestore(updates));
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deleteStaffUser(id: string): Promise<void> {
  const path = `staff/${id}`;
  try {
    await deleteDoc(doc(db, 'staff', id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// ==================== SEED ESSENTIAL STARTER MEDICINES ====================
export async function seedStarterMedicinesIfEmpty() {
  try {
    const snap = await getDocs(collection(db, 'medicines'));
    if (!snap.empty) return;

    const defaults: Omit<Medicine, 'id' | 'createdAt' | 'updatedAt'>[] = [
      {
        name: 'Paracetamol',
        generic: 'Acetaminophen',
        strength: '500 mg',
        form: 'Tablet',
        defaultDosage: '1 Tablet',
        defaultFrequency: '1-0-1',
        defaultDuration: '3 Days',
        foodInstruction: 'After Food',
        instructions: 'Take for fever and mild pain',
        currentStock: 150,
        minStockLevel: 30,
        price: 5.0,
        purchasePrice: 2.5,
        status: 'active',
        isFavorite: true,
      },
      {
        name: 'Amoxicillin + Clavulanate',
        generic: 'Amoxicillin / Clavulanic Acid',
        strength: '625 mg',
        form: 'Tablet',
        defaultDosage: '1 Tablet',
        defaultFrequency: '1-0-1',
        defaultDuration: '5 Days',
        foodInstruction: 'After Food',
        instructions: 'Complete antibiotic course',
        currentStock: 80,
        minStockLevel: 20,
        price: 22.0,
        purchasePrice: 14.0,
        status: 'active',
        isFavorite: true,
      },
      {
        name: 'Cetirizine',
        generic: 'Cetirizine Hydrochloride',
        strength: '10 mg',
        form: 'Tablet',
        defaultDosage: '1 Tablet',
        defaultFrequency: '0-0-1',
        defaultDuration: '5 Days',
        foodInstruction: 'At Bedtime',
        instructions: 'May cause mild drowsiness',
        currentStock: 120,
        minStockLevel: 25,
        price: 4.5,
        purchasePrice: 1.8,
        status: 'active',
        isFavorite: true,
      },
      {
        name: 'Pantoprazole',
        generic: 'Pantoprazole Sodium',
        strength: '40 mg',
        form: 'Tablet',
        defaultDosage: '1 Tablet',
        defaultFrequency: '1-0-0',
        defaultDuration: '7 Days',
        foodInstruction: 'Before Breakfast',
        instructions: 'Take on an empty stomach in the morning',
        currentStock: 95,
        minStockLevel: 25,
        price: 12.0,
        purchasePrice: 6.5,
        status: 'active',
        isFavorite: true,
      },
      {
        name: 'Azithromycin',
        generic: 'Azithromycin Dihydrate',
        strength: '500 mg',
        form: 'Tablet',
        defaultDosage: '1 Tablet',
        defaultFrequency: '1-0-0',
        defaultDuration: '3 Days',
        foodInstruction: '1 Hour Before Food',
        instructions: 'Take at the same time daily',
        currentStock: 60,
        minStockLevel: 15,
        price: 28.0,
        purchasePrice: 17.5,
        status: 'active',
        isFavorite: true,
      },
      {
        name: 'Metformin',
        generic: 'Metformin Hydrochloride',
        strength: '500 mg',
        form: 'Tablet',
        defaultDosage: '1 Tablet',
        defaultFrequency: '1-0-1',
        defaultDuration: '30 Days',
        foodInstruction: 'With Meals',
        instructions: 'For glycemic control',
        currentStock: 200,
        minStockLevel: 50,
        price: 8.0,
        purchasePrice: 4.0,
        status: 'active',
        isFavorite: true,
      },
      {
        name: 'Cough Relief Syrup',
        generic: 'Dextromethorphan + Chlorpheniramine',
        strength: '100 ml',
        form: 'Syrup',
        defaultDosage: '10 ml',
        defaultFrequency: 'Three times daily',
        defaultDuration: '5 Days',
        foodInstruction: 'After Food',
        instructions: 'Shake well before use',
        currentStock: 45,
        minStockLevel: 15,
        price: 85.0,
        purchasePrice: 52.0,
        status: 'active',
        isFavorite: true,
      },
    ];

    const now = new Date().toISOString();
    for (let i = 0; i < defaults.length; i++) {
      const id = 'MED-' + (1001 + i);
      await setDoc(doc(db, 'medicines', id), cleanForFirestore({
        ...defaults[i],
        id,
        createdAt: now,
        updatedAt: now,
      }));
    }
  } catch (err) {
    console.warn('Could not seed starter medicines:', err);
  }
}

// ==================== PATIENTS CRUD ====================
export function subscribePatients(callback: (patients: Patient[]) => void) {
  const path = 'patients';
  const q = query(collection(db, path), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs
        .map((d) => d.data() as Patient)
        .filter((p) => !p.isArchived);
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function addPatient(patient: Omit<Patient, 'id' | 'patientId' | 'createdAt' | 'updatedAt'>): Promise<Patient> {
  const path = 'patients';
  try {
    const snap = await getDocs(collection(db, 'patients'));
    const nextSeq = snap.size + 1001;
    const patientId = `PAT-${nextSeq}`;
    const id = 'P-' + Date.now();
    const now = new Date().toISOString();

    const newPatient: Patient = {
      ...patient,
      id,
      patientId,
      createdAt: now,
      updatedAt: now,
    };
    await setDoc(doc(db, 'patients', id), cleanForFirestore(newPatient));
    return newPatient;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updatePatient(id: string, updates: Partial<Patient>): Promise<void> {
  const path = `patients/${id}`;
  try {
    await updateDoc(doc(db, 'patients', id), cleanForFirestore({
      ...updates,
      updatedAt: new Date().toISOString(),
    }));
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function checkPatientClinicalHistory(patientId: string): Promise<number> {
  try {
    let count = 0;
    // Check appointments, consultations, vitals, prescriptions, invoices
    const collectionsToCheck = ['appointments', 'consultations', 'vitals', 'prescriptions', 'invoices'];
    for (const colName of collectionsToCheck) {
      const q = query(collection(db, colName), where('patientId', '==', patientId));
      const snap = await getDocs(q);
      count += snap.size;
    }
    return count;
  } catch (err) {
    console.warn('Could not check clinical history:', err);
    return 0;
  }
}

export async function deletePatient(id: string): Promise<void> {
  const path = `patients/${id}`;
  try {
    // Medical Record Safety: Check if patient has any clinical records
    const historyCount = await checkPatientClinicalHistory(id);
    if (historyCount > 0) {
      // Safe Archive strategy: Retain historical medical integrity while removing patient from active registry
      await updateDoc(doc(db, 'patients', id), cleanForFirestore({
        isArchived: true,
        archivedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }));
    } else {
      // No medical history exists: Permanent clean deletion is safe
      await deleteDoc(doc(db, 'patients', id));
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// ==================== APPOINTMENTS CRUD ====================
export function subscribeAppointments(callback: (appointments: Appointment[]) => void) {
  const path = 'appointments';
  const q = query(collection(db, path), orderBy('date', 'desc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as Appointment);
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function addAppointment(
  data: Omit<Appointment, 'id' | 'createdAt' | 'updatedAt'>
): Promise<Appointment> {
  const path = 'appointments';
  try {
    const id = 'APT-' + Date.now();
    const now = new Date().toISOString();
    const apt: Appointment = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    await setDoc(doc(db, 'appointments', id), cleanForFirestore(apt));
    return apt;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updateAppointment(id: string, updates: Partial<Appointment>): Promise<void> {
  const path = `appointments/${id}`;
  try {
    await updateDoc(doc(db, 'appointments', id), cleanForFirestore({
      ...updates,
      updatedAt: new Date().toISOString(),
    }));
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deleteAppointment(id: string): Promise<void> {
  const path = `appointments/${id}`;
  try {
    await deleteDoc(doc(db, 'appointments', id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// ==================== VITALS CRUD ====================
export function subscribeVitals(callback: (vitals: Vital[]) => void) {
  const path = 'vitals';
  const q = query(collection(db, path), orderBy('recordedAt', 'desc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as Vital);
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function addVital(data: Omit<Vital, 'id' | 'createdAt'>): Promise<Vital> {
  const path = 'vitals';
  try {
    const id = 'VIT-' + Date.now();
    // Auto calculate BMI if height and weight exist
    let bmi = data.bmi;
    if (!bmi && data.weight && data.height) {
      const heightInM = data.height / 100;
      bmi = parseFloat((data.weight / (heightInM * heightInM)).toFixed(1));
    }
    const vital: Vital = {
      ...data,
      bmi,
      id,
      createdAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'vitals', id), cleanForFirestore(vital));
    return vital;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

// ==================== CONSULTATIONS CRUD ====================
export function subscribeConsultations(callback: (consultations: Consultation[]) => void) {
  const path = 'consultations';
  const q = query(collection(db, path), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as Consultation);
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function addConsultation(
  data: Omit<Consultation, 'id' | 'createdAt' | 'updatedAt'>
): Promise<Consultation> {
  const path = 'consultations';
  try {
    const id = 'CON-' + Date.now();
    const now = new Date().toISOString();
    const con: Consultation = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    await setDoc(doc(db, 'consultations', id), cleanForFirestore(con));
    return con;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

// ==================== PRESCRIPTIONS CRUD ====================
export function subscribePrescriptions(callback: (prescriptions: Prescription[]) => void) {
  const path = 'prescriptions';
  const q = query(collection(db, path), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs
        .map((d) => d.data() as Prescription)
        .filter((rx) => !rx.isArchived && rx.status !== 'void');
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function addPrescription(
  data: Omit<Prescription, 'id' | 'prescriptionNumber' | 'createdAt'>
): Promise<Prescription> {
  const path = 'prescriptions';
  try {
    const snap = await getDocs(collection(db, 'prescriptions'));
    const rxSeq = 1000 + snap.size + 1;
    const year = new Date().getFullYear();
    const prescriptionNumber = `RX-${year}-${rxSeq}`;
    const id = 'RX-' + Date.now();
    const rx: Prescription = {
      ...data,
      id,
      prescriptionNumber,
      status: 'active',
      isArchived: false,
      createdAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'prescriptions', id), cleanForFirestore(rx));
    return rx;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updatePrescription(
  id: string,
  updates: Partial<Prescription>
): Promise<void> {
  const path = `prescriptions/${id}`;
  try {
    await updateDoc(doc(db, 'prescriptions', id), cleanForFirestore({
      ...updates,
      updatedAt: new Date().toISOString(),
    }));
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function voidPrescription(
  id: string,
  reason: string = 'Voided by attending doctor'
): Promise<void> {
  const path = `prescriptions/${id}`;
  try {
    await updateDoc(doc(db, 'prescriptions', id), cleanForFirestore({
      status: 'void',
      isArchived: true,
      archivedAt: new Date().toISOString(),
      advice: `[VOIDED: ${reason}]`,
      updatedAt: new Date().toISOString(),
    }));
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

// ==================== MEDICINES & INVENTORY ====================
export function subscribeMedicines(callback: (medicines: Medicine[]) => void) {
  const path = 'medicines';
  const q = query(collection(db, path), orderBy('name', 'asc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs
        .map((d) => d.data() as Medicine)
        .filter((m) => !m.isArchived && m.status !== 'archived');
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function addMedicine(
  data: Omit<Medicine, 'id' | 'createdAt' | 'updatedAt'>
): Promise<Medicine> {
  const path = 'medicines';
  try {
    const id = 'MED-' + Date.now();
    const now = new Date().toISOString();
    const med: Medicine = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    await setDoc(doc(db, 'medicines', id), cleanForFirestore(med));
    return med;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updateMedicine(id: string, updates: Partial<Medicine>): Promise<void> {
  const path = `medicines/${id}`;
  try {
    await updateDoc(doc(db, 'medicines', id), cleanForFirestore({
      ...updates,
      updatedAt: new Date().toISOString(),
    }));
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deleteMedicine(id: string): Promise<{ archived: boolean }> {
  const path = `medicines/${id}`;
  try {
    // Check if any prescriptions reference this medicine
    const rxSnap = await getDocs(collection(db, 'prescriptions'));
    const isReferencedInRx = rxSnap.docs.some((d) => {
      const rx = d.data() as Prescription;
      return rx.medicines && rx.medicines.some((m) => m.medicineId === id);
    });

    if (isReferencedInRx) {
      // Soft-archive medicine to preserve historical prescriptions and dispensing logs
      await updateDoc(doc(db, 'medicines', id), cleanForFirestore({
        status: 'archived',
        isArchived: true,
        archivedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }));
      return { archived: true };
    }

    // Permanent delete if no clinical references exist
    await deleteDoc(doc(db, 'medicines', id));
    return { archived: false };
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function adjustMedicineStock(
  medicineId: string,
  medicineName: string,
  type: 'in' | 'out' | 'adjustment',
  quantity: number,
  reason: string,
  performedBy: string,
  batchNumber?: string,
  expiryDate?: string
): Promise<void> {
  const path = 'stock_movements';
  try {
    // 1. Get current stock
    const medRef = doc(db, 'medicines', medicineId);
    const medSnap = await getDoc(medRef);
    if (!medSnap.exists()) throw new Error('Medicine not found');
    const medData = medSnap.data() as Medicine;
    let newStock = medData.currentStock;
    if (type === 'in') {
      newStock += quantity;
    } else if (type === 'out') {
      newStock = Math.max(0, newStock - quantity);
    } else {
      newStock = quantity;
    }

    await updateDoc(medRef, cleanForFirestore({
      currentStock: newStock,
      updatedAt: new Date().toISOString(),
    }));

    // 2. Log movement
    const movementId = 'MOV-' + Date.now();
    const movement: StockMovement = {
      id: movementId,
      medicineId,
      medicineName,
      type,
      quantity,
      batchNumber,
      expiryDate,
      reason,
      performedBy,
      createdAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'stock_movements', movementId), cleanForFirestore(movement));
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export function subscribeStockMovements(callback: (movements: StockMovement[]) => void) {
  const path = 'stock_movements';
  const q = query(collection(db, path), orderBy('createdAt', 'desc'), limit(100));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as StockMovement);
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

// ==================== SUPPLIERS ====================
export function subscribeSuppliers(callback: (suppliers: Supplier[]) => void) {
  const path = 'suppliers';
  const q = query(collection(db, path), orderBy('name', 'asc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as Supplier);
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function addSupplier(data: Omit<Supplier, 'id' | 'createdAt' | 'updatedAt'>): Promise<Supplier> {
  const path = 'suppliers';
  try {
    const id = 'SUP-' + Date.now();
    const now = new Date().toISOString();
    const sup: Supplier = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    await setDoc(doc(db, 'suppliers', id), cleanForFirestore(sup));
    return sup;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

// ==================== BILLING & INVOICES ====================
export function subscribeInvoices(callback: (invoices: Invoice[]) => void) {
  const path = 'invoices';
  const q = query(collection(db, path), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as Invoice);
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function createInvoice(
  data: Omit<Invoice, 'id' | 'invoiceNumber' | 'createdAt' | 'updatedAt'>
): Promise<Invoice> {
  const path = 'invoices';
  try {
    const snap = await getDocs(collection(db, 'invoices'));
    const seq = 1000 + snap.size + 1;
    const invoiceNumber = `INV-${seq}`;
    const id = 'INV-' + Date.now();
    const now = new Date().toISOString();

    const inv: Invoice = {
      ...data,
      id,
      invoiceNumber,
      createdAt: now,
      updatedAt: now,
    };
    await setDoc(doc(db, 'invoices', id), cleanForFirestore(inv));

    // If paid amount > 0, record payment automatically
    if (inv.paidAmount > 0) {
      await recordPayment({
        invoiceId: id,
        invoiceNumber,
        patientId: inv.patientId,
        patientName: inv.patientName,
        amount: inv.paidAmount,
        method: (inv.paymentMethod as any) || 'cash',
        receivedBy: 'Reception',
        date: inv.date,
        notes: 'Initial invoice payment',
      });
    }
    return inv;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updateInvoicePayment(
  invoiceId: string,
  newPaidAddition: number,
  method: any,
  receivedBy: string
): Promise<void> {
  const path = `invoices/${invoiceId}`;
  try {
    const invRef = doc(db, 'invoices', invoiceId);
    const snap = await getDoc(invRef);
    if (!snap.exists()) throw new Error('Invoice not found');
    const inv = snap.data() as Invoice;

    const updatedPaid = (inv.paidAmount || 0) + newPaidAddition;
    const updatedDue = Math.max(0, inv.total - updatedPaid);
    const updatedStatus = updatedDue === 0 ? 'paid' : updatedPaid > 0 ? 'partial' : 'pending';

    await updateDoc(invRef, cleanForFirestore({
      paidAmount: updatedPaid,
      dueAmount: updatedDue,
      status: updatedStatus,
      updatedAt: new Date().toISOString(),
    }));

    await recordPayment({
      invoiceId,
      invoiceNumber: inv.invoiceNumber,
      patientId: inv.patientId,
      patientName: inv.patientName,
      amount: newPaidAddition,
      method,
      receivedBy,
      date: new Date().toISOString().split('T')[0],
      notes: 'Payment towards dues',
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

// ==================== PAYMENTS ====================
export function subscribePayments(callback: (payments: Payment[]) => void) {
  const path = 'payments';
  const q = query(collection(db, path), orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as Payment);
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function recordPayment(data: Omit<Payment, 'id' | 'createdAt'>): Promise<Payment> {
  const path = 'payments';
  try {
    const id = 'PAY-' + Date.now();
    const payment: Payment = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'payments', id), cleanForFirestore(payment));
    return payment;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

// ==================== MEDICAL DOCUMENTS ====================
export function subscribeMedicalDocuments(patientId: string | null, callback: (docs: MedicalDocument[]) => void) {
  const path = 'medical_documents';
  const q = patientId
    ? query(collection(db, path), where('patientId', '==', patientId), orderBy('createdAt', 'desc'))
    : query(collection(db, path), orderBy('createdAt', 'desc'));

  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as MedicalDocument);
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function addMedicalDocument(
  data: Omit<MedicalDocument, 'id' | 'createdAt'>
): Promise<MedicalDocument> {
  const path = 'medical_documents';
  try {
    const id = 'DOC-' + Date.now();
    const docData: MedicalDocument = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'medical_documents', id), cleanForFirestore(docData));
    return docData;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function deleteMedicalDocument(id: string): Promise<void> {
  const path = `medical_documents/${id}`;
  try {
    await deleteDoc(doc(db, 'medical_documents', id));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// ==================== FOLLOW-UPS ====================
export function subscribeFollowUps(callback: (followUps: FollowUp[]) => void) {
  const path = 'follow_ups';
  const q = query(collection(db, path), orderBy('scheduledDate', 'asc'));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as FollowUp);
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}

export async function addFollowUp(data: Omit<FollowUp, 'id' | 'createdAt' | 'updatedAt'>): Promise<FollowUp> {
  const path = 'follow_ups';
  try {
    const id = 'FLW-' + Date.now();
    const now = new Date().toISOString();
    const flw: FollowUp = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    await setDoc(doc(db, 'follow_ups', id), cleanForFirestore(flw));
    return flw;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updateFollowUp(id: string, updates: Partial<FollowUp>): Promise<void> {
  const path = `follow_ups/${id}`;
  try {
    await updateDoc(doc(db, 'follow_ups', id), cleanForFirestore({
      ...updates,
      updatedAt: new Date().toISOString(),
    }));
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

// ==================== AUDIT LOGS SUBSCRIPTION ====================
export function subscribeAuditLogs(callback: (logs: AuditLog[]) => void) {
  const path = 'audit_logs';
  const q = query(collection(db, path), orderBy('timestamp', 'desc'), limit(100));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => d.data() as AuditLog);
      callback(list);
    },
    (err) => handleFirestoreError(err, OperationType.GET, path)
  );
}
