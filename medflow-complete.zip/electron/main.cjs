const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const { openDatabase, validateBackup } = require('./database.cjs');

const DB_FILE = () => path.join(app.getPath('userData'), 'medflow.db');
const BACKUP_DIR = () => path.join(app.getPath('documents'), 'MedFlow Backups');
const KEEP_AUTO_BACKUPS = 30;

let store = null;
let mainWindow = null;
let quitting = false;

// ---------- only one copy of the app may use the database ----------
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}

const stamp = (d = new Date()) => {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};

// ---------- automatic daily backup (one file per day, newest 30 kept) ----------
function autoBackup() {
  try {
    if (!store) return;
    const dir = BACKUP_DIR();
    store.backupTo(path.join(dir, `medflow-auto-${stamp()}.db`));
    const files = fs
      .readdirSync(dir)
      .filter((f) => /^medflow-auto-\d{4}-\d{2}-\d{2}\.db$/.test(f))
      .sort();
    while (files.length > KEEP_AUTO_BACKUPS) fs.unlinkSync(path.join(dir, files.shift()));
  } catch (err) {
    console.error('Auto backup failed:', err);
  }
}

// ---------- IPC ----------
function registerIpc() {
  ipcMain.handle('db:loadAll', () => store.loadAll());
  ipcMain.handle('db:set', (_e, col, id, json) => store.set(col, id, json));
  ipcMain.handle('db:delete', (_e, col, id) => store.remove(col, id));
  ipcMain.handle('app:dbInfo', () => ({ dbPath: DB_FILE(), backupDir: BACKUP_DIR() }));

  ipcMain.handle('backup:openFolder', async () => {
    fs.mkdirSync(BACKUP_DIR(), { recursive: true });
    await shell.openPath(BACKUP_DIR());
    return true;
  });

  ipcMain.handle('backup:export', async () => {
    try {
      const res = await dialog.showSaveDialog(mainWindow, {
        title: 'Save MedFlow backup',
        defaultPath: path.join(app.getPath('documents'), `medflow-backup-${stamp()}.db`),
        filters: [{ name: 'MedFlow Backup', extensions: ['db'] }],
      });
      if (res.canceled || !res.filePath) return { ok: false, canceled: true };
      store.backupTo(res.filePath);
      return { ok: true, path: res.filePath };
    } catch (err) {
      return { ok: false, error: String(err && err.message ? err.message : err) };
    }
  });

  ipcMain.handle('backup:restore', async () => {
    try {
      const res = await dialog.showOpenDialog(mainWindow, {
        title: 'Select MedFlow backup file',
        properties: ['openFile'],
        filters: [{ name: 'MedFlow Backup', extensions: ['db'] }],
      });
      if (res.canceled || !res.filePaths[0]) return { ok: false, canceled: true };
      const chosen = res.filePaths[0];

      if (!validateBackup(Database, chosen)) {
        return { ok: false, error: 'This file is not a valid MedFlow backup.' };
      }
      const confirm = await dialog.showMessageBox(mainWindow, {
        type: 'warning',
        buttons: ['Cancel', 'Restore'],
        defaultId: 0,
        cancelId: 0,
        title: 'Restore backup',
        message: 'Current data will be REPLACED by the backup.',
        detail: 'A safety copy of the current data is saved first. The app will restart.',
      });
      if (confirm.response !== 1) return { ok: false, canceled: true };

      store.backupTo(path.join(BACKUP_DIR(), `medflow-before-restore-${Date.now()}.db`));
      store.close();
      store = null;
      const target = DB_FILE();
      for (const ext of ['-wal', '-shm']) {
        try { fs.unlinkSync(target + ext); } catch {}
      }
      fs.copyFileSync(chosen, target);
      app.relaunch();
      app.exit(0);
      return { ok: true };
    } catch (err) {
      return { ok: false, error: String(err && err.message ? err.message : err) };
    }
  });
}

// ---------- window ----------
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1366,
    height: 820,
    minWidth: 1024,
    minHeight: 640,
    show: false,
    autoHideMenuBar: true,
    title: 'MedFlow Clinic Manager',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });
  mainWindow.maximize();
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));

  // links such as WhatsApp open in the normal browser (needs internet only for that)
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file://')) {
      e.preventDefault();
      if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    }
  });
  mainWindow.on('closed', () => (mainWindow = null));
}

app.whenReady().then(() => {
  try {
    store = openDatabase(Database, DB_FILE());
  } catch (err) {
    dialog.showErrorBox('MedFlow', 'Database could not be opened:\n' + err.message);
    app.exit(1);
    return;
  }
  Menu.setApplicationMenu(null);
  registerIpc();
  autoBackup();
  createWindow();
});

app.on('before-quit', () => {
  if (quitting) return;
  quitting = true;
  autoBackup();
  try { store && store.close(); } catch {}
});

app.on('window-all-closed', () => app.quit());
