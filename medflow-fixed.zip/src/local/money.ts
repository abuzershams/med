/** Currency symbol used everywhere money is shown. Set from Settings > Clinic Profile. */
let symbol = 'Rs.';

export const DEFAULT_CURRENCY = 'Rs.';

export function setCurrency(value?: string | null) {
  const v = (value ?? '').trim();
  symbol = v || DEFAULT_CURRENCY;
}

/** Current currency symbol, with a trailing space for words like "Rs." */
export function cur(): string {
  return symbol;
}
