/**
 * Printing helpers that work offline on every platform.
 *  - Desktop app (Electron): real Windows print dialog / "Save as PDF" file dialog.
 *  - Phone app (Capacitor/Android): makes a PDF and opens the Share menu
 *    (Print, WhatsApp, Drive, Save to Files ...), because phones have no window.print().
 *  - Normal browser: window.print() / jsPDF download.
 */
import { Capacitor } from '@capacitor/core';
import html2canvas from 'html2canvas-pro';
import jsPDF from 'jspdf';

const isPhoneApp = () => Capacitor.isNativePlatform();

export const isPhone = isPhoneApp;

export const NO_PRINTER_MESSAGE =
  'No printer found on this computer. Turn the printer ON, connect its USB cable (or Wi-Fi), ' +
  'add it in Windows Settings > Printers & scanners, then press Print again. ' +
  'You can also press "Download PDF" and print the file later.';

async function elementToPdfBase64(el: HTMLElement): Promise<string> {
  const canvas = await html2canvas(el, {
    scale: 2,
    useCORS: true,
    logging: false,
    backgroundColor: '#ffffff',
    windowWidth: 900, // lay out like a desktop page so the PDF looks like an A4 sheet
  });

  const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const margin = 8;
  const w = pageW - margin * 2;
  const availH = pageH - margin * 2;
  // how many canvas pixels fit on one A4 page at this width
  const pxPerPage = Math.floor((availH * canvas.width) / w);

  // Cut the long picture into clean A4 pages (no content bleeding into the margins)
  let y = 0;
  let first = true;
  while (y < canvas.height) {
    const sliceH = Math.min(pxPerPage, canvas.height - y);
    const slice = document.createElement('canvas');
    slice.width = canvas.width;
    slice.height = sliceH;
    const ctx = slice.getContext('2d')!;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, slice.width, slice.height);
    ctx.drawImage(canvas, 0, y, canvas.width, sliceH, 0, 0, canvas.width, sliceH);
    if (!first) pdf.addPage();
    pdf.addImage(slice.toDataURL('image/jpeg', 0.95), 'JPEG', margin, margin, w, (sliceH * w) / canvas.width);
    first = false;
    y += sliceH;
  }
  const dataUri = pdf.output('datauristring'); // data:application/pdf;filename=...;base64,XXXX
  return dataUri.substring(dataUri.indexOf('base64,') + 7);
}

async function sharePdfOnPhone(el: HTMLElement, fileName: string): Promise<void> {
  const { Filesystem, Directory } = await import('@capacitor/filesystem');
  const { Share } = await import('@capacitor/share');
  const data = await elementToPdfBase64(el);
  const safe = fileName.replace(/[^\w.\-]+/g, '_');
  const written = await Filesystem.writeFile({ path: safe, data, directory: Directory.Cache });
  await Share.share({ title: safe, url: written.uri, dialogTitle: 'Print / Save / Send PDF' });
}

/** Print button. `el` + `fileName` are needed for the phone app. */
export async function printPage(el?: HTMLElement | null, fileName = 'document.pdf'): Promise<void> {
  if (isPhoneApp()) {
    if (!el) throw new Error('Nothing to print here.');
    await sharePdfOnPhone(el, fileName);
    return;
  }
  const api = window.electronAPI;
  if (api?.printPage) {
    // Tell the user clearly if Windows has no printer at all
    if (api.listPrinters) {
      const printers = await api.listPrinters().catch(() => null);
      if (printers && printers.length === 0) {
        throw new Error(NO_PRINTER_MESSAGE);
      }
    }
    const r = await withPrintTarget(el, () => api.printPage());
    if (!r.ok && r.reason && !/cancel/i.test(r.reason)) {
      throw new Error('Print failed: ' + r.reason);
    }
    return;
  }
  await withPrintTarget(el, async () => {
    window.print();
  });
}

/**
 * "Download PDF" button. Returns true if it handled the job (desktop or phone app),
 * false if the caller should use its own browser download code.
 */
export async function savePageAsPdf(fileName: string, el?: HTMLElement | null): Promise<boolean> {
  if (isPhoneApp()) {
    if (!el) throw new Error('Nothing to save here.');
    await sharePdfOnPhone(el, fileName);
    return true;
  }
  const api = window.electronAPI;
  if (!api?.savePdf) return false;
  const r = await withPrintTarget(el, () => api.savePdf(fileName));
  if (!r.ok && !r.canceled) throw new Error(r.error || 'Could not save PDF');
  return true;
}


/**
 * The print stylesheet shows ONLY elements marked "print-portal" and hides the rest of the app.
 * Modals already live in such a portal. For any other element (e.g. a report) we print a temporary copy.
 */
async function withPrintTarget<T>(el: HTMLElement | null | undefined, fn: () => Promise<T>): Promise<T> {
  if (!el || el.closest('.print-portal')) return fn();
  const holder = document.createElement('div');
  holder.className = 'print-portal print-clone';
  holder.appendChild(el.cloneNode(true));
  document.body.appendChild(holder);
  try {
    return await fn();
  } finally {
    holder.remove();
  }
}

/** Save a text file (CSV etc.). Desktop/browser: normal download. Phone app: Share menu (Save to Files/Drive/WhatsApp). */
export async function saveTextFile(fileName: string, text: string, mime = 'text/csv;charset=utf-8'): Promise<void> {
  const safe = fileName.replace(/[^\w.\-]+/g, '_');
  const body = mime.startsWith('text/csv') ? '\uFEFF' + text : text; // BOM so Excel shows Urdu/Hindi names correctly
  if (isPhoneApp()) {
    const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
    const { Share } = await import('@capacitor/share');
    const written = await Filesystem.writeFile({ path: safe, data: body, directory: Directory.Cache, encoding: Encoding.UTF8 });
    await Share.share({ title: safe, url: written.uri, dialogTitle: 'Save / Send file' });
    return;
  }
  const blob = new Blob([body], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = safe;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    a.remove();
    URL.revokeObjectURL(url);
  }, 1500);
}

/** Save a stored document (data: URL). Phone app: Share menu. Otherwise normal download. */
export async function saveDataUrl(fileName: string, dataUrl: string): Promise<void> {
  const safe = (fileName || 'document').replace(/[^\w.\-]+/g, '_');
  if (isPhoneApp()) {
    const { Filesystem, Directory } = await import('@capacitor/filesystem');
    const { Share } = await import('@capacitor/share');
    const base64 = dataUrl.substring(dataUrl.indexOf('base64,') + 7);
    const written = await Filesystem.writeFile({ path: safe, data: base64, directory: Directory.Cache });
    await Share.share({ title: safe, url: written.uri, dialogTitle: 'Save / Send file' });
    return;
  }
  const a = document.createElement('a');
  a.href = dataUrl;
  a.download = safe;
  document.body.appendChild(a);
  a.click();
  a.remove();
}
