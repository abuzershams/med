import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initStore } from './local/firestore.ts';

// Desktop (Windows) fix: keyboard input can freeze after alert()/confirm().
if (window.electronAPI?.refocus) {
  const refocus = () => setTimeout(() => window.electronAPI?.refocus(), 0);
  const nativeAlert = window.alert.bind(window);
  const nativeConfirm = window.confirm.bind(window);
  window.alert = (msg?: any) => {
    nativeAlert(msg);
    refocus();
  };
  window.confirm = (msg?: string) => {
    const r = nativeConfirm(msg);
    refocus();
    return r;
  };
}

const root = createRoot(document.getElementById('root')!);

initStore()
  .then(() => root.render(<App />))
  .catch((err) => {
    console.error('Failed to open local database', err);
    document.getElementById('root')!.innerHTML =
      '<div style="padding:24px;font-family:sans-serif"><h2>Database could not be opened</h2><p>' +
      String(err && err.message ? err.message : err) +
      '</p></div>';
  });
