import React from 'react';
import { AlertTriangle, Trash2, X, Loader2, Pill } from 'lucide-react';
import { Medicine } from '../../types';

interface DeleteMedicineModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicine: Medicine | null;
  onConfirm: () => Promise<void>;
  isLoading: boolean;
}

export const DeleteMedicineModal: React.FC<DeleteMedicineModalProps> = ({
  isOpen,
  onClose,
  medicine,
  onConfirm,
  isLoading,
}) => {
  if (!isOpen || !medicine) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2 text-rose-600">
              <div className="w-9 h-9 rounded-xl bg-rose-50 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-rose-600" />
              </div>
              <h3 className="font-bold text-slate-900 text-base">Remove Medicine?</h3>
            </div>
            <button
              onClick={onClose}
              disabled={isLoading}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition cursor-pointer disabled:opacity-40"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
            <div className="flex items-center gap-2">
              <Pill className="w-4 h-4 text-blue-600 shrink-0" />
              <p className="font-bold text-slate-900 text-sm">{medicine.name}</p>
            </div>
            <div className="text-xs text-slate-600 space-y-0.5 pl-6 font-mono">
              <p>Generic: <span className="text-slate-800 font-semibold">{medicine.generic}</span></p>
              <p>Strength: <span className="text-slate-800 font-semibold">{medicine.strength}</span> ({medicine.form})</p>
              <p>Current Stock: <span className="text-slate-800 font-semibold">{medicine.currentStock} units</span></p>
            </div>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            If this formulation is referenced by existing patient prescriptions, it will be safely <strong>archived</strong> so past patient medical records remain preserved.
          </p>

          <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-200 transition cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={onConfirm}
              disabled={isLoading}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-xs transition flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Removing...</span>
                </>
              ) : (
                <>
                  <Trash2 className="w-4 h-4" />
                  <span>Confirm Delete / Archive</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
