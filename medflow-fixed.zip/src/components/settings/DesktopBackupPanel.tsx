import { useEffect, useState } from 'react';
import { Database, FolderOpen, RotateCcw, HardDriveDownload } from 'lucide-react';

/** Backup / restore of the full local database. Only shown inside the desktop app. */
export function DesktopBackupPanel() {
  const api = window.electronAPI;
  const [info, setInfo] = useState<{ dbPath: string; backupDir: string } | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api?.getDbInfo().then(setInfo).catch(() => {});
  }, []);

  if (!api) return null;

  const doExport = async () => {
    setBusy(true);
    const r = await api.exportBackup();
    setBusy(false);
    if (r.canceled) return;
    setMsg(r.ok ? { ok: true, text: `Backup saved: ${r.path}` } : { ok: false, text: r.error || 'Backup failed' });
  };

  const doRestore = async () => {
    setBusy(true);
    const r = await api.restoreBackup();
    setBusy(false);
    if (r.canceled) return;
    if (!r.ok) setMsg({ ok: false, text: r.error || 'Restore failed' });
  };

  return (
    <div className="bg-white rounded-2xl border border-teal-200 p-6 shadow-xs max-w-2xl space-y-4">
      <div>
        <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
          <Database className="w-5 h-5 text-teal-600" />
          Full Database Backup (Recommended)
        </h3>
        <p className="text-sm text-slate-500 mt-1">
          Copy all clinic data to a pendrive or external drive. Do this regularly. If this computer
          fails, the data can be restored on another computer.
        </p>
      </div>

      <div className="flex flex-wrap gap-3">
        <button
          disabled={busy}
          onClick={doExport}
          className="inline-flex items-center gap-2 px-5 py-3 bg-teal-600 text-white rounded-xl hover:bg-teal-700 font-medium transition shadow-sm cursor-pointer disabled:opacity-50"
        >
          <HardDriveDownload className="w-5 h-5" />
          Save Backup to Pendrive / Folder
        </button>
        <button
          disabled={busy}
          onClick={doRestore}
          className="inline-flex items-center gap-2 px-5 py-3 bg-white text-slate-700 border border-slate-300 rounded-xl hover:bg-slate-50 font-medium transition cursor-pointer disabled:opacity-50"
        >
          <RotateCcw className="w-5 h-5" />
          Restore from Backup
        </button>
        <button
          onClick={() => api.openBackupFolder()}
          className="inline-flex items-center gap-2 px-5 py-3 bg-white text-slate-700 border border-slate-300 rounded-xl hover:bg-slate-50 font-medium transition cursor-pointer"
        >
          <FolderOpen className="w-5 h-5" />
          Open Auto-Backup Folder
        </button>
      </div>

      {msg && (
        <p className={`text-sm font-medium ${msg.ok ? 'text-teal-700' : 'text-red-600'}`}>{msg.text}</p>
      )}

      <div className="text-xs text-slate-500 space-y-1">
        <p>An automatic backup is also made every day and when the app closes (last 30 days are kept).</p>
        {info && <p>Auto-backup folder: {info.backupDir}</p>}
      </div>
    </div>
  );
}
