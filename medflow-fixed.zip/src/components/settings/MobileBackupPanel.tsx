import { useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { Share2, Upload } from 'lucide-react';
import { exportAll, importAll } from '../../local/firestore';

/** Backup / restore for the Android app. Only shown inside the phone app. */
export function MobileBackupPanel() {
  const fileRef = useRef<HTMLInputElement>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  if (!Capacitor.isNativePlatform()) return null;

  const doExport = async () => {
    setBusy(true);
    try {
      const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
      const { Share } = await import('@capacitor/share');
      const name = `medflow-backup-${new Date().toISOString().split('T')[0]}.json`;
      const written = await Filesystem.writeFile({
        path: name,
        data: JSON.stringify({ medflowBackup: 1, data: exportAll() }),
        directory: Directory.Cache,
        encoding: Encoding.UTF8,
      });
      await Share.share({ title: 'MedFlow backup', url: written.uri, dialogTitle: 'Save backup to Drive / WhatsApp / Files' });
      setMsg({ ok: true, text: 'Backup file ready. Save it to Google Drive or send it to yourself.' });
    } catch (e: any) {
      setMsg({ ok: false, text: e?.message || 'Backup failed' });
    }
    setBusy(false);
  };

  const doRestore = async (file: File | undefined) => {
    if (!file) return;
    if (!window.confirm('Current data will be REPLACED by this backup. Continue?')) return;
    setBusy(true);
    try {
      const parsed = JSON.parse(await file.text());
      if (!parsed || parsed.medflowBackup !== 1 || !parsed.data) throw new Error('This is not a MedFlow backup file.');
      await importAll(parsed.data);
      window.location.reload();
    } catch (e: any) {
      setMsg({ ok: false, text: e?.message || 'Restore failed' });
      setBusy(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-teal-200 p-6 shadow-xs max-w-2xl space-y-4">
      <div>
        <h3 className="font-bold text-slate-900 text-lg">Phone Data Backup (Recommended)</h3>
        <p className="text-sm text-slate-500 mt-1">
          Data is stored only on this phone. If the phone is lost or the app is uninstalled, data is lost.
          Save a backup file regularly to Google Drive or send it to yourself.
        </p>
      </div>
      <div className="flex flex-wrap gap-3">
        <button
          disabled={busy}
          onClick={doExport}
          className="inline-flex items-center gap-2 px-5 py-3 bg-teal-600 text-white rounded-xl hover:bg-teal-700 font-medium transition shadow-sm cursor-pointer disabled:opacity-50"
        >
          <Share2 className="w-5 h-5" />
          Save / Share Backup
        </button>
        <button
          disabled={busy}
          onClick={() => fileRef.current?.click()}
          className="inline-flex items-center gap-2 px-5 py-3 bg-white text-slate-700 border border-slate-300 rounded-xl hover:bg-slate-50 font-medium transition cursor-pointer disabled:opacity-50"
        >
          <Upload className="w-5 h-5" />
          Restore from Backup
        </button>
        <input ref={fileRef} type="file" accept=".json,application/json" className="hidden" onChange={(e) => doRestore(e.target.files?.[0])} />
      </div>
      {msg && <p className={`text-sm font-medium ${msg.ok ? 'text-teal-700' : 'text-red-600'}`}>{msg.text}</p>}
    </div>
  );
}
