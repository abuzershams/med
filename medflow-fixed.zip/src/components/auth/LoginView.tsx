import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Stethoscope,
  Lock,
  User,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  Users,
  CalendarCheck,
  FileText,
  Pill,
  BarChart3,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

export const LoginView: React.FC = () => {
  const { login, clinic } = useAuth();
  const [username, setUsername] = useState('doctoradmin');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showForgotModal, setShowForgotModal] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!username.trim() || !password) {
      setError('Please enter both username and password.');
      return;
    }

    setLoading(true);
    const result = await login(username.trim(), password, rememberMe);
    if (!result.success) {
      setError(result.error || 'Invalid credentials.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl w-full bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col md:flex-row">
        
        {/* Left Hero Branding Panel */}
        <div className="md:w-5/12 bg-gradient-to-br from-blue-700 via-blue-800 to-indigo-900 text-white p-8 flex flex-col justify-between relative overflow-hidden">
          {/* Background subtle decoration */}
          <div className="absolute -top-12 -right-12 w-48 h-48 bg-white/5 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-cyan-400/10 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-inner">
                <Stethoscope className="w-7 h-7 text-cyan-300" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">
                  {clinic?.name || 'Clinic Management System'}
                </h1>
                <p className="text-xs text-blue-200">
                  {clinic?.doctorName ? `Lead: ${clinic.doctorName}` : 'Professional Healthcare System'}
                </p>
              </div>
            </div>

            <h2 className="text-2xl font-extrabold tracking-tight mb-2 leading-tight">
              Better Care • Smarter Management
            </h2>
            <p className="text-xs text-blue-200 mb-8">
              A unified clinical portal for doctors, nurses, receptionists, and pharmacy staff.
            </p>

            {/* Feature highlights */}
            <div className="space-y-3">
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-3.5 py-2 rounded-xl border border-white/10 text-xs">
                <Users className="w-4 h-4 text-cyan-300 shrink-0" />
                <span>Patient EMR & Chronological Timeline</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-3.5 py-2 rounded-xl border border-white/10 text-xs">
                <CalendarCheck className="w-4 h-4 text-cyan-300 shrink-0" />
                <span>OPD Queues & Smart Scheduling</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-3.5 py-2 rounded-xl border border-white/10 text-xs">
                <FileText className="w-4 h-4 text-cyan-300 shrink-0" />
                <span>Standardized Digital Prescriptions</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-3.5 py-2 rounded-xl border border-white/10 text-xs">
                <Pill className="w-4 h-4 text-cyan-300 shrink-0" />
                <span>Pharmacy Inventory & Low Stock Alerts</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-3.5 py-2 rounded-xl border border-white/10 text-xs">
                <BarChart3 className="w-4 h-4 text-cyan-300 shrink-0" />
                <span>Revenue, Billing & Follow-up Analytics</span>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-white/10 text-[11px] text-blue-200 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-300" />
              Role-Based Access (RBAC)
            </span>
            <span>v1.0.0</span>
          </div>
        </div>

        {/* Right Login Form */}
        <div className="md:w-7/12 p-6 sm:p-10 flex flex-col justify-center">
          <div className="mb-6">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Secure Clinic Portal</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Welcome Back</h2>
            <p className="text-sm text-slate-500 mt-1">
              Sign in with your clinic staff credentials to access records.
            </p>
          </div>

          {error && (
            <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Username <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. doctoradmin"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm text-slate-800 pl-10"
                />
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs font-semibold text-slate-700">
                  Password <span className="text-rose-500">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => setShowForgotModal(true)}
                  className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm text-slate-800 pl-10 pr-10"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-slate-600 select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                />
                <span>Remember me on this workstation</span>
              </label>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <span>Verifying credentials...</span>
                ) : (
                  <>
                    <span>Log In to Clinic Portal</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Helper note */}
          <div className="mt-8 pt-6 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Primary Doctor / Admin username: <strong className="text-slate-700 font-semibold">doctoradmin</strong></span>
            <span className="text-emerald-600 font-medium flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Database Online
            </span>
          </div>
        </div>
      </div>

      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 mb-2">Password Recovery</h3>
            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              For security compliance, staff accounts can be reset directly by the clinic administrator in <strong className="text-slate-800">Settings &gt; Staff & Permissions</strong>.
            </p>
            <div className="bg-amber-50 border border-amber-200 text-amber-900 text-xs p-3.5 rounded-xl mb-4 leading-relaxed">
              <strong>Need Admin Reset?</strong> If you forgot the primary administrator password, contact your technical support or reset your account through the administrative console.
            </div>
            <button
              onClick={() => setShowForgotModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold transition"
            >
              Understood, Back to Login
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
