import React, { useState } from 'react';
import { Appointment, AppointmentStatus } from '../../types';
import { WhatsAppButton } from '../common/WhatsAppButton';
import {
  Calendar,
  Clock,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Stethoscope,
  Trash2,
  Edit2,
  Kanban,
  List,
  AlertCircle,
  Phone,
} from 'lucide-react';

interface AppointmentsViewProps {
  appointments: Appointment[];
  onOpenBookModal: () => void;
  onOpenEditModal: (appointment: Appointment) => void;
  onStartConsultation: (appointment: Appointment) => void;
  onUpdateStatus: (id: string, newStatus: AppointmentStatus) => Promise<void>;
  onDeleteAppointment: (id: string) => Promise<void>;
}

export const AppointmentsView: React.FC<AppointmentsViewProps> = ({
  appointments,
  onOpenBookModal,
  onOpenEditModal,
  onStartConsultation,
  onUpdateStatus,
  onDeleteAppointment,
}) => {
  const [viewMode, setViewMode] = useState<'list' | 'kanban'>('list');
  const [dateFilter, setDateFilter] = useState<'today' | 'tomorrow' | 'week' | 'all'>('today');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrowDate = new Date();
  tomorrowDate.setDate(tomorrowDate.getDate() + 1);
  const tomorrowStr = tomorrowDate.toISOString().split('T')[0];

  const filteredAppointments = appointments.filter((apt) => {
    // 1. Search filter
    const term = searchTerm.toLowerCase();
    const matchSearch =
      apt.patientName.toLowerCase().includes(term) ||
      apt.patientPhone.includes(term) ||
      apt.reason.toLowerCase().includes(term);

    // 2. Date filter
    let matchDate = true;
    if (dateFilter === 'today') {
      matchDate = apt.date === todayStr;
    } else if (dateFilter === 'tomorrow') {
      matchDate = apt.date === tomorrowStr;
    } else if (dateFilter === 'week') {
      const aptTime = new Date(apt.date).getTime();
      const nowTime = new Date().getTime();
      const diffDays = (aptTime - nowTime) / (1000 * 3600 * 24);
      matchDate = diffDays >= -1 && diffDays <= 7;
    }

    // 3. Status filter
    const matchStatus = statusFilter === 'all' || apt.status === statusFilter;

    return matchSearch && matchDate && matchStatus;
  });

  const statusBadgeColor: Record<string, string> = {
    scheduled: 'bg-indigo-100 text-indigo-700 border-indigo-200',
    confirmed: 'bg-blue-100 text-blue-700 border-blue-200',
    waiting: 'bg-amber-100 text-amber-800 border-amber-200',
    in_consultation: 'bg-cyan-100 text-cyan-800 border-cyan-200',
    completed: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    cancelled: 'bg-rose-100 text-rose-700 border-rose-200',
    no_show: 'bg-slate-100 text-slate-700 border-slate-200',
  };

  const kanbanColumns: { status: AppointmentStatus; label: string; color: string }[] = [
    { status: 'scheduled', label: 'Scheduled', color: 'border-indigo-400 bg-indigo-50/50' },
    { status: 'waiting', label: 'Waiting in Lobby', color: 'border-amber-400 bg-amber-50/50' },
    { status: 'in_consultation', label: 'In Consultation', color: 'border-cyan-400 bg-cyan-50/50' },
    { status: 'completed', label: 'Completed', color: 'border-emerald-400 bg-emerald-50/50' },
  ];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Calendar className="w-5 h-5 text-indigo-600" />
            <span>Clinic Appointments & OPD Queue</span>
          </h2>
          <p className="text-xs text-slate-500">
            {filteredAppointments.length} appointment(s) displayed • Real-time status management
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* List vs Kanban Toggle */}
          <div className="bg-slate-100 p-1 rounded-xl flex items-center gap-1 border border-slate-200 text-xs">
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg flex items-center gap-1 font-semibold transition ${
                viewMode === 'list' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <List className="w-4 h-4" />
              <span className="hidden sm:inline">List</span>
            </button>
            <button
              onClick={() => setViewMode('kanban')}
              className={`p-1.5 rounded-lg flex items-center gap-1 font-semibold transition ${
                viewMode === 'kanban' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Kanban className="w-4 h-4" />
              <span className="hidden sm:inline">Board</span>
            </button>
          </div>

          <button
            onClick={onOpenBookModal}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs hover:shadow transition"
          >
            <Plus className="w-4 h-4" />
            <span>+ Book Appointment</span>
          </button>
        </div>
      </div>

      {/* Filter and Date Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-3">
        {/* Date presets */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
          <button
            onClick={() => setDateFilter('today')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition ${
              dateFilter === 'today' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Today
          </button>
          <button
            onClick={() => setDateFilter('tomorrow')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition ${
              dateFilter === 'tomorrow' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Tomorrow
          </button>
          <button
            onClick={() => setDateFilter('week')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition ${
              dateFilter === 'week' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Next 7 Days
          </button>
          <button
            onClick={() => setDateFilter('all')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition ${
              dateFilter === 'all' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Dates
          </button>
        </div>

        {/* Search */}
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search patient, phone, symptoms..."
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Status Dropdown */}
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          <option value="all">All Statuses</option>
          <option value="scheduled">Scheduled</option>
          <option value="waiting">Waiting in Lobby</option>
          <option value="in_consultation">In Consultation</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
          <option value="no_show">No Show</option>
        </select>
      </div>

      {/* VIEW MODE 1: LIST VIEW */}
      {viewMode === 'list' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          {filteredAppointments.length === 0 ? (
            <div className="py-16 text-center text-slate-400 text-xs">
              <Calendar className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="font-semibold text-slate-600 text-sm">No appointments matching filters</p>
              <p className="mt-1 text-slate-400">Try changing your date filter or book a new appointment.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[11px] border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Date & Slot</th>
                    <th className="py-3 px-4">Patient</th>
                    <th className="py-3 px-4">Reason / Symptoms</th>
                    <th className="py-3 px-4">Type & Source</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAppointments.map((apt) => (
                    <tr key={apt.id} className="hover:bg-indigo-50/40 transition">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{apt.date}</div>
                        <div className="text-[11px] text-indigo-700 font-semibold flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3" />
                          <span>{apt.time}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{apt.patientName}</div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{apt.patientPhone}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-slate-700">
                        <p className="font-medium">{apt.reason}</p>
                        {apt.notes && <p className="text-[10px] text-slate-400 italic truncate max-w-xs">{apt.notes}</p>}
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="capitalize font-medium text-slate-700">{apt.type}</span>
                        <span className="text-[10px] text-slate-400 block capitalize">{apt.source.replace('_', ' ')}</span>
                      </td>

                      <td className="py-3.5 px-4">
                        <select
                          value={apt.status}
                          onChange={(e) => onUpdateStatus(apt.id, e.target.value as any)}
                          className={`text-xs font-semibold px-2.5 py-1 rounded-lg border capitalize focus:outline-none ${
                            statusBadgeColor[apt.status] || 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          <option value="scheduled">Scheduled</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="waiting">Waiting</option>
                          <option value="in_consultation">In Consultation</option>
                          <option value="completed">Completed</option>
                          <option value="cancelled">Cancelled</option>
                          <option value="no_show">No Show</option>
                        </select>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <WhatsAppButton
                            phone={apt.patientPhone}
                            patientName={apt.patientName}
                            messageType="appointment"
                            size="sm"
                          />

                          {apt.status !== 'completed' && (
                            <button
                              onClick={() => onStartConsultation(apt)}
                              className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold flex items-center gap-1 shadow-2xs transition"
                              title="Begin Doctor Consultation"
                            >
                              <Stethoscope className="w-3.5 h-3.5" />
                              <span>Consult</span>
                            </button>
                          )}

                          <button
                            onClick={() => onOpenEditModal(apt)}
                            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                            title="Edit / Reschedule"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => {
                              if (window.confirm('Delete this appointment entry?')) {
                                onDeleteAppointment(apt.id);
                              }
                            }}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 transition"
                            title="Cancel / Delete Appointment"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* VIEW MODE 2: KANBAN BOARD */}
      {viewMode === 'kanban' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {kanbanColumns.map((col) => {
            const columnItems = filteredAppointments.filter((a) => a.status === col.status);
            return (
              <div
                key={col.status}
                className={`rounded-2xl border p-4 flex flex-col h-[650px] ${col.color}`}
              >
                <div className="flex items-center justify-between pb-3 border-b border-slate-200/60 mb-3">
                  <h3 className="font-bold text-xs uppercase tracking-wider text-slate-800">
                    {col.label}
                  </h3>
                  <span className="w-6 h-6 rounded-full bg-white text-slate-800 text-xs font-bold flex items-center justify-center shadow-2xs">
                    {columnItems.length}
                  </span>
                </div>

                <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                  {columnItems.length === 0 ? (
                    <div className="text-center py-10 text-slate-400 text-xs">
                      No patients in {col.label.toLowerCase()}
                    </div>
                  ) : (
                    columnItems.map((item) => (
                      <div
                        key={item.id}
                        className="bg-white rounded-xl p-3.5 shadow-2xs border border-slate-200/80 hover:border-indigo-300 transition text-xs space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-900">{item.patientName}</span>
                          <span className="font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md font-mono">
                            {item.time}
                          </span>
                        </div>

                        <p className="text-slate-600 font-medium line-clamp-2">{item.reason}</p>

                        <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-100">
                          <span>{item.date}</span>
                          <span className="capitalize">{item.type}</span>
                        </div>

                        {/* Quick Action in Card */}
                        <div className="pt-2 flex items-center justify-between gap-1">
                          <WhatsAppButton
                            phone={item.patientPhone}
                            patientName={item.patientName}
                            size="sm"
                          />

                          {item.status !== 'completed' && (
                            <button
                              onClick={() => onStartConsultation(item)}
                              className="px-2 py-1 rounded-md bg-blue-600 hover:bg-blue-700 text-white font-semibold text-[11px] flex items-center gap-1 shadow-2xs"
                            >
                              <Stethoscope className="w-3 h-3" />
                              <span>Consult</span>
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
