import React, { useState } from 'react';
import { Patient } from '../../types';
import { WhatsAppButton } from '../common/WhatsAppButton';
import { DeletePatientModal } from './DeletePatientModal';
import { checkPatientClinicalHistory } from '../../services/db';
import {
  Users,
  Search,
  Plus,
  Filter,
  Download,
  Trash2,
  Edit2,
  Eye,
  Stethoscope,
  Phone,
  Droplet,
  MapPin,
  Calendar,
  CheckCircle,
} from 'lucide-react';
import { saveTextFile } from '../../local/printing';

interface PatientsViewProps {
  patients: Patient[];
  onOpenAddModal: () => void;
  onOpenEditModal: (patient: Patient) => void;
  onOpenProfileModal: (patient: Patient) => void;
  onOpenConsultation: (patient: Patient) => void;
  onDeletePatient: (id: string, name: string) => Promise<void>;
}

export const PatientsView: React.FC<PatientsViewProps> = ({
  patients,
  onOpenAddModal,
  onOpenEditModal,
  onOpenProfileModal,
  onOpenConsultation,
  onDeletePatient,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [genderFilter, setGenderFilter] = useState<string>('all');
  const [bloodFilter, setBloodFilter] = useState<string>('all');

  // Delete modal state
  const [patientToDelete, setPatientToDelete] = useState<Patient | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [clinicalHistoryCount, setClinicalHistoryCount] = useState<number>(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Filtered patients
  const filteredPatients = patients.filter((p) => {
    const term = searchTerm.toLowerCase();
    const matchSearch =
      p.fullName.toLowerCase().includes(term) ||
      p.patientId.toLowerCase().includes(term) ||
      p.phone.includes(term) ||
      (p.city && p.city.toLowerCase().includes(term));

    const matchGender = genderFilter === 'all' || p.gender === genderFilter;
    const matchBlood = bloodFilter === 'all' || p.bloodGroup === bloodFilter;

    return matchSearch && matchGender && matchBlood;
  });

  const handleExportCSV = () => {
    const headers = ['Patient ID', 'Full Name', 'Age', 'Gender', 'Phone', 'Blood Group', 'City', 'Address', 'Registered At'];
    const rows = filteredPatients.map((p) => [
      p.patientId,
      `"${p.fullName.replace(/"/g, '""')}"`,
      p.age,
      p.gender,
      p.phone,
      p.bloodGroup || '',
      `"${(p.city || '').replace(/"/g, '""')}"`,
      `"${(p.address || '').replace(/"/g, '""')}"`,
      p.createdAt.split('T')[0],
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    saveTextFile(`Patients_Export_${new Date().toISOString().split('T')[0]}.csv`, csvContent).catch((e) => alert(e.message));
  };

  const handleOpenDeleteModal = async (p: Patient) => {
    setPatientToDelete(p);
    setDeleteError(null);
    setIsDeleteModalOpen(true);
    try {
      const count = await checkPatientClinicalHistory(p.id);
      setClinicalHistoryCount(count);
    } catch {
      setClinicalHistoryCount(0);
    }
  };

  const handleConfirmDelete = async (p: Patient) => {
    setIsDeleting(true);
    setDeleteError(null);
    try {
      await onDeletePatient(p.id, p.fullName);
      setIsDeleteModalOpen(false);
      setPatientToDelete(null);
      setToastMessage(`Patient ${p.fullName} (${p.patientId}) was successfully deleted.`);
      setTimeout(() => {
        setToastMessage(null);
      }, 4000);
    } catch (err: any) {
      console.error('Failed to delete patient:', err);
      setDeleteError(err.message || 'Failed to delete patient record from database. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-600 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2.5 text-xs font-semibold animate-in slide-in-from-top-4">
          <CheckCircle className="w-4 h-4 shrink-0 text-emerald-200" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header section with Stats & Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            <span>Patient Registry & EMR</span>
          </h2>
          <p className="text-xs text-slate-500">
            {patients.length} total patient(s) registered in clinic database
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs transition"
            title="Export patient records to CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs hover:shadow transition"
          >
            <Plus className="w-4 h-4" />
            <span>+ Add Patient</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by patient name, Patient ID (PAT-...), mobile number, city..."
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={genderFilter}
            onChange={(e) => setGenderFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Genders</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>

          <select
            value={bloodFilter}
            onChange={(e) => setBloodFilter(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Blood Groups</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
          </select>
        </div>
      </div>

      {/* Patients Table / List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredPatients.length === 0 ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="font-semibold text-slate-600 text-sm">No patient records found</p>
            <p className="mt-1 text-slate-400">
              {searchTerm ? 'Try adjusting your search criteria.' : 'Click "+ Add Patient" above to register your first patient.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[11px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Patient ID</th>
                  <th className="py-3 px-4">Full Name</th>
                  <th className="py-3 px-4">Age / Gender</th>
                  <th className="py-3 px-4">Phone</th>
                  <th className="py-3 px-4">Blood Group</th>
                  <th className="py-3 px-4">City / Area</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPatients.map((p) => (
                  <tr key={p.id} className="hover:bg-blue-50/40 transition group">
                    <td className="py-3.5 px-4 font-mono font-bold text-blue-700">
                      {p.patientId}
                    </td>

                    <td className="py-3.5 px-4">
                      <button
                        onClick={() => onOpenProfileModal(p)}
                        className="font-bold text-slate-900 hover:text-blue-700 text-left transition"
                      >
                        {p.fullName}
                      </button>
                      {p.notes && (
                        <p className="text-[10px] text-slate-400 truncate max-w-xs">{p.notes}</p>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-slate-600">
                      {p.age} Yrs • {p.gender}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5 font-medium text-slate-700">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{p.phone}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="inline-flex items-center gap-1 font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-100 text-[11px]">
                        <Droplet className="w-3 h-3 text-rose-500" />
                        {p.bloodGroup || 'N/A'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-slate-600">
                      {p.city || 'Local'}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <WhatsAppButton
                          phone={p.phone}
                          patientName={p.fullName}
                          size="sm"
                        />

                        <button
                          onClick={() => onOpenConsultation(p)}
                          className="p-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 transition cursor-pointer"
                          title="Start OPD Consultation"
                        >
                          <Stethoscope className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => onOpenProfileModal(p)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer"
                          title="View Chronological History"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => onOpenEditModal(p)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer"
                          title="Edit Patient Details"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleOpenDeleteModal(p)}
                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 transition cursor-pointer"
                          title="Delete Patient Record"
                          aria-label={`Delete Patient ${p.fullName}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Delete Patient Confirmation Modal */}
      <DeletePatientModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setPatientToDelete(null);
          setDeleteError(null);
        }}
        patient={patientToDelete}
        onConfirmDelete={handleConfirmDelete}
        isDeleting={isDeleting}
        errorMessage={deleteError}
        clinicalHistoryCount={clinicalHistoryCount}
      />
    </div>
  );
};
