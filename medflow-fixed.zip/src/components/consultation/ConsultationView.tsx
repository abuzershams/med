import React, { useState, useEffect } from 'react';
import { Patient, Appointment, Consultation, Vital } from '../../types';
import {
  Stethoscope,
  User,
  Activity,
  FileText,
  Save,
  CheckCircle2,
  Clock,
  Calendar,
  AlertCircle,
  Plus,
  Receipt,
  Heart,
} from 'lucide-react';

interface ConsultationViewProps {
  patients: Patient[];
  consultations: Consultation[];
  vitals: Vital[];
  activePatient?: Patient | null;
  activeAppointment?: Appointment | null;
  doctorName: string;
  onSaveConsultation: (data: Omit<Consultation, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Consultation>;
  onProceedToPrescription: (consultation: Consultation, patient: Patient) => void;
  onProceedToInvoice: (consultation: Consultation, patient: Patient) => void;
}

export const ConsultationView: React.FC<ConsultationViewProps> = ({
  patients,
  consultations,
  vitals,
  activePatient,
  activeAppointment,
  doctorName,
  onSaveConsultation,
  onProceedToPrescription,
  onProceedToInvoice,
}) => {
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');
  const [chiefComplaint, setChiefComplaint] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [medicalHistory, setMedicalHistory] = useState('');
  const [examination, setExamination] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [clinicalNotes, setClinicalNotes] = useState('');
  const [treatmentPlan, setTreatmentPlan] = useState('');
  const [advice, setAdvice] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');
  const [loading, setLoading] = useState(false);
  const [successCon, setSuccessCon] = useState<Consultation | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (activePatient) {
      setSelectedPatientId(activePatient.id);
      setMedicalHistory(activePatient.notes || '');
    } else if (patients.length > 0 && !selectedPatientId) {
      setSelectedPatientId(patients[0].id);
      setMedicalHistory(patients[0].notes || '');
    }

    if (activeAppointment) {
      setChiefComplaint(activeAppointment.reason || '');
    }
  }, [activePatient, activeAppointment, patients]);

  const currentPatient = patients.find((p) => p.id === selectedPatientId);
  const patientPastConsultations = consultations.filter((c) => c.patientId === selectedPatientId);
  const patientLatestVital = vitals.find((v) => v.patientId === selectedPatientId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedPatientId || !currentPatient) {
      setError('Please select a patient for this consultation.');
      return;
    }
    if (!diagnosis.trim()) {
      setError('Diagnosis is required.');
      return;
    }

    setLoading(true);
    try {
      const created = await onSaveConsultation({
        patientId: currentPatient.id,
        patientName: currentPatient.fullName,
        patientAge: currentPatient.age,
        patientGender: currentPatient.gender,
        appointmentId: activeAppointment?.id,
        doctorName: doctorName || 'Attending Doctor',
        chiefComplaint: chiefComplaint.trim() || 'General consultation',
        symptoms: symptoms.trim(),
        medicalHistory: medicalHistory.trim() || undefined,
        examination: examination.trim() || undefined,
        diagnosis: diagnosis.trim(),
        clinicalNotes: clinicalNotes.trim() || undefined,
        treatmentPlan: treatmentPlan.trim() || undefined,
        advice: advice.trim() || undefined,
        followUpDate: followUpDate || undefined,
      });
      setSuccessCon(created);
    } catch (err: any) {
      setError(err.message || 'Failed to save consultation.');
    } finally {
      setLoading(false);
    }
  };

  const handleResetForm = () => {
    setSuccessCon(null);
    setChiefComplaint('');
    setSymptoms('');
    setExamination('');
    setDiagnosis('');
    setClinicalNotes('');
    setTreatmentPlan('');
    setAdvice('');
    setFollowUpDate('');
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-blue-600" />
            <span>Doctor OPD Consultation Station</span>
          </h2>
          <p className="text-xs text-slate-500">
            Document clinical findings, diagnosis, treatment advice & trigger digital prescription
          </p>
        </div>

        {/* Patient Selection Dropdown */}
        <div className="w-full sm:w-72">
          <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
            Active Patient Encounter:
          </label>
          <select
            value={selectedPatientId}
            onChange={(e) => {
              setSelectedPatientId(e.target.value);
              setSuccessCon(null);
            }}
            className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-2xs"
          >
            {patients.map((p) => (
              <option key={p.id} value={p.id}>
                {p.fullName} ({p.patientId}) - {p.gender}, {p.age}y
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main 2-Column Clinical Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Comprehensive Consultation Form */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successCon ? (
            <div className="py-8 text-center space-y-4">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Consultation Documented Successfully</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Diagnosis: <strong className="text-slate-800">{successCon.diagnosis}</strong> recorded for{' '}
                  <strong className="text-slate-800">{currentPatient?.fullName}</strong>.
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
                <button
                  onClick={() => currentPatient && onProceedToPrescription(successCon, currentPatient)}
                  className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs hover:shadow transition flex items-center gap-1.5"
                >
                  <FileText className="w-4 h-4" />
                  <span>Generate Digital Prescription (Rx)</span>
                </button>

                <button
                  onClick={() => currentPatient && onProceedToInvoice(successCon, currentPatient)}
                  className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs hover:shadow transition flex items-center gap-1.5"
                >
                  <Receipt className="w-4 h-4" />
                  <span>Generate Billing Invoice</span>
                </button>

                <button
                  onClick={handleResetForm}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold transition"
                >
                  Next Consultation
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Chief Complaint <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={chiefComplaint}
                    onChange={(e) => setChiefComplaint(e.target.value)}
                    placeholder="e.g. High fever for 3 days, body ache, dry cough"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Presenting Symptoms
                  </label>
                  <input
                    type="text"
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    placeholder="e.g. Chills, sore throat, fatigue, loss of appetite"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Medical & Allergy History
                  </label>
                  <textarea
                    rows={2}
                    value={medicalHistory}
                    onChange={(e) => setMedicalHistory(e.target.value)}
                    placeholder="Known hypertension, diabetes, drug allergies..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Physical Examination Findings
                  </label>
                  <textarea
                    rows={2}
                    value={examination}
                    onChange={(e) => setExamination(e.target.value)}
                    placeholder="Throat congested, chest clear, abdominal soft non-tender..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Primary Clinical Diagnosis <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={diagnosis}
                  onChange={(e) => setDiagnosis(e.target.value)}
                  placeholder="e.g. Acute Upper Respiratory Tract Infection (URTI) with Pyrexia"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 font-semibold text-blue-900 bg-blue-50/30"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Treatment Plan / Procedures Done
                  </label>
                  <textarea
                    rows={2}
                    value={treatmentPlan}
                    onChange={(e) => setTreatmentPlan(e.target.value)}
                    placeholder="Oral antibiotic course, hydration therapy, nebulization..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Doctor Advice & Dietary Restrictions
                  </label>
                  <textarea
                    rows={2}
                    value={advice}
                    onChange={(e) => setAdvice(e.target.value)}
                    placeholder="Drink plenty of warm fluids, steam inhalation twice daily, rest..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-semibold text-slate-700">
                      Scheduled Follow-up Date
                    </label>
                    <span className="text-[10px] text-slate-400 font-medium">Quick Suggestions:</span>
                  </div>

                  {/* Quick suggestion pills based on duration */}
                  <div className="flex flex-wrap gap-1 mb-2">
                    {[
                      { label: '+3 Days', days: 3 },
                      { label: '+5 Days', days: 5 },
                      { label: '+7 Days (1 Wk)', days: 7 },
                      { label: '+10 Days', days: 10 },
                      { label: '+14 Days (2 Wks)', days: 14 },
                      { label: '+1 Month', days: 30 },
                    ].map((item) => {
                      const d = new Date();
                      d.setDate(d.getDate() + item.days);
                      const targetStr = d.toISOString().split('T')[0];
                      const isSelected = followUpDate === targetStr;

                      return (
                        <button
                          key={item.label}
                          type="button"
                          onClick={() => setFollowUpDate(targetStr)}
                          className={`px-2 py-0.5 rounded-lg text-[11px] font-semibold transition cursor-pointer border ${
                            isSelected
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                          }`}
                        >
                          {item.label}
                        </button>
                      );
                    })}
                    {followUpDate && (
                      <button
                        type="button"
                        onClick={() => setFollowUpDate('')}
                        className="px-1.5 py-0.5 text-[11px] text-slate-400 hover:text-slate-600 font-medium"
                        title="Clear Follow-up date"
                      >
                        Clear
                      </button>
                    )}
                  </div>

                  <input
                    type="date"
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Follow-up date automatically records into the Follow-ups list for patient tracking.
                  </p>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Attending Physician
                  </label>
                  <input
                    type="text"
                    disabled
                    value={doctorName}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-xs text-slate-600"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-3">
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs hover:shadow transition flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{loading ? 'Saving Notes...' : 'Save Consultation Record'}</span>
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Right 1 Col: Context Panel (Patient Vitals & Past Consultations) */}
        <div className="space-y-6">
          {/* Active Patient Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs text-xs space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-sm">
                {currentPatient?.fullName.charAt(0) || 'P'}
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">{currentPatient?.fullName || 'No Patient'}</h3>
                <p className="text-slate-400 font-mono text-[11px]">{currentPatient?.patientId}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-[11px]">
              <div>
                <span className="text-slate-400 block">Age & Gender</span>
                <span className="font-semibold text-slate-800">{currentPatient?.age}y • {currentPatient?.gender}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Blood Group</span>
                <span className="font-semibold text-rose-600">{currentPatient?.bloodGroup || 'N/A'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Contact Phone</span>
                <span className="font-semibold text-slate-800">{currentPatient?.phone}</span>
              </div>
              <div>
                <span className="text-slate-400 block">City</span>
                <span className="font-semibold text-slate-800">{currentPatient?.city || 'Local'}</span>
              </div>
            </div>
          </div>

          {/* Latest Vitals Reading */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs text-xs space-y-2.5">
            <h3 className="font-bold text-slate-900 flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-emerald-600" />
              <span>Latest Vital Signs</span>
            </h3>

            {patientLatestVital ? (
              <div className="space-y-2 pt-1">
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">Blood Pressure:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {patientLatestVital.bpSystolic}/{patientLatestVital.bpDiastolic} mmHg
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">Pulse:</span>
                  <span className="font-mono font-bold text-slate-800">{patientLatestVital.pulse || '--'} bpm</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">SpO2 Oxygen:</span>
                  <span className="font-mono font-bold text-slate-800">{patientLatestVital.spo2 || '--'}%</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">Temp / BMI:</span>
                  <span className="font-bold text-slate-800">
                    {patientLatestVital.temperature || '--'}°F • BMI {patientLatestVital.bmi || '--'}
                  </span>
                </div>
                <p className="text-[10px] text-slate-400">
                  Recorded: {patientLatestVital.recordedAt.split('T')[0]} by {patientLatestVital.recordedBy}
                </p>
              </div>
            ) : (
              <p className="text-slate-400 text-xs py-2">No vitals on record for this patient.</p>
            )}
          </div>

          {/* Previous Consultations History */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs text-xs space-y-3">
            <h3 className="font-bold text-slate-900 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-blue-600" />
              <span>Previous Consultations ({patientPastConsultations.length})</span>
            </h3>

            {patientPastConsultations.length === 0 ? (
              <p className="text-slate-400 text-xs py-2">No past visits recorded.</p>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {patientPastConsultations.slice(0, 4).map((c) => (
                  <div key={c.id} className="p-2.5 rounded-xl border border-slate-100 bg-slate-50 space-y-1">
                    <div className="flex justify-between text-[11px]">
                      <span className="font-bold text-slate-900">{c.diagnosis}</span>
                      <span className="text-slate-400 font-mono">{c.createdAt.split('T')[0]}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 line-clamp-1">{c.chiefComplaint}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
