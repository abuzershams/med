import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Invoice, InvoiceItem, Patient, Payment } from '../../types';
import { WhatsAppButton } from '../common/WhatsAppButton';
import {
  Receipt,
  Plus,
  Search,
  Printer,
  DollarSign,
  AlertCircle,
  CheckCircle2,
  X,
  CreditCard,
  Trash2,
  Save,
  Eye,
} from 'lucide-react';
import { cur } from '../../local/money';

interface BillingViewProps {
  invoices: Invoice[];
  patients: Patient[];
  onOpenPrintModal: (invoice: Invoice) => void;
  onCreateInvoice: (data: Omit<Invoice, 'id' | 'invoiceNumber' | 'createdAt' | 'updatedAt'>) => Promise<Invoice>;
  onUpdateInvoicePayment: (invoiceId: string, amount: number, method: any, staffName: string) => Promise<void>;
  userName: string;
}

export const BillingView: React.FC<BillingViewProps> = ({
  invoices,
  patients,
  onOpenPrintModal,
  onCreateInvoice,
  onUpdateInvoicePayment,
  userName,
}) => {
  const { clinic } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [payModalInvoice, setPayModalInvoice] = useState<Invoice | null>(null);

  // New Invoice Form
  const [patientId, setPatientId] = useState('');
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split('T')[0]);
  const [items, setItems] = useState<InvoiceItem[]>([
    {
      id: 'item-1',
      description: 'General OPD Doctor Consultation',
      type: 'consultation',
      quantity: 1,
      unitPrice: 0,
      amount: 0,
    },
  ]);
  const [discount, setDiscount] = useState<number>(0);
  const [tax, setTax] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(50.0);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'upi' | 'card' | 'bank_transfer'>('cash');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  // Partial Payment Form
  const [partialPaymentAmount, setPartialPaymentAmount] = useState<number>(0);
  const [partialPaymentMethod, setPartialPaymentMethod] = useState<'cash' | 'upi' | 'card' | 'bank_transfer'>('cash');
  const [payLoading, setPayLoading] = useState(false);

  // Totals calculations
  const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
  const totalAmount = Math.max(0, subtotal - (discount || 0) + (tax || 0));
  const dueAmount = Math.max(0, totalAmount - (paidAmount || 0));

  const totalBilled = invoices.reduce((sum, i) => sum + i.total, 0);
  const totalCollected = invoices.reduce((sum, i) => sum + i.paidAmount, 0);
  const totalOutstanding = invoices.reduce((sum, i) => sum + i.dueAmount, 0);

  const handleAddItem = () => {
    setItems([
      ...items,
      {
        id: 'item-' + Date.now(),
        description: 'Medical Procedure / Service',
        type: 'service',
        quantity: 1,
        unitPrice: 0,
        amount: 0,
      },
    ]);
  };

  const handleUpdateItem = (index: number, field: keyof InvoiceItem, val: any) => {
    const updated = [...items];
    const item = { ...updated[index], [field]: val };
    if (field === 'quantity' || field === 'unitPrice') {
      const q = field === 'quantity' ? Number(val) : item.quantity;
      const u = field === 'unitPrice' ? Number(val) : item.unitPrice;
      item.amount = (q || 0) * (u || 0);
    }
    updated[index] = item;
    setItems(updated);
  };

  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) return;
    setItems(items.filter((_, idx) => idx !== index));
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const p = patients.find((pat) => pat.id === patientId);
    if (!p) {
      alert('Please select a patient.');
      return;
    }
    if (items.some((it) => !it.description.trim() || !(it.quantity > 0) || it.unitPrice < 0)) {
      alert('Please check the bill items: name is required, quantity must be at least 1 and price cannot be negative.');
      return;
    }
    if (totalAmount <= 0) {
      alert('Total bill amount must be greater than zero.');
      return;
    }
    if ((Number(paidAmount) || 0) < 0 || (Number(paidAmount) || 0) > totalAmount) {
      alert('Paid amount cannot be negative or more than the total bill.');
      return;
    }

    setLoading(true);
    try {
      const status = dueAmount === 0 ? 'paid' : paidAmount > 0 ? 'partial' : 'pending';
      const created = await onCreateInvoice({
        patientId: p.id,
        patientName: p.fullName,
        patientPhone: p.phone,
        date: invoiceDate,
        items,
        subtotal,
        discount: Number(discount) || 0,
        tax: Number(tax) || 0,
        total: totalAmount,
        paidAmount: Number(paidAmount) || 0,
        dueAmount,
        status,
        paymentMethod,
        notes: notes.trim() || undefined,
      });

      setIsCreateModalOpen(false);
      if (clinic?.autoPrintInvoice || clinic?.autoPrintOnSave) {
        onOpenPrintModal(created);
      }
    } catch (err: any) {
      alert('Error creating invoice: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRecordDuePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModalInvoice || partialPaymentAmount <= 0) return;

    setPayLoading(true);
    try {
      await onUpdateInvoicePayment(
        payModalInvoice.id,
        partialPaymentAmount,
        partialPaymentMethod,
        userName
      );
      setPayModalInvoice(null);
    } catch (err: any) {
      alert('Error updating payment: ' + err.message);
    } finally {
      setPayLoading(false);
    }
  };

  const filteredInvoices = invoices.filter((inv) => {
    const term = searchTerm.toLowerCase();
    const matchTerm =
      inv.invoiceNumber.toLowerCase().includes(term) ||
      inv.patientName.toLowerCase().includes(term);
    const matchStatus = statusFilter === 'all' || inv.status === statusFilter;
    return matchTerm && matchStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Receipt className="w-5 h-5 text-amber-600" />
            <span>Clinic Billing & Invoices</span>
          </h2>
          <p className="text-xs text-slate-500">
            Generate itemized clinic bills, track revenue collections, receipts & payment dues
          </p>
        </div>

        <button
          onClick={() => {
            setPaidAmount(50);
            setIsCreateModalOpen(true);
          }}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs hover:shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>+ Create Invoice</span>
        </button>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold">Total Billed</span>
          <p className="text-2xl font-extrabold text-slate-900 mt-1">
            {cur()}{totalBilled.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <span className="text-[11px] text-slate-400">Total invoice value</span>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold">Revenue Collected</span>
          <p className="text-2xl font-extrabold text-emerald-600 mt-1">
            {cur()}{totalCollected.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <span className="text-[11px] text-emerald-700 font-medium">Successfully settled</span>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold">Outstanding Dues</span>
          <p className="text-2xl font-extrabold text-rose-600 mt-1">
            {cur()}{totalOutstanding.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <span className="text-[11px] text-rose-700 font-medium">Unpaid customer balance</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by invoice number (INV-...), patient name..."
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 font-semibold"
        >
          <option value="all">All Payment Statuses</option>
          <option value="paid">Fully Paid</option>
          <option value="partial">Partially Paid</option>
          <option value="pending">Pending</option>
        </select>
      </div>

      {/* Invoices Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredInvoices.length === 0 ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            <Receipt className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="font-semibold text-slate-600 text-sm">No invoices found</p>
            <p className="mt-1 text-slate-400">Click "+ Create Invoice" to generate a clinic bill.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[11px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Invoice #</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Patient</th>
                  <th className="py-3 px-4">Total Amount</th>
                  <th className="py-3 px-4">Paid</th>
                  <th className="py-3 px-4">Due Balance</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-amber-50/30 transition">
                    <td className="py-3.5 px-4 font-mono font-bold text-amber-700">
                      {inv.invoiceNumber}
                    </td>

                    <td className="py-3.5 px-4 text-slate-500 font-mono">
                      {inv.date}
                    </td>

                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      {inv.patientName}
                    </td>

                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      {cur()}{inv.total.toFixed(2)}
                    </td>

                    <td className="py-3.5 px-4 font-semibold text-emerald-700">
                      {cur()}{inv.paidAmount.toFixed(2)}
                    </td>

                    <td className="py-3.5 px-4 font-bold text-rose-600">
                      {cur()}{inv.dueAmount.toFixed(2)}
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                          inv.status === 'paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : inv.status === 'partial'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {inv.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {(() => {
                          const pPhone = inv.patientPhone || patients.find((p) => p.id === inv.patientId)?.phone;
                          if (!pPhone) return null;
                          const waText = `Hello ${inv.patientName},\n\nYour invoice from ${clinic?.name || 'Clinic'}:\nInvoice: ${inv.invoiceNumber}\nTotal: ${cur()}${inv.total.toFixed(2)}\nPaid: ${cur()}${inv.paidAmount.toFixed(2)}\nDue: ${cur()}${inv.dueAmount.toFixed(2)}\nStatus: ${inv.status.toUpperCase()}\n\nThank you.`;
                          return (
                            <WhatsAppButton
                              phone={pPhone}
                              patientName={inv.patientName}
                              customText={waText}
                              size="sm"
                            />
                          );
                        })()}

                        {inv.dueAmount > 0 && (
                          <button
                            onClick={() => {
                              setPayModalInvoice(inv);
                              setPartialPaymentAmount(inv.dueAmount);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold transition cursor-pointer text-xs"
                            title="Collect Due Payment"
                          >
                            + Pay Due
                          </button>
                        )}

                        <button
                          onClick={() => onOpenPrintModal(inv)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer"
                          title="View Invoice Slip"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => onOpenPrintModal(inv)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold flex items-center gap-1 transition cursor-pointer text-xs"
                          title="Print or Save PDF"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Print Bill</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* CREATE INVOICE MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
          <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-amber-600" />
                <h3 className="font-bold text-sm text-slate-900">Create Patient Invoice</h3>
              </div>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-6 overflow-y-auto space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Select Patient <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={patientId}
                    onChange={(e) => setPatientId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="">-- Choose Patient --</option>
                    {patients.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.fullName} ({p.patientId}) - {p.phone}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Billing Date</label>
                  <input
                    type="date"
                    value={invoiceDate}
                    onChange={(e) => setInvoiceDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Line Items */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                    Invoice Line Items ({items.length})
                  </span>
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 hover:bg-amber-100 font-semibold text-xs transition"
                  >
                    + Add Item
                  </button>
                </div>

                <div className="space-y-2">
                  {items.map((item, idx) => (
                    <div
                      key={item.id}
                      className="grid grid-cols-12 gap-2 bg-white p-2.5 rounded-xl border border-slate-200 items-center"
                    >
                      <div className="col-span-5">
                        <input
                          type="text"
                          required
                          value={item.description}
                          onChange={(e) => handleUpdateItem(idx, 'description', e.target.value)}
                          placeholder="Description"
                          className="w-full px-2 py-1 rounded border border-slate-200 text-xs font-medium"
                        />
                      </div>
                      <div className="col-span-2">
                        <select
                          value={item.type}
                          onChange={(e) => handleUpdateItem(idx, 'type', e.target.value)}
                          className="w-full px-1.5 py-1 rounded border border-slate-200 text-xs bg-white uppercase text-[10px]"
                        >
                          <option value="consultation">Consultation</option>
                          <option value="service">Service</option>
                          <option value="procedure">Procedure</option>
                          <option value="medicine">Medicine</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                      <div className="col-span-1">
                        <input
                          type="number"
                          min={1}
                          value={item.quantity}
                          onChange={(e) => handleUpdateItem(idx, 'quantity', e.target.value)}
                          className="w-full px-1.5 py-1 rounded border border-slate-200 text-xs text-center"
                        />
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          step="0.1"
                          value={item.unitPrice}
                          onChange={(e) => handleUpdateItem(idx, 'unitPrice', e.target.value)}
                          className="w-full px-2 py-1 rounded border border-slate-200 text-xs font-mono text-right"
                        />
                      </div>
                      <div className="col-span-1 font-mono font-bold text-right text-slate-800">
                        {cur()}{item.amount.toFixed(1)}
                      </div>
                      <div className="col-span-1 flex justify-end">
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(idx)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Financial Calculation Box */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Payment Method</label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                    >
                      <option value="cash">Cash Payment</option>
                      <option value="upi">UPI / QR Code</option>
                      <option value="card">Credit / Debit Card</option>
                      <option value="bank_transfer">Bank Transfer</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Invoice Notes</label>
                    <input
                      type="text"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="e.g. Paid via Cash at Counter"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal:</span>
                    <span className="font-mono font-semibold">{cur()}{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-600">Discount ($):</span>
                    <input
                      type="number"
                      min={0}
                      value={discount}
                      onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)}
                      className="w-24 px-2 py-1 rounded border border-slate-300 text-right font-mono"
                    />
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-600">Tax ($):</span>
                    <input
                      type="number"
                      min={0}
                      value={tax}
                      onChange={(e) => setTax(parseFloat(e.target.value) || 0)}
                      className="w-24 px-2 py-1 rounded border border-slate-300 text-right font-mono"
                    />
                  </div>
                  <div className="flex justify-between font-bold text-sm text-slate-900 pt-2 border-t border-slate-200">
                    <span>Net Total:</span>
                    <span className="font-mono">{cur()}{totalAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-200 text-emerald-700 font-bold">
                    <span>Amount Paid Now:</span>
                    <input
                      type="number"
                      min={0}
                      max={totalAmount}
                      value={paidAmount}
                      onChange={(e) => setPaidAmount(parseFloat(e.target.value) || 0)}
                      className="w-28 px-2 py-1 rounded border border-slate-300 text-right font-mono text-emerald-800 font-bold bg-white"
                    />
                  </div>
                  <div className="flex justify-between font-bold text-rose-600 pt-1">
                    <span>Balance Due:</span>
                    <span className="font-mono">{cur()}{dueAmount.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{loading ? 'Processing...' : 'Generate Bill & Receipt'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* COLLECT DUE PAYMENT MODAL */}
      {payModalInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm text-slate-900">
                Collect Payment for {payModalInvoice.invoiceNumber}
              </h3>
              <button onClick={() => setPayModalInvoice(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRecordDuePayment} className="p-6 space-y-4 text-xs">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl">
                <p className="font-bold text-amber-900">{payModalInvoice.patientName}</p>
                <p className="text-amber-800">
                  Total Bill: {cur()}{payModalInvoice.total.toFixed(2)} • Current Due: {cur()}{payModalInvoice.dueAmount.toFixed(2)}
                </p>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Payment Amount to Collect ($) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="number"
                  required
                  step="0.1"
                  min={1}
                  max={payModalInvoice.dueAmount}
                  value={partialPaymentAmount}
                  onChange={(e) => setPartialPaymentAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-mono font-bold text-emerald-700"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Payment Method</label>
                <select
                  value={partialPaymentMethod}
                  onChange={(e) => setPartialPaymentMethod(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white font-medium"
                >
                  <option value="cash">Cash</option>
                  <option value="upi">UPI / QR Code</option>
                  <option value="card">Card</option>
                  <option value="bank_transfer">Bank Transfer</option>
                </select>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setPayModalInvoice(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={payLoading}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition flex items-center gap-1.5"
                >
                  <span>{payLoading ? 'Recording...' : 'Confirm Payment'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
