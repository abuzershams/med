import React, { useState } from 'react';
import { FollowUp, Patient } from '../../types';
import { addFollowUp, updateFollowUp, recordAudit } from '../../services/db';
import { useAuth } from '../../context/AuthContext';
import { WhatsAppButton } from '../common/WhatsAppButton';
import {
  CalendarClock,
  Search,
  Plus,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  User,
  Calendar,
  Phone,
  X,
  Save,
  MessageSquare,
} from 'lucide-react';

interface FollowupsViewProps {
  followUps: FollowUp[];
  patients: Patient[];
  onSelectPatient: (patient: Patient) => void;
  onNewConsultation?: (patient: Patient) => void;
}

export function FollowupsView({
  followUps,
  patients,
  onSelectPatient,
  onNewConsultation,
}: FollowupsViewProps) {
  const { currentUser, clinic } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'today' | 'upcoming' | 'overdue' | 'all'>('today');

  // Add Follow-up modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [patientId, setPatientId] = useState('');
  const [scheduledDate, setScheduledDate] = useState(
    new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [doctorName, setDoctorName] = useState(clinic?.doctorName || 'Dr. Doctor');
  const [reason, setReason] = useState('Routine review / medication evaluation');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const todayStr = new Date().toISOString().split('T')[0];

  const handleStatusChange = async (followUp: FollowUp, newStatus: FollowUp['status']) => {
    try {
      await updateFollowUp(followUp.id, { status: newStatus });
      await recordAudit(
        'Update Follow-up Status',
        `Changed follow-up for ${followUp.patientName} to ${newStatus}`,
        currentUser?.fullName || 'Staff',
        currentUser?.role || 'staff',
        'follow_up',
        followUp.id
      );
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientId || !scheduledDate) {
      setError('Please select a patient and scheduled date');
      return;
    }

    const patient = patients.find((p) => p.id === patientId);
    if (!patient) return;

    setIsSubmitting(true);
    try {
      await addFollowUp({
        patientId,
        patientName: patient.fullName,
        patientPhone: patient.phone,
        doctorName: doctorName.trim(),
        scheduledDate,
        reason: reason.trim(),
        status: 'scheduled',
        notes: notes.trim(),
      });

      await recordAudit(
        'Schedule Follow-up',
        `Scheduled follow-up on ${scheduledDate} for ${patient.fullName}`,
        currentUser?.fullName || 'Staff',
        currentUser?.role || 'staff',
        'follow_up'
      );

      setIsModalOpen(false);
      setPatientId('');
      setReason('Routine review / medication evaluation');
      setNotes('');
      setError('');
    } catch (err: any) {
      setError(err.message || 'Failed to schedule follow-up');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Group counts
  const todayCount = followUps.filter(
    (f) => f.scheduledDate === todayStr && f.status === 'scheduled'
  ).length;
  const upcomingCount = followUps.filter(
    (f) => f.scheduledDate > todayStr && f.status === 'scheduled'
  ).length;
  const overdueCount = followUps.filter(
    (f) => f.scheduledDate < todayStr && f.status === 'scheduled'
  ).length;

  const filteredFollowUps = followUps.filter((f) => {
    const matchesSearch =
      f.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.patientPhone.includes(searchTerm) ||
      f.reason.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (activeTab === 'today') {
      return f.scheduledDate === todayStr;
    }
    if (activeTab === 'upcoming') {
      return f.scheduledDate > todayStr && f.status === 'scheduled';
    }
    if (activeTab === 'overdue') {
      return f.scheduledDate < todayStr && f.status === 'scheduled';
    }
    return true; // 'all'
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <CalendarClock className="w-7 h-7 text-teal-600" />
            Patient Follow-ups & Reminders
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Track scheduled reviews, send WhatsApp reminders, and follow up on patient progress
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition font-medium shadow-sm cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          Schedule Follow-up
        </button>
      </div>

      {/* Quick Summary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div
          onClick={() => setActiveTab('today')}
          className={`p-4 rounded-xl border transition cursor-pointer ${
            activeTab === 'today'
              ? 'bg-teal-50 border-teal-300 ring-2 ring-teal-500/20'
              : 'bg-white border-slate-200 hover:border-teal-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-teal-700">
              Due Today
            </span>
            <Clock className="w-4 h-4 text-teal-600" />
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{todayCount}</p>
          <p className="text-xs text-slate-500 mt-0.5">Patients scheduled today</p>
        </div>

        <div
          onClick={() => setActiveTab('upcoming')}
          className={`p-4 rounded-xl border transition cursor-pointer ${
            activeTab === 'upcoming'
              ? 'bg-blue-50 border-blue-300 ring-2 ring-blue-500/20'
              : 'bg-white border-slate-200 hover:border-blue-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-blue-700">
              Upcoming
            </span>
            <Calendar className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{upcomingCount}</p>
          <p className="text-xs text-slate-500 mt-0.5">Future scheduled reviews</p>
        </div>

        <div
          onClick={() => setActiveTab('overdue')}
          className={`p-4 rounded-xl border transition cursor-pointer ${
            activeTab === 'overdue'
              ? 'bg-amber-50 border-amber-300 ring-2 ring-amber-500/20'
              : 'bg-white border-slate-200 hover:border-amber-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-700">
              Overdue
            </span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{overdueCount}</p>
          <p className="text-xs text-slate-500 mt-0.5">Past dates pending check-in</p>
        </div>

        <div
          onClick={() => setActiveTab('all')}
          className={`p-4 rounded-xl border transition cursor-pointer ${
            activeTab === 'all'
              ? 'bg-slate-100 border-slate-400 ring-2 ring-slate-400/20'
              : 'bg-white border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-700">
              All Follow-ups
            </span>
            <CalendarClock className="w-4 h-4 text-slate-600" />
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{followUps.length}</p>
          <p className="text-xs text-slate-500 mt-0.5">Total recorded follow-ups</p>
        </div>
      </div>

      {/* Search and Tabs */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-4 justify-between">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search follow-ups by patient name, phone, or reason..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm"
          />
        </div>

        <div className="flex bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('today')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
              activeTab === 'today' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Today ({todayCount})
          </button>
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
              activeTab === 'upcoming' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Upcoming ({upcomingCount})
          </button>
          <button
            onClick={() => setActiveTab('overdue')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
              activeTab === 'overdue' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Overdue ({overdueCount})
          </button>
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
              activeTab === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All
          </button>
        </div>
      </div>

      {/* Follow-ups List */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        {filteredFollowUps.length === 0 ? (
          <div className="p-12 text-center">
            <CalendarClock className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-semibold text-slate-800">No follow-ups found</h3>
            <p className="text-sm text-slate-500 mt-1 max-w-sm mx-auto">
              There are no follow-ups scheduled for this filter view.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredFollowUps.map((flw) => {
              const patient = patients.find((p) => p.id === flw.patientId);
              const isOverdue = flw.scheduledDate < todayStr && flw.status === 'scheduled';
              const isToday = flw.scheduledDate === todayStr;

              return (
                <div
                  key={flw.id}
                  className="p-4 hover:bg-slate-50 transition flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-3.5">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                        flw.status === 'completed'
                          ? 'bg-emerald-100 text-emerald-700'
                          : isOverdue
                          ? 'bg-amber-100 text-amber-700'
                          : isToday
                          ? 'bg-teal-100 text-teal-700'
                          : 'bg-blue-100 text-blue-700'
                      }`}
                    >
                      {flw.status === 'completed' ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : (
                        <CalendarClock className="w-5 h-5" />
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <button
                          onClick={() => patient && onSelectPatient(patient)}
                          className="font-bold text-slate-900 hover:text-teal-600 text-base cursor-pointer"
                        >
                          {flw.patientName}
                        </button>
                        <span className="text-xs text-slate-400">({flw.patientPhone})</span>

                        {isToday && flw.status === 'scheduled' && (
                          <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-teal-100 text-teal-800">
                            Today
                          </span>
                        )}
                        {isOverdue && (
                          <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">
                            Overdue
                          </span>
                        )}
                        {flw.status === 'completed' && (
                          <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                            Completed
                          </span>
                        )}
                        {flw.status === 'cancelled' && (
                          <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600">
                            Cancelled
                          </span>
                        )}
                      </div>

                      <p className="text-sm text-slate-700 mt-1 font-medium">{flw.reason}</p>

                      <div className="mt-1 flex items-center gap-4 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5" />
                          Scheduled: <strong className="text-slate-700">{flw.scheduledDate}</strong>
                        </span>
                        <span>Doctor: {flw.doctorName}</span>
                      </div>

                      {flw.notes && (
                        <p className="mt-1.5 text-xs text-slate-500 bg-slate-50 p-1.5 rounded inline-block">
                          Note: {flw.notes}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 self-end md:self-center">
                    {/* WhatsApp Reminder Button */}
                    <WhatsAppButton
                      phone={flw.patientPhone}
                      patientName={flw.patientName}
                      messageType="followup"
                      customText={`Hello ${flw.patientName}, this is a gentle reminder from ${clinic?.name || 'Clinic'} for your scheduled follow-up on ${flw.scheduledDate} with ${flw.doctorName}. Please let us know if you need to reschedule.`}
                      size="sm"
                    />

                    {/* Consultation Trigger */}
                    {onNewConsultation && patient && (
                      <button
                        onClick={() => onNewConsultation(patient)}
                        className="px-2.5 py-1.5 text-xs font-medium text-teal-700 bg-teal-50 hover:bg-teal-100 rounded-lg transition"
                      >
                        Start OPD
                      </button>
                    )}

                    {/* Status Toggle buttons */}
                    {flw.status === 'scheduled' ? (
                      <button
                        onClick={() => handleStatusChange(flw, 'completed')}
                        className="px-2.5 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition inline-flex items-center gap-1 cursor-pointer"
                        title="Mark as completed"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Mark Done
                      </button>
                    ) : (
                      <button
                        onClick={() => handleStatusChange(flw, 'scheduled')}
                        className="px-2.5 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition cursor-pointer"
                      >
                        Re-open
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Schedule Follow-up Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <CalendarClock className="w-5 h-5 text-teal-600" />
                Schedule Patient Follow-up
              </h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-rose-700 text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            <form onSubmit={handleCreateSubmit} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Patient <span className="text-rose-500">*</span>
                </label>
                <select
                  required
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                >
                  <option value="">Select Patient...</option>
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.fullName} ({p.patientId}) - {p.phone}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Follow-up Date <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  required
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Doctor Name
                </label>
                <input
                  type="text"
                  required
                  value={doctorName}
                  onChange={(e) => setDoctorName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Reason / Purpose
                </label>
                <input
                  type="text"
                  placeholder="e.g. Suture removal, BP check, Medication review"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Special Instructions / Notes
                </label>
                <textarea
                  rows={2}
                  placeholder="Remind patient to come fasting, bring previous reports, etc."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 text-sm font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 text-sm font-medium shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? 'Scheduling...' : 'Save Follow-up'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
