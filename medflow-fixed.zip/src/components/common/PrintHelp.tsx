import React from 'react';
import { Info } from 'lucide-react';
import { isPhone } from '../../local/printing';

/** Short "how do I print" instructions. Shown inside the invoice / prescription preview. Never printed. */
export const PrintHelp: React.FC = () => {
  const phone = isPhone();
  const desktop = !phone && !!window.electronAPI;

  return (
    <div className="no-print print:hidden px-4 py-2 bg-sky-50 border-b border-sky-200 text-[11px] leading-snug text-sky-900 flex gap-2 shrink-0">
      <Info className="w-4 h-4 shrink-0 text-sky-600 mt-0.5" />
      {phone ? (
        <p>
          <b>Printing from phone:</b> tap <b>Print</b>, a PDF is made and the Share menu opens. Choose your
          printer app (Print / HP Smart / Epson iPrint / Mopria) or save the PDF to Files/Drive and print it from a
          computer. Phone and Wi-Fi printer must be on the same Wi-Fi network. No printer? Use{' '}
          <b>WhatsApp</b> or <b>Download PDF</b>.
        </p>
      ) : desktop ? (
        <p>
          <b>Printing from computer:</b> click <b>Print</b> and pick your printer in the window that opens (printer must be
          switched ON and added in Windows). No printer? choose <b>Microsoft Print to PDF</b> there, or click{' '}
          <b>Download PDF</b>. Everything works without internet.
        </p>
      ) : (
        <p>
          Click <b>Print</b> and choose a printer, or choose <b>Save as PDF</b> in the print window.
        </p>
      )}
    </div>
  );
};
