import React, { useState, useEffect } from 'react';
import { Patient, Appointment, Prescription, Invoice } from '../../types';
import { Search, X, User, Calendar, FileText, Receipt, ArrowRight } from 'lucide-react';
import { cur } from '../../local/money';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  patients: Patient[];
  appointments: Appointment[];
  prescriptions: Prescription[];
  invoices: Invoice[];
  onSelectResult: (type: 'patient' | 'appointment' | 'prescription' | 'invoice', item: any) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  patients,
  appointments,
  prescriptions,
  invoices,
  onSelectResult,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!isOpen) return null;

  const term = searchTerm.trim().toLowerCase();

  const matchedPatients = term
    ? patients.filter(
        (p) =>
          p.fullName.toLowerCase().includes(term) ||
          p.patientId.toLowerCase().includes(term) ||
          p.phone.includes(term)
      ).slice(0, 5)
    : [];

  const matchedAppointments = term
    ? appointments.filter(
        (a) =>
          a.patientName.toLowerCase().includes(term) ||
          a.patientPhone.includes(term) ||
          a.reason.toLowerCase().includes(term)
      ).slice(0, 4)
    : [];

  const matchedPrescriptions = term
    ? prescriptions.filter(
        (rx) =>
          rx.prescriptionNumber.toLowerCase().includes(term) ||
          rx.patientName.toLowerCase().includes(term) ||
          rx.diagnosis.toLowerCase().includes(term)
      ).slice(0, 4)
    : [];

  const matchedInvoices = term
    ? invoices.filter(
        (inv) =>
          inv.invoiceNumber.toLowerCase().includes(term) ||
          inv.patientName.toLowerCase().includes(term)
      ).slice(0, 4)
    : [];

  const totalResults =
    matchedPatients.length +
    matchedAppointments.length +
    matchedPrescriptions.length +
    matchedInvoices.length;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-start justify-center pt-16 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 flex items-center gap-3">
          <Search className="w-5 h-5 text-blue-600 shrink-0" />
          <input
            type="text"
            autoFocus
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search patients by name, ID, mobile, prescription, invoice..."
            className="w-full text-sm outline-none text-slate-800 placeholder-slate-400"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-600 px-2 py-1 rounded-md font-medium transition"
          >
            ESC
          </button>
        </div>

        {/* Results Area */}
        <div className="overflow-y-auto p-4 space-y-4">
          {!term && (
            <div className="py-8 text-center text-slate-400 text-xs">
              <p>Type keywords to search across Patients, Appointments, Prescriptions, and Invoices.</p>
              <p className="mt-1 text-[11px] text-slate-400">Examples: "John", "PAT-1001", "Fever", "INV-1001", "98765"</p>
            </div>
          )}

          {term && totalResults === 0 && (
            <div className="py-8 text-center text-slate-500 text-sm">
              No matching records found for "{searchTerm}".
            </div>
          )}

          {/* Patients */}
          {matchedPatients.length > 0 && (
            <div>
              <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-blue-500" />
                <span>Patients ({matchedPatients.length})</span>
              </h4>
              <div className="space-y-1">
                {matchedPatients.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      onSelectResult('patient', p);
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-xl hover:bg-blue-50/70 text-left transition flex items-center justify-between border border-transparent hover:border-blue-200 group"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-slate-900 group-hover:text-blue-700">
                          {p.fullName}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">
                          {p.patientId}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {p.age} yrs • {p.gender}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Phone: {p.phone} • Blood: {p.bloodGroup || 'N/A'} • {p.city || 'Local'}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-blue-600" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Appointments */}
          {matchedAppointments.length > 0 && (
            <div>
              <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                <span>Appointments ({matchedAppointments.length})</span>
              </h4>
              <div className="space-y-1">
                {matchedAppointments.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => {
                      onSelectResult('appointment', a);
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-xl hover:bg-indigo-50/70 text-left transition flex items-center justify-between border border-transparent hover:border-indigo-200 group"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-slate-900 group-hover:text-indigo-700">
                          {a.patientName}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 font-medium capitalize">
                          {a.status}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Date: {a.date} at {a.time} • Reason: {a.reason}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-indigo-600" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Prescriptions */}
          {matchedPrescriptions.length > 0 && (
            <div>
              <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-emerald-500" />
                <span>Prescriptions ({matchedPrescriptions.length})</span>
              </h4>
              <div className="space-y-1">
                {matchedPrescriptions.map((rx) => (
                  <button
                    key={rx.id}
                    onClick={() => {
                      onSelectResult('prescription', rx);
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-xl hover:bg-emerald-50/70 text-left transition flex items-center justify-between border border-transparent hover:border-emerald-200 group"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-slate-900 group-hover:text-emerald-700">
                          {rx.prescriptionNumber}
                        </span>
                        <span className="text-xs text-slate-600">
                          for {rx.patientName}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Diagnosis: {rx.diagnosis} • {rx.medicines.length} medicines
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-emerald-600" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Invoices */}
          {matchedInvoices.length > 0 && (
            <div>
              <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Receipt className="w-3.5 h-3.5 text-amber-500" />
                <span>Invoices ({matchedInvoices.length})</span>
              </h4>
              <div className="space-y-1">
                {matchedInvoices.map((inv) => (
                  <button
                    key={inv.id}
                    onClick={() => {
                      onSelectResult('invoice', inv);
                      onClose();
                    }}
                    className="w-full p-2.5 rounded-xl hover:bg-amber-50/70 text-left transition flex items-center justify-between border border-transparent hover:border-amber-200 group"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-slate-900 group-hover:text-amber-700">
                          {inv.invoiceNumber}
                        </span>
                        <span className="text-xs text-slate-600">
                          {inv.patientName}
                        </span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium uppercase ${
                          inv.status === 'paid'
                            ? 'bg-emerald-100 text-emerald-700'
                            : inv.status === 'partial'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-rose-100 text-rose-700'
                        }`}>
                          {inv.status}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Total: {cur()}{inv.total.toFixed(2)} • Due: {cur()}{inv.dueAmount.toFixed(2)}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-amber-600" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
