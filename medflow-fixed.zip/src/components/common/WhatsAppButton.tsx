import React from 'react';
import { MessageCircle } from 'lucide-react';

interface WhatsAppButtonProps {
  phone: string;
  patientName?: string;
  messageType?: 'appointment' | 'followup' | 'prescription' | 'invoice' | 'receipt' | 'general';
  customText?: string;
  size?: 'sm' | 'md';
  className?: string;
}

export const WhatsAppButton: React.FC<WhatsAppButtonProps> = ({
  phone,
  patientName = 'Patient',
  messageType = 'general',
  customText,
  size = 'md',
  className = '',
}) => {
  // Clean phone number: remove non-digits
  const cleanPhone = phone.replace(/[^0-9]/g, '');

  let defaultMessage = `Hello ${patientName}, this is from the clinic regarding your healthcare visit.`;

  if (messageType === 'appointment') {
    defaultMessage = `Hello ${patientName}, your appointment at our clinic has been scheduled. Please arrive 10 minutes before your slot.`;
  } else if (messageType === 'followup') {
    defaultMessage = `Hello ${patientName}, this is a gentle reminder for your scheduled medical follow-up consultation with the doctor.`;
  } else if (messageType === 'prescription') {
    defaultMessage = `Hello ${patientName}, your digital medical prescription has been prepared. Please follow all dosage instructions carefully.`;
  } else if (messageType === 'invoice') {
    defaultMessage = `Hello ${patientName}, your clinic invoice has been generated. Thank you for visiting us.`;
  } else if (messageType === 'receipt') {
    defaultMessage = `Hello ${patientName}, your payment has been successfully received. Thank you for your payment.`;
  }

  const finalMessage = customText || defaultMessage;
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(finalMessage)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center gap-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-medium transition shadow-sm hover:shadow ${
        size === 'sm' ? 'px-2 py-1 text-xs' : 'px-3 py-1.5 text-xs'
      } ${className}`}
      title="Contact patient via WhatsApp"
    >
      <MessageCircle className="w-3.5 h-3.5 fill-white text-emerald-500" />
      <span>WhatsApp</span>
    </a>
  );
};
