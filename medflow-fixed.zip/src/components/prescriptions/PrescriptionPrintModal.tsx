import { createPortal } from 'react-dom';
import React, { useEffect, useState, useRef } from 'react';
import { printPage, savePageAsPdf } from '../../local/printing';
import { PrintHelp } from '../common/PrintHelp';
import { Prescription, Clinic } from '../../types';
import { WhatsAppButton } from '../common/WhatsAppButton';
import {
  X,
  Printer,
  Download,
  Phone,
  MapPin,
  HeartPulse,
  AlertTriangle,
  Loader2,
  FileDown,
} from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas-pro';

interface PrescriptionPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  prescription: Prescription | null;
  clinic: Clinic | null;
  patientPhone?: string;
}

export const PrescriptionPrintModal: React.FC<PrescriptionPrintModalProps> = ({
  isOpen,
  onClose,
  prescription,
  clinic,
  patientPhone = '',
}) => {
  const [printError, setPrintError] = useState<string | null>(null);
  const [isPdfGenerating, setIsPdfGenerating] = useState(false);
  const printContentRef = useRef<HTMLDivElement>(null);

  // ESC key listener & browser back accessibility
  useEffect(() => {
    if (!isOpen) return;
    setPrintError(null);
    setIsPdfGenerating(false);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !prescription) return null;

  // Real, direct print handler: never checks physical printer existence!
  const handlePrint = async (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setPrintError(null);

    try {
      if (typeof window !== 'undefined' && typeof window.print === 'function') {
        // Trigger browser / device native print dialog immediately
        await printPage(
          printContentRef.current,
          `${prescription.prescriptionNumber || 'Prescription'}_${(prescription.patientName || 'Patient').replace(/\s+/g, '_')}.pdf`
        );
      } else {
        throw new Error('window.print is not supported in this environment');
      }
    } catch (err: any) {
      console.error('Print trigger error:', err);
      setPrintError(err?.message || 'Unable to open print preview. Please try Download PDF instead.');
    }
  };

  // Dedicated direct PDF download handler that does NOT depend on a physical printer
  const handleDownloadPdf = async (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setPrintError(null);
    setIsPdfGenerating(true);

    try {
      // Desktop app: save a real (text) PDF through Electron
      const rxFile = `${prescription.prescriptionNumber || 'Prescription'}_${(prescription.patientName || 'Patient').replace(/\s+/g, '_')}.pdf`;
      if (await savePageAsPdf(rxFile, printContentRef.current)) return;

      const contentEl = printContentRef.current;
      if (!contentEl) {
        throw new Error('Print canvas not found in DOM');
      }

      // Capture high-res canvas of the prescription
      const canvas = await html2canvas(contentEl, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
      });

      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
      const safeFilename = `${prescription.prescriptionNumber || 'Prescription'}_${(prescription.patientName || 'Patient').replace(/\s+/g, '_')}.pdf`;
      pdf.save(safeFilename);
    } catch (err: any) {
      console.error('PDF generation error:', err);
      setPrintError(
        'Unable to generate PDF automatically. You can also use "Print Prescription" and choose "Save as PDF".'
      );
    } finally {
      setIsPdfGenerating(false);
    }
  };

  const cName = clinic?.name || 'Medical Health Clinic';
  const docName = prescription.doctorName || clinic?.doctorName || '';
  const qual = prescription.qualification || clinic?.qualification || 'MBBS, MD';
  const regNo = prescription.registrationNumber || clinic?.registrationNumber || '';
  const phone = clinic?.phone || '';
  const addr = clinic?.address || '';

  return createPortal(
    <div className="print-portal prescription-print-modal-overlay fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 print:p-0 print:bg-white print:fixed print:inset-0">
      <div className="prescription-print-modal-container bg-white rounded-2xl shadow-2xl max-w-3xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] print:max-h-none print:shadow-none print:border-none print:rounded-none relative">
        
        {/* Sticky Action Header bar with clearly visible, accessible [X] Close button */}
        <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50/95 backdrop-blur-xs flex items-center justify-between print:hidden sticky top-0 z-30 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-800">Prescription Preview:</span>
            <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              {prescription.prescriptionNumber}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {patientPhone && (
              <WhatsAppButton
                phone={patientPhone}
                patientName={prescription.patientName}
                messageType="prescription"
                size="sm"
              />
            )}
            
            {/* Separate DOWNLOAD PDF button (independent of physical printer) */}
            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isPdfGenerating}
              className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer border border-slate-200 disabled:opacity-60"
              title="Download Prescription as PDF file (No printer needed)"
            >
              {isPdfGenerating ? (
                <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
              ) : (
                <FileDown className="w-4 h-4 text-slate-600" />
              )}
              <span>{isPdfGenerating ? 'Generating...' : 'Download PDF'}</span>
            </button>

            {/* Print Prescription button - triggers browser/device native print flow */}
            <button
              type="button"
              onClick={handlePrint}
              className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
              title="Print Prescription (Triggers system print dialog / save as PDF)"
            >
              <Printer className="w-4 h-4" />
              <span>Print Prescription</span>
            </button>

            {/* Prominent High-Contrast Close [X] Button - Mobile Accessible touch target */}
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 transition cursor-pointer border border-slate-200 shadow-2xs"
              title="Close Preview (Esc)"
              aria-label="Close Prescription Preview"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <PrintHelp />

        {/* Visible error fallback if print preview fails */}
        {printError && (
          <div className="px-5 py-3 bg-rose-50 border-b border-rose-200 text-rose-700 text-xs font-medium flex items-center justify-between gap-3 print:hidden">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{printError}</span>
            </div>
            <button
              type="button"
              onClick={handleDownloadPdf}
              className="px-3 py-1 rounded-lg bg-rose-600 text-white font-bold text-xs hover:bg-rose-700 shrink-0 cursor-pointer"
            >
              Download PDF Instead
            </button>
          </div>
        )}

        {/* PRINTABLE A4 PRESCRIPTION CANVAS */}
        <div
          ref={printContentRef}
          className="prescription-print-content p-8 sm:p-10 overflow-y-auto print:p-0 print:overflow-visible text-slate-900 font-sans space-y-6"
        >
          
          {/* Clinic Letterhead Header */}
          <div className="border-b-2 border-slate-900 pb-5 flex items-start justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-3">
                {clinic?.logoUrl ? (
                  <img
                    src={clinic.logoUrl}
                    alt={cName}
                    className="w-12 h-12 object-contain rounded-lg"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-xl bg-blue-700 text-white flex items-center justify-center print:bg-slate-900 shadow-xs">
                    <HeartPulse className="w-6 h-6 text-cyan-200" />
                  </div>
                )}
                <div>
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight uppercase">
                    {cName}
                  </h1>
                  <p className="text-[11px] text-slate-500 uppercase tracking-widest font-semibold">
                    Clinical OPD & Healthcare Services
                  </p>
                </div>
              </div>

              {addr && (
                <p className="text-xs text-slate-600 flex items-center gap-1.5 mt-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{addr}</span>
                </p>
              )}
              {phone && (
                <p className="text-xs text-slate-600 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>Appointments / Helpline: <strong>{phone}</strong></span>
                </p>
              )}
            </div>

            <div className="text-right shrink-0">
              <h2 className="text-base font-bold text-slate-900">{docName}</h2>
              <p className="text-xs font-semibold text-blue-800 print:text-slate-700">{qual}</p>
              <p className="text-[11px] font-mono text-slate-500 mt-0.5">Reg. No: <strong>{regNo}</strong></p>
            </div>
          </div>

          {/* Patient Demographics Bar */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs print:bg-slate-50 print:border-slate-300">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Patient Name</span>
              <span className="font-bold text-slate-900 text-sm">{prescription.patientName}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Age / Gender</span>
              <span className="font-semibold text-slate-800">{prescription.patientAge} Years / {prescription.patientGender}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Patient ID</span>
              <span className="font-mono font-bold text-slate-800">{prescription.patientId}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Date & Time</span>
              <span className="font-semibold text-slate-800">
                {prescription.createdAt ? prescription.createdAt.split('T')[0] : new Date().toISOString().split('T')[0]}
              </span>
            </div>
          </div>

          {/* Clinical Diagnosis Bar */}
          {prescription.diagnosis && (
            <div className="flex items-center gap-2 text-xs">
              <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px]">Clinical Diagnosis:</span>
              <span className="font-bold text-sm text-blue-900 bg-blue-50 px-2.5 py-0.5 rounded-md border border-blue-200 print:border-slate-300 print:text-slate-900 print:bg-transparent">
                {prescription.diagnosis}
              </span>
            </div>
          )}

          {/* Rx Symbol & Medication Regimen */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-2xl font-serif font-black text-blue-700 print:text-slate-900">℞</span>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
                Prescribed Medicines & Posology
              </span>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-hidden print:border-slate-300">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3 w-8">#</th>
                    <th className="py-2.5 px-3">Medicine & Strength</th>
                    <th className="py-2.5 px-3">Form</th>
                    <th className="py-2.5 px-3">Dosage & Frequency</th>
                    <th className="py-2.5 px-3">Duration</th>
                    <th className="py-2.5 px-3">Timing & Instructions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {prescription.medicines.map((item, index) => (
                    <tr key={item.id || index} className="hover:bg-slate-50">
                      <td className="py-3 px-3 font-bold text-slate-400">{index + 1}</td>
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900 text-[13px]">{item.name}</div>
                        {item.generic && (
                          <div className="text-[11px] text-slate-500 italic">{item.generic}</div>
                        )}
                      </td>
                      <td className="py-3 px-3 text-slate-700 font-medium">{item.form || 'Tab'}</td>
                      <td className="py-3 px-3 font-semibold text-blue-800 print:text-slate-900">
                        {item.dosage || '1 Tab'} • {item.frequency || '1-0-1'}
                      </td>
                      <td className="py-3 px-3 font-medium text-slate-700">{item.duration || '5 Days'}</td>
                      <td className="py-3 px-3">
                        <span className="font-semibold text-slate-800">{item.timing || 'After Food'}</span>
                        {item.instructions && (
                          <span className="block text-[11px] text-slate-500 italic mt-0.5">
                            {item.instructions}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Advice & Follow-up Section */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 avoid-break">
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 print:bg-transparent text-xs space-y-1.5">
              <span className="font-bold text-slate-800 uppercase text-[10px] tracking-wider block">
                Dietary & Lifestyle Advice:
              </span>
              <p className="text-slate-700 whitespace-pre-line leading-relaxed">
                {prescription.advice || 'Follow the medication schedule strictly. Maintain adequate hydration and rest.'}
              </p>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 print:bg-transparent text-xs space-y-1.5">
              <span className="font-bold text-slate-800 uppercase text-[10px] tracking-wider block">
                Next Review / Follow-up:
              </span>
              <p className="text-sm font-bold text-blue-800 print:text-slate-900">
                {prescription.followUpDate ? `Scheduled for: ${prescription.followUpDate}` : 'SOS / As needed or in 7 days'}
              </p>
              <p className="text-[11px] text-slate-500 mt-1">
                Please bring this prescription slip and prior investigation reports during follow-up.
              </p>
            </div>
          </div>

          {/* Doctor Signature & Seal Area */}
          <div className="pt-8 flex items-end justify-between border-t border-slate-200 text-xs avoid-break">
            <div className="text-[10px] text-slate-400 space-y-0.5">
              <p>Generated digitally via {cName} Clinic Management EMR</p>
              <p>Prescription ID: {prescription.prescriptionNumber} • Confidential Medical Document</p>
            </div>

            <div className="text-center w-52 shrink-0">
              <div className="h-12 border-b border-slate-400 flex items-end justify-center pb-1">
                <span className="font-serif italic text-base text-slate-700 font-bold">{docName}</span>
              </div>
              <p className="font-bold text-slate-800 mt-1.5">{docName}</p>
              <p className="text-[10px] text-slate-500">{qual} • Reg No: {regNo}</p>
              <p className="text-[9px] text-slate-400 uppercase tracking-widest mt-0.5 font-semibold">Authorized Signature</p>
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
