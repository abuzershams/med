import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Prescription, Patient, Medicine, PrescriptionItem, Consultation } from '../../types';
import { voidPrescription } from '../../services/db';
import { WhatsAppButton } from '../common/WhatsAppButton';
import { VoidPrescriptionModal } from './VoidPrescriptionModal';
import {
  FileText,
  Plus,
  Search,
  Printer,
  Trash2,
  Calendar,
  Pill,
  Save,
  X,
  Stethoscope,
  Clock,
  Sparkles,
  Eye,
  Archive,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface PrescriptionsViewProps {
  prescriptions: Prescription[];
  patients: Patient[];
  medicines: Medicine[];
  doctorName: string;
  qualification: string;
  registrationNumber: string;
  onSavePrescription: (data: Omit<Prescription, 'id' | 'prescriptionNumber' | 'createdAt'>) => Promise<Prescription>;
  onOpenPrintModal: (rx: Prescription) => void;
  onVoidPrescription?: (id: string, reason: string) => Promise<void>;
  initialConsultation?: Consultation | null;
  initialPatient?: Patient | null;
}

export const PrescriptionsView: React.FC<PrescriptionsViewProps> = ({
  prescriptions,
  patients,
  medicines,
  doctorName,
  qualification,
  registrationNumber,
  onSavePrescription,
  onOpenPrintModal,
  onVoidPrescription = voidPrescription,
  initialConsultation,
  initialPatient,
}) => {
  const { clinic } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);

  // Void / Archive modal state
  const [rxToVoid, setRxToVoid] = useState<Prescription | null>(null);
  const [isVoiding, setIsVoiding] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<'success' | 'error'>('success');

  // Builder form states
  const [patientId, setPatientId] = useState(initialPatient?.id || '');
  const [diagnosis, setDiagnosis] = useState(initialConsultation?.diagnosis || '');
  const [advice, setAdvice] = useState(initialConsultation?.advice || 'Rest well, drink warm fluids, and complete the course.');
  const [followUpDate, setFollowUpDate] = useState(initialConsultation?.followUpDate || '');
  const [rxItems, setRxItems] = useState<PrescriptionItem[]>([
    {
      id: 'item-1',
      name: 'Paracetamol',
      generic: 'Acetaminophen',
      strength: '500 mg',
      form: 'Tablet',
      dosage: '1 Tablet',
      frequency: '1-0-1',
      duration: '3 Days',
      timing: 'After Food',
      instructions: 'For fever & pain relief',
    },
  ]);
  const [loading, setLoading] = useState(false);

  // Open builder automatically if opened from consultation
  React.useEffect(() => {
    if (initialPatient) {
      setPatientId(initialPatient.id);
      setIsBuilderOpen(true);
    }
    if (initialConsultation) {
      setDiagnosis(initialConsultation.diagnosis);
      if (initialConsultation.advice) setAdvice(initialConsultation.advice);
      if (initialConsultation.followUpDate) setFollowUpDate(initialConsultation.followUpDate);
    }
  }, [initialPatient, initialConsultation]);

  const selectedPatient = patients.find((p) => p.id === patientId);

  const handleAddMedicineRow = () => {
    const newItem: PrescriptionItem = {
      id: 'item-' + Date.now(),
      name: '',
      form: 'Tablet',
      dosage: '1 Tablet',
      frequency: '1-0-1',
      duration: '5 Days',
      timing: 'After Food',
    };
    setRxItems([...rxItems, newItem]);
  };

  const handleSelectPredefinedMedicine = (index: number, medId: string) => {
    const med = medicines.find((m) => m.id === medId);
    if (!med) return;

    const updated = [...rxItems];
    updated[index] = {
      ...updated[index],
      medicineId: med.id,
      name: med.name,
      generic: med.generic,
      strength: med.strength,
      form: med.form,
      dosage: med.defaultDosage || '1 ' + med.form,
      frequency: med.defaultFrequency || '1-0-1',
      duration: med.defaultDuration || '5 Days',
      timing: med.foodInstruction || 'After Food',
      instructions: med.instructions || '',
    };
    setRxItems(updated);
  };

  const handleUpdateItem = (index: number, field: keyof PrescriptionItem, val: string) => {
    const updated = [...rxItems];
    updated[index] = { ...updated[index], [field]: val };
    setRxItems(updated);
  };

  const handleRemoveItem = (index: number) => {
    if (rxItems.length <= 1) return;
    setRxItems(rxItems.filter((_, idx) => idx !== index));
  };

  const handleSaveRx = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient) {
      alert('Please select a patient.');
      return;
    }
    if (!diagnosis.trim()) {
      alert('Diagnosis is required.');
      return;
    }
    if (rxItems.some((item) => !item.name.trim())) {
      alert('Please specify name for all prescribed medicines.');
      return;
    }

    setLoading(true);
    try {
      const saved = await onSavePrescription({
        patientId: selectedPatient.id,
        patientName: selectedPatient.fullName,
        patientAge: selectedPatient.age,
        patientGender: selectedPatient.gender,
        consultationId: initialConsultation?.id,
        doctorName: doctorName || 'Attending Physician',
        qualification,
        registrationNumber,
        diagnosis: diagnosis.trim(),
        medicines: rxItems,
        advice: advice.trim(),
        followUpDate: followUpDate || undefined,
      });

      setIsBuilderOpen(false);
      // Immediately open the prescription print preview modal so user can Print Rx or Download PDF
      onOpenPrintModal(saved);
    } catch (err: any) {
      alert('Failed to save prescription: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const filteredPrescriptions = prescriptions.filter((rx) => {
    const term = searchTerm.toLowerCase();
    return (
      rx.prescriptionNumber.toLowerCase().includes(term) ||
      rx.patientName.toLowerCase().includes(term) ||
      rx.diagnosis.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <span>Digital Prescriptions (Rx)</span>
          </h2>
          <p className="text-xs text-slate-500">
            {prescriptions.length} digital prescription(s) generated • Instant Print & PDF
          </p>
        </div>

        <button
          onClick={() => setIsBuilderOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs hover:shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>+ Create Prescription</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3">
        <Search className="w-4 h-4 text-slate-400 shrink-0" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search prescriptions by Rx number (RX-2026-...), patient name, diagnosis..."
          className="w-full text-xs text-slate-800 outline-none"
        />
      </div>

      {/* Prescriptions List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredPrescriptions.length === 0 ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="font-semibold text-slate-600 text-sm">No prescriptions found</p>
            <p className="mt-1 text-slate-400">Click "+ Create Prescription" to generate an Rx slip.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[11px] border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Rx Number</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Patient Name</th>
                  <th className="py-3 px-4">Diagnosis</th>
                  <th className="py-3 px-4">Medications</th>
                  <th className="py-3 px-4">Follow-up</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPrescriptions.map((rx) => {
                  const patientObj = patients.find((p) => p.id === rx.patientId);
                  return (
                    <tr key={rx.id} className="hover:bg-blue-50/40 transition">
                      <td className="py-3.5 px-4 font-mono font-bold text-blue-700">
                        {rx.prescriptionNumber}
                      </td>

                      <td className="py-3.5 px-4 text-slate-500 font-mono">
                        {rx.createdAt.split('T')[0]}
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-900">{rx.patientName}</span>
                        <span className="text-[11px] text-slate-400 block font-mono">{rx.patientId}</span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-slate-800">{rx.diagnosis}</span>
                      </td>

                      <td className="py-3.5 px-4 text-slate-600">
                        <span className="font-bold text-slate-900">{rx.medicines.length} items:</span>{' '}
                        {rx.medicines.map((m) => m.name).slice(0, 3).join(', ')}
                        {rx.medicines.length > 3 ? '...' : ''}
                      </td>

                      <td className="py-3.5 px-4 text-slate-500">
                        {rx.followUpDate || 'None'}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {patientObj && (
                            <WhatsAppButton
                              phone={patientObj.phone}
                              patientName={rx.patientName}
                              messageType="prescription"
                              size="sm"
                            />
                          )}

                          <button
                            onClick={() => onOpenPrintModal(rx)}
                            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer"
                            title="View Prescription Details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => onOpenPrintModal(rx)}
                            className="px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold flex items-center gap-1.5 shadow-2xs transition cursor-pointer text-xs"
                            title="Print Prescription (A4 Layout)"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Print</span>
                          </button>

                          <button
                            onClick={() => setRxToVoid(rx)}
                            className="p-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-700 transition cursor-pointer"
                            title="Void / Archive Prescription"
                          >
                            <Archive className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Void / Archive Prescription Modal */}
      <VoidPrescriptionModal
        isOpen={!!rxToVoid}
        onClose={() => setRxToVoid(null)}
        prescription={rxToVoid}
        isLoading={isVoiding}
        onConfirm={async (reason) => {
          if (!rxToVoid) return;
          setIsVoiding(true);
          try {
            await onVoidPrescription(rxToVoid.id, reason);
            setToastType('success');
            setToastMessage(`Prescription ${rxToVoid.prescriptionNumber} has been safely archived & marked void.`);
            setRxToVoid(null);
            setTimeout(() => setToastMessage(null), 4000);
          } catch (err: any) {
            setToastType('error');
            setToastMessage(`Failed to archive prescription: ${err.message || 'Database error'}`);
          } finally {
            setIsVoiding(false);
          }
        }}
      />

      {/* Floating Status Notification Toast */}
      {toastMessage && (
        <div
          className={`fixed bottom-6 right-6 z-50 px-4 py-3 rounded-xl shadow-lg border flex items-center gap-2.5 text-xs font-semibold animate-in fade-in slide-in-from-bottom-3 duration-200 ${
            toastType === 'success'
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
              : 'bg-rose-50 text-rose-800 border-rose-200'
          }`}
        >
          {toastType === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span>{toastMessage}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="ml-2 text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* PRESCRIPTION BUILDER MODAL */}
      {isBuilderOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
          <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
            
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Digital Prescription Builder</h3>
                  <p className="text-[11px] text-slate-500">
                    Prescribe medicines from formulary master with auto-dosages
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsBuilderOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveRx} className="p-6 overflow-y-auto space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Select Patient <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={patientId}
                    onChange={(e) => setPatientId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">-- Choose Patient --</option>
                    {patients.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.fullName} ({p.patientId}) - {p.gender}, {p.age}y
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Clinical Diagnosis <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={diagnosis}
                    onChange={(e) => setDiagnosis(e.target.value)}
                    placeholder="e.g. Acute Pharyngitis with Fever"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Medicine Table Builder */}
              <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/60 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Pill className="w-4 h-4 text-blue-600" />
                    <span>Prescribed Medications ({rxItems.length})</span>
                  </span>
                  <button
                    type="button"
                    onClick={handleAddMedicineRow}
                    className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 font-semibold text-xs transition flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Add Medicine</span>
                  </button>
                </div>

                <div className="space-y-3">
                  {rxItems.map((item, idx) => (
                    <div
                      key={item.id}
                      className="bg-white p-3 rounded-xl border border-slate-200 space-y-2.5 shadow-2xs"
                    >
                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-center">
                        {/* Predefined selector */}
                        <div className="sm:col-span-4">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">
                            Formulary Catalog
                          </label>
                          <select
                            onChange={(e) => handleSelectPredefinedMedicine(idx, e.target.value)}
                            className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-xs bg-slate-50"
                          >
                            <option value="">-- Choose from Master Catalog --</option>
                            {medicines.map((m) => (
                              <option key={m.id} value={m.id}>
                                {m.name} ({m.strength}) - {m.form}
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* Medicine Name */}
                        <div className="sm:col-span-4">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">
                            Medicine Name & Strength <span className="text-rose-500">*</span>
                          </label>
                          <input
                            type="text"
                            required
                            value={item.name}
                            onChange={(e) => handleUpdateItem(idx, 'name', e.target.value)}
                            placeholder="e.g. Paracetamol 500mg"
                            className="w-full px-2 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold"
                          />
                        </div>

                        {/* Form */}
                        <div className="sm:col-span-3">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">
                            Form
                          </label>
                          <input
                            type="text"
                            value={item.form}
                            onChange={(e) => handleUpdateItem(idx, 'form', e.target.value)}
                            placeholder="Tablet / Syrup"
                            className="w-full px-2 py-1.5 rounded-lg border border-slate-300 text-xs"
                          />
                        </div>

                        {/* Delete row */}
                        <div className="sm:col-span-1 flex justify-end">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(idx)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                            title="Remove row"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Dosage details */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <div>
                          <label className="block text-[10px] text-slate-500">Dosage</label>
                          <input
                            type="text"
                            value={item.dosage}
                            onChange={(e) => handleUpdateItem(idx, 'dosage', e.target.value)}
                            placeholder="1 Tablet"
                            className="w-full px-2 py-1 rounded border border-slate-200 text-xs"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] text-slate-500">Frequency</label>
                          <input
                            type="text"
                            value={item.frequency}
                            onChange={(e) => handleUpdateItem(idx, 'frequency', e.target.value)}
                            placeholder="1-0-1 or 3x Daily"
                            className="w-full px-2 py-1 rounded border border-slate-200 text-xs font-semibold text-blue-700"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] text-slate-500">Duration</label>
                          <input
                            type="text"
                            value={item.duration}
                            onChange={(e) => handleUpdateItem(idx, 'duration', e.target.value)}
                            placeholder="5 Days"
                            className="w-full px-2 py-1 rounded border border-slate-200 text-xs"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] text-slate-500">Timing</label>
                          <select
                            value={item.timing}
                            onChange={(e) => handleUpdateItem(idx, 'timing', e.target.value)}
                            className="w-full px-2 py-1 rounded border border-slate-200 text-xs bg-white"
                          >
                            <option value="After Food">After Food</option>
                            <option value="Before Food">Before Food</option>
                            <option value="With Meals">With Meals</option>
                            <option value="At Bedtime">At Bedtime</option>
                            <option value="Empty Stomach">Empty Stomach</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Advice and Next Visit */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Special Advice & Dietary Instructions
                  </label>
                  <textarea
                    rows={2}
                    value={advice}
                    onChange={(e) => setAdvice(e.target.value)}
                    placeholder="Drink plenty of warm water, avoid oily and cold food..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-semibold text-slate-700">
                      Next Follow-up Review Date
                    </label>
                    <span className="text-[10px] text-slate-400 font-medium">Quick Suggestions:</span>
                  </div>

                  {/* Suggest follow-up from prescribed medication duration or standard pills */}
                  <div className="flex flex-wrap gap-1 mb-2">
                    {/* Dynamic pill based on max duration from rxItems */}
                    {(() => {
                      let maxDays = 0;
                      rxItems.forEach((item) => {
                        const m = (item.duration || '').match(/\d+/);
                        if (m) {
                          const num = parseInt(m[0], 10);
                          if (num > maxDays) maxDays = num;
                        }
                      });
                      if (maxDays > 0) {
                        const d = new Date();
                        d.setDate(d.getDate() + maxDays);
                        const targetStr = d.toISOString().split('T')[0];
                        return (
                          <button
                            type="button"
                            onClick={() => setFollowUpDate(targetStr)}
                            className="px-2 py-0.5 rounded-lg text-[11px] font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 transition cursor-pointer flex items-center gap-1"
                            title={`Suggest date after ${maxDays} days of prescribed medicine`}
                          >
                            <span>After Meds (+{maxDays}d)</span>
                          </button>
                        );
                      }
                      return null;
                    })()}

                    {[
                      { label: '+3 Days', days: 3 },
                      { label: '+5 Days', days: 5 },
                      { label: '+7 Days (1 Wk)', days: 7 },
                      { label: '+10 Days', days: 10 },
                      { label: '+14 Days (2 Wks)', days: 14 },
                      { label: '+1 Month', days: 30 },
                    ].map((item) => {
                      const d = new Date();
                      d.setDate(d.getDate() + item.days);
                      const targetStr = d.toISOString().split('T')[0];
                      const isSelected = followUpDate === targetStr;

                      return (
                        <button
                          key={item.label}
                          type="button"
                          onClick={() => setFollowUpDate(targetStr)}
                          className={`px-2 py-0.5 rounded-lg text-[11px] font-semibold transition cursor-pointer border ${
                            isSelected
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                          }`}
                        >
                          {item.label}
                        </button>
                      );
                    })}

                    {followUpDate && (
                      <button
                        type="button"
                        onClick={() => setFollowUpDate('')}
                        className="px-1.5 py-0.5 text-[11px] text-slate-400 hover:text-slate-600 font-medium"
                      >
                        Clear
                      </button>
                    )}
                  </div>

                  <input
                    type="date"
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Automatically records a Follow-up reminder for this patient.
                  </p>
                </div>
              </div>

              {/* Footer */}
              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsBuilderOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-xs hover:shadow transition flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{loading ? 'Generating Rx...' : 'Save & Print Prescription'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
