export type UserRole = 'admin' | 'doctor' | 'receptionist' | 'nurse' | 'pharmacy' | 'staff';

export interface Clinic {
  id: string;
  name: string;
  doctorName: string;
  qualification: string;
  registrationNumber: string;
  phone: string;
  whatsapp?: string;
  email?: string;
  address: string;
  workingHours?: string;
  logoUrl?: string;
  currency?: string;
  autoPrintOnSave?: boolean;
  autoPrintPrescription?: boolean;
  autoPrintInvoice?: boolean;
  setupCompleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface UserStaff {
  id: string;
  username: string;
  fullName: string;
  role: UserRole;
  phone: string;
  email?: string;
  status: 'active' | 'inactive';
  passwordHash: string;
  createdAt: string;
  lastLogin?: string;
}

export interface Patient {
  id: string;
  patientId: string; // e.g. PAT-1001
  fullName: string;
  dob?: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  phone: string;
  alternatePhone?: string;
  address: string;
  city: string;
  bloodGroup: string;
  emergencyContact?: string;
  notes?: string;
  photoUrl?: string;
  isArchived?: boolean;
  archivedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export type AppointmentStatus =
  | 'scheduled'
  | 'confirmed'
  | 'waiting'
  | 'in_consultation'
  | 'completed'
  | 'cancelled'
  | 'no_show';

export type AppointmentType = 'new' | 'followup' | 'emergency' | 'routine';
export type AppointmentSource = 'walk_in' | 'phone' | 'online';

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  doctorName: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  reason: string;
  type: AppointmentType;
  status: AppointmentStatus;
  source: AppointmentSource;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Vital {
  id: string;
  patientId: string;
  patientName?: string;
  appointmentId?: string;
  weight?: number; // kg
  height?: number; // cm
  bmi?: number;
  bpSystolic?: number; // mmHg
  bpDiastolic?: number; // mmHg
  pulse?: number; // bpm
  temperature?: number; // °F
  spo2?: number; // %
  bloodSugar?: number; // mg/dL
  respiratoryRate?: number; // breaths/min
  recordedBy: string;
  recordedAt: string;
  notes?: string;
  createdAt: string;
}

export interface Consultation {
  id: string;
  patientId: string;
  patientName: string;
  patientAge?: number;
  patientGender?: string;
  appointmentId?: string;
  doctorName: string;
  chiefComplaint: string;
  symptoms: string;
  medicalHistory?: string;
  examination?: string;
  diagnosis: string;
  clinicalNotes?: string;
  treatmentPlan?: string;
  advice?: string;
  followUpDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PrescriptionItem {
  id: string;
  medicineId?: string;
  name: string;
  generic?: string;
  strength?: string;
  form: string;
  dosage: string; // e.g. "1 Tablet", "5 ml"
  frequency: string; // e.g. "1-0-1", "Once Daily", "Three times a day"
  duration: string; // e.g. "5 Days", "2 Weeks"
  timing: string; // e.g. "After Food", "Before Food"
  instructions?: string;
}

export interface Prescription {
  id: string;
  prescriptionNumber: string; // e.g. RX-2026-001
  patientId: string;
  patientName: string;
  patientAge: number;
  patientGender: string;
  consultationId?: string;
  doctorName: string;
  qualification?: string;
  registrationNumber?: string;
  diagnosis: string;
  medicines: PrescriptionItem[];
  advice?: string;
  followUpDate?: string;
  status?: 'active' | 'void' | 'archived';
  isArchived?: boolean;
  archivedAt?: string;
  createdAt: string;
  updatedAt?: string;
}

export type MedicineForm =
  | 'Tablet'
  | 'Capsule'
  | 'Syrup'
  | 'Injection'
  | 'Drops'
  | 'Cream'
  | 'Ointment'
  | 'Inhaler'
  | 'Powder'
  | 'Suspension'
  | 'Other';

export interface Medicine {
  id: string;
  name: string;
  generic: string;
  strength: string;
  form: MedicineForm;
  defaultDosage: string;
  defaultFrequency: string;
  defaultDuration: string;
  foodInstruction: string;
  instructions?: string;
  currentStock: number;
  minStockLevel: number;
  price: number;
  purchasePrice?: number;
  status: 'active' | 'inactive' | 'archived';
  isArchived?: boolean;
  archivedAt?: string;
  isFavorite?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface StockMovement {
  id: string;
  medicineId: string;
  medicineName: string;
  type: 'in' | 'out' | 'adjustment';
  quantity: number;
  batchNumber?: string;
  expiryDate?: string;
  reason: string;
  performedBy: string;
  createdAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  company: string;
  phone: string;
  email?: string;
  address: string;
  taxNumber?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface InvoiceItem {
  id: string;
  description: string;
  type: 'consultation' | 'service' | 'procedure' | 'medicine' | 'other';
  quantity: number;
  unitPrice: number;
  amount: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string; // e.g. INV-1001
  patientId: string;
  patientName: string;
  patientPhone?: string;
  appointmentId?: string;
  date: string;
  items: InvoiceItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  paidAmount: number;
  dueAmount: number;
  status: 'paid' | 'partial' | 'pending';
  paymentMethod?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Payment {
  id: string;
  invoiceId: string;
  invoiceNumber: string;
  patientId: string;
  patientName: string;
  amount: number;
  method: 'cash' | 'upi' | 'card' | 'bank_transfer' | 'other';
  receivedBy: string;
  referenceNumber?: string;
  date: string;
  notes?: string;
  createdAt: string;
}

export interface MedicalDocument {
  id: string;
  patientId: string;
  patientName: string;
  title: string;
  documentType: 'lab_report' | 'x_ray' | 'prescription' | 'mri_ct' | 'discharge_summary' | 'other';
  fileUrl: string; // base64 or remote URL
  fileName?: string;
  fileSize?: string;
  notes?: string;
  uploadedBy: string;
  createdAt: string;
}

export interface FollowUp {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  doctorName: string;
  scheduledDate: string;
  reason: string;
  status: 'scheduled' | 'completed' | 'missed' | 'cancelled';
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  action: string;
  details: string;
  performedBy: string;
  userRole: string;
  timestamp: string;
  entityType?: string;
  entityId?: string;
}
