const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  dbLoadAll: () => ipcRenderer.invoke('db:loadAll'),
  dbSet: (col, id, json) => ipcRenderer.invoke('db:set', col, id, json),
  dbDelete: (col, id) => ipcRenderer.invoke('db:delete', col, id),
  getDbInfo: () => ipcRenderer.invoke('app:dbInfo'),
  exportBackup: () => ipcRenderer.invoke('backup:export'),
  restoreBackup: () => ipcRenderer.invoke('backup:restore'),
  printPage: () => ipcRenderer.invoke('print:page'),
  listPrinters: () => ipcRenderer.invoke('print:printers'),
  refocus: () => ipcRenderer.invoke('app:refocus'),
  savePdf: (name) => ipcRenderer.invoke('print:savePdf', name),
  openBackupFolder: () => ipcRenderer.invoke('backup:openFolder'),
});
