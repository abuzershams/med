// SQLite storage layer. Kept free of Electron imports so it can be tested alone.
const fs = require('fs');
const path = require('path');

function openDatabase(Database, file) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new Database(file);
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = FULL'); // safest: data is flushed to disk on every write
  db.exec(`CREATE TABLE IF NOT EXISTS docs (
    col  TEXT NOT NULL,
    id   TEXT NOT NULL,
    data TEXT NOT NULL,
    PRIMARY KEY (col, id)
  )`);

  const qAll = db.prepare('SELECT col, id, data FROM docs');
  const qSet = db.prepare(
    'INSERT INTO docs (col, id, data) VALUES (?, ?, ?) ON CONFLICT(col, id) DO UPDATE SET data = excluded.data'
  );
  const qDel = db.prepare('DELETE FROM docs WHERE col = ? AND id = ?');

  return {
    loadAll() {
      return qAll.all().map((r) => [r.col, r.id, r.data]);
    },
    set(col, id, json) {
      qSet.run(String(col), String(id), String(json));
      return true;
    },
    remove(col, id) {
      qDel.run(String(col), String(id));
      return true;
    },
    // Consistent copy of the whole database into a single file.
    backupTo(dest) {
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      if (fs.existsSync(dest)) fs.unlinkSync(dest);
      db.exec(`VACUUM INTO '${dest.replace(/'/g, "''")}'`);
      return dest;
    },
    close() {
      db.close();
    },
  };
}

// Returns true if `file` looks like a MedFlow database.
function validateBackup(Database, file) {
  let test;
  try {
    test = new Database(file, { readonly: true, fileMustExist: true });
    const row = test.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='docs'").get();
    return !!row;
  } catch {
    return false;
  } finally {
    try { test && test.close(); } catch {}
  }
}

module.exports = { openDatabase, validateBackup };
