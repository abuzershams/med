# MedFlow Clinic Manager (fully offline)

Works with **no internet**: Windows desktop app (EXE) and Android app (APK).
Internet is only used when the user taps a WhatsApp button.

## Where data lives
- **Windows**: `%APPDATA%\MedFlow Clinic\medflow.db` (SQLite). Automatic daily backup in `Documents\MedFlow Backups` (last 30 kept).
- **Android**: inside the app (IndexedDB). Use Settings > "Save / Share Backup" regularly. Uninstalling the app deletes the data.
- Phone and computer data are **separate** (no sync). Use backup files to move data.

## Printing
- **Windows**: Print button opens the Windows print window. The printer must be ON and added in Windows (Settings > Printers & scanners). No printer: choose "Microsoft Print to PDF" or use "Download PDF".
- **Android**: Print/Download makes an A4 PDF and opens the Share menu. Pick a printer app (Print, HP Smart, Epson iPrint, Mopria) or save to Files/Drive. Phone and Wi-Fi printer must be on the same Wi-Fi.

## Build the Windows installer
GitHub: upload the *contents* of this folder to a repository, Actions > "Build Windows EXE" > Run workflow, download artifact `MedFlow-Windows-Installer`.
Or locally (Node 22): `npm install` then `npm run dist:win` (installer in `release/`).

## Build the Android APK
Same repository: Actions > "Build Android APK" > Run workflow, download artifact `MedFlow-Android-APK` (debug APK, install by allowing "unknown sources").

## Run for testing
`npm install` then `npm start`
