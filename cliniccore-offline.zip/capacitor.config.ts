import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.clinic.management',
  appName: 'Clinic Management System',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
};

export default config;
