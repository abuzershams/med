# Clinic Management System (100% Offline)

A production-ready, fully offline Medical Clinic & Hospital Practice Management System built with React, TypeScript, Vite, Tailwind CSS, and IndexedDB (Dexie).

This application runs completely offline with **zero external server dependencies**. All database records, medical records, patient files, invoices, prescriptions, and pharmacy inventories are stored locally inside the browser/device IndexedDB storage.

---

## 🚀 Key Features

1. **100% Offline-First Architecture**: Runs without internet. No cloud lock-in, no telemetry, no remote API calls.
2. **Secure Authentication & RBAC**:
   - First-time clinic and doctor setup wizard.
   - One-time 12-character emergency Recovery Key.
   - Offline password hashing with `bcryptjs`.
   - 5-attempt brute-force login lock with visual countdown timer.
   - Role-Based Access Control: Admin, Doctor, Receptionist, Pharmacist, Staff.
3. **Clinical Practice Management**:
   - Patient master with unique IDs (`PT-0001`), full medical history, allergies, timeline, and document storage.
   - Doctor directory and scheduling.
   - Appointment booking with day tokens, double-booking prevention, status lifecycle, and optional WhatsApp notification links.
   - Digital vitals recording with automatic BMI calculation and trend tracking.
   - Detailed consultations and diagnostic notes.
   - Electronic Prescriptions with autocomplete from Medicine Master, dosage rules, templates, and signature zones.
4. **Pharmacy & Inventory (POS)**:
   - Batch numbers, expiry alerts, low-stock notifications.
   - Real-time Point of Sale (POS) checkout with Cash, UPI, and Card.
   - Safe stock reduction (preventing negative inventory), purchases, stock movements, and return refunds.
   - Suppliers and vendor accounting.
5. **Billing & Invoices**:
   - Unique annual sequence invoice numbers (`INV-2026-0001`).
   - One-click auto-fetch of unbilled consultations/prescriptions.
   - Partial payments, credit advances, currency configuration (Default ₹ / INR), tax calculation.
   - Dual print formats: **A4 Clinical Sheet** & **80mm Thermal Receipt**.
   - Offline PDF generation with jsPDF.
6. **Finance & Operations**:
   - Income and expenses ledger.
   - Staff payroll and payslip generation.
   - Staff daily attendance tracker.
   - Comprehensive analytical reports with CSV & PDF export.
7. **Offline Backup & Restore**:
   - Complete single-file JSON backup including base64 documents, logo, and full database state.
   - Easy restore on any machine.
   - Automated 7-day backup reminder badge.

---

## 🛠️ How to Run Locally

```bash
# 1. Install dependencies
npm install

# 2. Run local development server
npm run dev
# The app opens on http://localhost:3000

# 3. Build for production (Works from file:// protocol)
npm run build
```

---

## 📦 Building Windows (.exe) & Android (.apk)

### Automated GitHub Actions (Recommended)
This repository includes pre-configured GitHub Actions:
1. Push this project to GitHub.
2. Go to the **Actions** tab in your repository.
3. Select **Build Windows Application (.exe)** or **Build Android APK (.apk)**.
4. Download the generated installer/APK directly from the **Artifacts** section!

### Manual Local Builds

#### Windows (.exe via Electron)
```bash
npm run build
npm run electron:build
# The installer is generated inside the /release folder
```

#### Android (.apk via Capacitor)
```bash
npm run build
npx cap add android   # Only needed the first time
npx cap sync android
cd android && ./gradlew assembleDebug
# APK is generated at android/app/build/outputs/apk/debug/app-debug.apk
```
