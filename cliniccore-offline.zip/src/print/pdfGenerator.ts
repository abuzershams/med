import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { Invoice, Prescription, PharmacySale, Patient, Payslip, ClinicSettings } from '../types';
import { numberToWords } from '../utils/numberToWords';

export async function generateInvoicePDF(invoice: Invoice, settings: ClinicSettings | null): Promise<jsPDF> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const clinicName = settings?.clinicName || 'City Health Clinic';
  const doctorName = settings?.doctorName || invoice.doctorName || 'Consultant Physician';
  const degree = settings?.degree || 'MBBS, MD';
  const regNo = settings?.registrationNumber || 'MED-REG-0000';
  const phone = settings?.phone || '';
  const address = settings?.address || '';
  const city = settings?.city || '';
  const currency = settings?.currencySymbol || 'Rs.';

  // Header
  doc.setFontSize(18);
  doc.setTextColor(20, 45, 95); // Navy
  doc.text(clinicName, 14, 20);

  doc.setFontSize(10);
  doc.setTextColor(100, 116, 139);
  doc.text(`${doctorName} - ${degree} | Reg: ${regNo}`, 14, 26);
  if (address || city) doc.text(`${address}${city ? ', ' + city : ''}`, 14, 31);
  if (phone) doc.text(`Phone: ${phone}`, 14, 36);

  // Line
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.5);
  doc.line(14, 40, 196, 40);

  // Invoice Title & Meta
  doc.setFontSize(14);
  doc.setTextColor(30, 41, 59);
  doc.text('TAX INVOICE / RECEIPT', 14, 48);

  doc.setFontSize(10);
  doc.text(`Invoice No: ${invoice.invoiceNumber}`, 140, 48);
  doc.text(`Date: ${invoice.date}`, 140, 54);
  doc.text(`Status: ${invoice.status.toUpperCase()}`, 140, 60);

  // Patient Info Card
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(14, 53, 115, 20, 2, 2, 'F');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text(`Patient: ${invoice.patientName} (${invoice.patientCode})`, 18, 59);
  doc.text(`Phone: ${invoice.patientPhone || 'N/A'}`, 18, 65);
  if (invoice.doctorName) doc.text(`Doctor: ${invoice.doctorName}`, 18, 70);

  // Items Table
  const tableData = invoice.items.map((item, index) => [
    index + 1,
    item.description,
    item.quantity,
    `${currency} ${item.unitPrice.toFixed(2)}`,
    `${currency} ${item.amount.toFixed(2)}`,
  ]);

  autoTable(doc, {
    startY: 78,
    head: [['#', 'Description', 'Qty', 'Unit Price', 'Amount']],
    body: tableData,
    theme: 'striped',
    headStyles: {
      fillColor: [30, 58, 138], // Navy
      textColor: 255,
      fontSize: 9,
      fontStyle: 'bold',
    },
    styles: {
      fontSize: 9,
      cellPadding: 3,
    },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 95 },
      2: { cellWidth: 18, halign: 'center' },
      3: { cellWidth: 30, halign: 'right' },
      4: { cellWidth: 30, halign: 'right' },
    },
  });

  const finalY = (doc as any).lastAutoTable.finalY + 8;

  // Totals Box
  const startX = 120;
  doc.setFontSize(9);
  doc.setTextColor(51, 65, 85);

  doc.text('Subtotal:', startX, finalY);
  doc.text(`${currency} ${invoice.subtotal.toFixed(2)}`, 195, finalY, { align: 'right' });

  let curY = finalY;
  if (invoice.discountAmount > 0) {
    curY += 5;
    doc.text('Discount:', startX, curY);
    doc.text(`-${currency} ${invoice.discountAmount.toFixed(2)}`, 195, curY, { align: 'right' });
  }

  if (invoice.taxAmount > 0) {
    curY += 5;
    doc.text(`Tax (${invoice.taxPercent}%):`, startX, curY);
    doc.text(`+${currency} ${invoice.taxAmount.toFixed(2)}`, 195, curY, { align: 'right' });
  }

  curY += 6;
  doc.setLineWidth(0.3);
  doc.line(startX, curY - 2, 196, curY - 2);

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Grand Total:', startX, curY + 3);
  doc.text(`${currency} ${invoice.grandTotal.toFixed(2)}`, 195, curY + 3, { align: 'right' });

  curY += 9;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Amount Paid:', startX, curY);
  doc.text(`${currency} ${invoice.amountPaid.toFixed(2)}`, 195, curY, { align: 'right' });

  curY += 5;
  doc.text('Balance Due:', startX, curY);
  doc.setTextColor(invoice.balanceDue > 0 ? 220 : 51, invoice.balanceDue > 0 ? 38 : 65, invoice.balanceDue > 0 ? 38 : 85);
  doc.text(`${currency} ${invoice.balanceDue.toFixed(2)}`, 195, curY, { align: 'right' });

  // Amount in words
  doc.setTextColor(71, 85, 105);
  doc.setFontSize(9);
  doc.text(`Amount in words: ${numberToWords(invoice.grandTotal)}`, 14, finalY + 4);

  // Footer notes & signature
  doc.setDrawColor(226, 232, 240);
  doc.line(14, 255, 196, 255);

  const footerText = settings?.invoiceFooterText || 'Thank you for choosing our clinic. Wishing you good health!';
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(footerText, 14, 262);

  doc.text('Authorized Signatory', 160, 275);
  doc.line(150, 270, 195, 270);

  return doc;
}

export async function generatePrescriptionPDF(
  rx: Prescription,
  settings: ClinicSettings | null
): Promise<jsPDF> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const clinicName = settings?.clinicName || 'City Health Clinic';
  const doctorName = rx.doctorName || settings?.doctorName || 'Doctor';
  const degree = settings?.degree || 'MBBS, MD';
  const regNo = settings?.registrationNumber || 'MED-REG-0000';
  const phone = settings?.phone || '';
  const address = settings?.address || '';

  // Clinic Header
  doc.setFontSize(18);
  doc.setTextColor(20, 45, 95);
  doc.text(clinicName, 14, 20);

  doc.setFontSize(10);
  doc.setTextColor(71, 85, 105);
  doc.text(`Dr. ${doctorName.replace(/^Dr\.\s*/i, '')} - ${degree}`, 14, 26);
  doc.text(`Reg No: ${regNo} | Phone: ${phone}`, 14, 31);
  if (address) doc.text(address, 14, 36);

  doc.setDrawColor(20, 45, 95);
  doc.setLineWidth(0.8);
  doc.line(14, 40, 196, 40);

  // Patient Info Bar
  doc.setFillColor(248, 250, 252);
  doc.rect(14, 44, 182, 14, 'F');
  doc.setFontSize(9);
  doc.setTextColor(30, 41, 59);
  doc.text(`Patient: ${rx.patientName} (${rx.patientCode})`, 18, 51);
  doc.text(`Date: ${rx.date}`, 140, 51);
  if (rx.vitalsSummary) {
    doc.text(`Vitals: ${rx.vitalsSummary}`, 18, 56);
  }

  // Diagnosis
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(20, 45, 95);
  doc.text(`Diagnosis: ${rx.diagnosis}`, 14, 66);

  // Rx Symbol
  doc.setFontSize(18);
  doc.text('Rx', 14, 76);

  // Medicines Table
  const tableData = rx.medicines.map((m, idx) => [
    idx + 1,
    `${m.name}${m.strength ? ' (' + m.strength + ')' : ''}\n${m.genericName ? '[' + m.genericName + ']' : ''}`,
    m.dose || '1 Tab',
    m.frequency,
    m.duration,
    m.timing,
    m.instructions || '-',
  ]);

  autoTable(doc, {
    startY: 80,
    head: [['#', 'Medicine & Composition', 'Dose', 'Freq', 'Duration', 'Food', 'Instructions']],
    body: tableData,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 58, 138],
      textColor: 255,
      fontSize: 8.5,
    },
    styles: {
      fontSize: 8,
      cellPadding: 2.5,
    },
    columnStyles: {
      0: { cellWidth: 8, halign: 'center' },
      1: { cellWidth: 62 },
      2: { cellWidth: 16 },
      3: { cellWidth: 20 },
      4: { cellWidth: 18 },
      5: { cellWidth: 24 },
      6: { cellWidth: 34 },
    },
  });

  let curY = (doc as any).lastAutoTable.finalY + 10;

  if (rx.testsAdvised) {
    doc.setFontSize(9.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(20, 45, 95);
    doc.text('Investigations / Tests Advised:', 14, curY);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(51, 65, 85);
    doc.text(rx.testsAdvised, 14, curY + 5);
    curY += 14;
  }

  if (rx.advice) {
    doc.setFontSize(9.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(20, 45, 95);
    doc.text('General Advice & Instructions:', 14, curY);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(51, 65, 85);
    doc.text(rx.advice, 14, curY + 5);
    curY += 14;
  }

  if (rx.followUpDate) {
    doc.setFontSize(9.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(190, 24, 93);
    doc.text(`Next Follow-up Date: ${rx.followUpDate}`, 14, curY);
  }

  // Doctor Signature
  doc.line(140, 255, 190, 255);
  doc.setFontSize(9);
  doc.setTextColor(51, 65, 85);
  doc.text(`Dr. ${doctorName.replace(/^Dr\.\s*/i, '')}`, 145, 260);
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(degree, 145, 265);

  const footerText = settings?.prescriptionFooterText || 'Please take medicines strictly as advised.';
  doc.line(14, 272, 196, 272);
  doc.text(footerText, 14, 277);

  return doc;
}

export async function generateReceiptPDF(sale: PharmacySale, settings: ClinicSettings | null): Promise<jsPDF> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: [80, 160], // Thermal 80mm format
  });

  const clinicName = settings?.clinicName || 'Clinic Management';
  const currency = settings?.currencySymbol || 'Rs.';

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(clinicName, 40, 10, { align: 'center' });

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(settings?.address || '', 40, 15, { align: 'center' });
  if (settings?.phone) doc.text(`Tel: ${settings.phone}`, 40, 19, { align: 'center' });

  doc.setLineWidth(0.3);
  doc.line(5, 22, 75, 22);

  doc.setFontSize(8);
  doc.text(`Receipt: ${sale.receiptNumber}`, 5, 26);
  doc.text(`Date: ${sale.date} ${sale.time}`, 5, 30);
  doc.text(`Customer: ${sale.customerName}`, 5, 34);

  const tableData = sale.items.map((i) => [
    i.medicineName,
    i.quantity,
    `${i.unitPrice.toFixed(2)}`,
    `${i.total.toFixed(2)}`,
  ]);

  autoTable(doc, {
    startY: 37,
    head: [['Item', 'Qty', 'Price', 'Total']],
    body: tableData,
    theme: 'plain',
    headStyles: { fontSize: 7, fontStyle: 'bold' },
    styles: { fontSize: 7, cellPadding: 1 },
    columnStyles: {
      0: { cellWidth: 35 },
      1: { cellWidth: 10, halign: 'center' },
      2: { cellWidth: 13, halign: 'right' },
      3: { cellWidth: 14, halign: 'right' },
    },
  });

  const finalY = (doc as any).lastAutoTable.finalY + 4;
  doc.line(5, finalY, 75, finalY);

  doc.setFontSize(8);
  doc.text('Subtotal:', 40, finalY + 4);
  doc.text(`${currency} ${sale.subtotal.toFixed(2)}`, 75, finalY + 4, { align: 'right' });

  let curY = finalY + 4;
  if (sale.discount > 0) {
    curY += 4;
    doc.text('Discount:', 40, curY);
    doc.text(`-${currency} ${sale.discount.toFixed(2)}`, 75, curY, { align: 'right' });
  }

  curY += 4;
  doc.setFont('helvetica', 'bold');
  doc.text('GRAND TOTAL:', 35, curY);
  doc.text(`${currency} ${sale.grandTotal.toFixed(2)}`, 75, curY, { align: 'right' });

  curY += 4;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.text(`Mode: ${sale.paymentMethod}`, 5, curY);

  doc.text('Thank you! Get well soon.', 40, curY + 8, { align: 'center' });

  return doc;
}

export async function generatePayslipPDF(payslip: Payslip, settings: ClinicSettings | null): Promise<jsPDF> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const clinicName = settings?.clinicName || 'Clinic Management';
  const currency = settings?.currencySymbol || 'Rs.';

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(20, 45, 95);
  doc.text(clinicName, 105, 20, { align: 'center' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(settings?.address || '', 105, 26, { align: 'center' });

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text(`SALARY PAYSLIP - ${payslip.month}`, 105, 34, { align: 'center' });

  doc.setDrawColor(226, 232, 240);
  doc.line(14, 38, 196, 38);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Employee Name: ${payslip.employeeName}`, 14, 46);
  doc.text(`Role / Designation: ${payslip.role}`, 14, 52);
  doc.text(`Payment Date: ${payslip.paymentDate}`, 130, 46);
  doc.text(`Status: Settled (Paid)`, 130, 52);

  autoTable(doc, {
    startY: 60,
    head: [['Description', 'Earnings', 'Deductions']],
    body: [
      ['Basic Salary', `${currency} ${payslip.basicSalary.toFixed(2)}`, '—'],
      ['Allowances & Incentives', `${currency} ${payslip.allowances.toFixed(2)}`, '—'],
      ['Statutory & Other Deductions', '—', `${currency} ${payslip.deductions.toFixed(2)}`],
      ['Total', `${currency} ${(payslip.basicSalary + payslip.allowances).toFixed(2)}`, `${currency} ${payslip.deductions.toFixed(2)}`],
    ],
    theme: 'grid',
    headStyles: { fillColor: [20, 45, 95] },
  });

  const finalY = (doc as any).lastAutoTable.finalY + 10;
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(20, 45, 95);
  doc.text(`Net Salary Payable: ${currency} ${payslip.netSalary.toFixed(2)}`, 14, finalY);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'italic');
  doc.setTextColor(100, 116, 139);
  doc.text(`Amount in Words: ${numberToWords(payslip.netSalary)} Only`, 14, finalY + 6);

  doc.line(140, finalY + 30, 190, finalY + 30);
  doc.text('Authorized Signatory', 145, finalY + 35);

  return doc;
}

export async function generateReportPDF(
  title: string,
  tableData: any[][],
  settings: ClinicSettings | null
): Promise<jsPDF> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const clinicName = settings?.clinicName || 'Clinic Management';

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(20, 45, 95);
  doc.text(clinicName, 105, 20, { align: 'center' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`Report Generated Offline on ${new Date().toLocaleDateString()}`, 105, 26, { align: 'center' });

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text(title, 105, 34, { align: 'center' });

  const headers = tableData[0] || [];
  const rows = tableData.slice(1);

  autoTable(doc, {
    startY: 42,
    head: [headers],
    body: rows,
    theme: 'striped',
    headStyles: { fillColor: [20, 45, 95] },
  });

  return doc;
}

export async function generateTestPagePDF(paperSize: 'A4' | '80mm' = 'A4'): Promise<jsPDF> {
  if (paperSize === '80mm') {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: [80, 150],
    });
    doc.setFontSize(12);
    doc.text('TEST RECEIPT - 80MM', 40, 15, { align: 'center' });
    doc.setFontSize(8);
    doc.text('Clinic Management System', 40, 22, { align: 'center' });
    doc.line(5, 25, 75, 25);
    doc.text('Item 1: Consultation', 5, 32);
    doc.text('Rs. 500.00', 75, 32, { align: 'right' });
    doc.text('Item 2: Lab Screening', 5, 38);
    doc.text('Rs. 150.00', 75, 38, { align: 'right' });
    doc.line(5, 42, 75, 42);
    doc.setFontSize(9);
    doc.text('Total: Rs. 650.00', 75, 48, { align: 'right' });
    doc.setFontSize(8);
    doc.text('Thermal Printer Margins Verified OK', 40, 60, { align: 'center' });
    return doc;
  }

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  // Corner markers
  doc.setLineWidth(0.5);
  doc.setDrawColor(20, 45, 95);
  // Top-left
  doc.line(10, 10, 20, 10);
  doc.line(10, 10, 10, 20);
  // Top-right
  doc.line(200, 10, 190, 10);
  doc.line(200, 10, 200, 20);
  // Bottom-left
  doc.line(10, 287, 20, 287);
  doc.line(10, 287, 10, 277);
  // Bottom-right
  doc.line(200, 287, 190, 287);
  doc.line(200, 287, 200, 277);

  doc.setFontSize(18);
  doc.setTextColor(20, 45, 95);
  doc.text('SYSTEM PRINT TEST PAGE (A4)', 105, 30, { align: 'center' });

  doc.setFontSize(10);
  doc.setTextColor(71, 85, 105);
  doc.text('Offline Clinical PDF & Print Engine Verification', 105, 38, { align: 'center' });

  autoTable(doc, {
    startY: 55,
    head: [['Parameter', 'Status', 'Description']],
    body: [
      ['Page Dimensions', 'PASS', 'Standard A4 210mm x 297mm confirmed'],
      ['Color Engine', 'PASS', 'RGB print color profile loaded without internet'],
      ['Table Alignment', 'PASS', 'Automatic cell padding and text wrapping verified'],
      ['Barcode/Receipts', 'PASS', 'Ready for instant clinical generation'],
    ],
    theme: 'striped',
    headStyles: { fillColor: [20, 45, 95] },
  });

  doc.setFontSize(9);
  doc.text(`Generated locally at: ${new Date().toLocaleString()}`, 105, 270, { align: 'center' });

  return doc;
}
