import React, { useRef } from 'react';
import { Printer, Download, Share2, X } from 'lucide-react';
import { printHtmlViaIframe } from '../utils/printHelper';
import { shareDocument } from '../utils/shareHelper';
import { useToast } from '../context/ToastContext';

interface PrintPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  documentType?: 'Invoice' | 'Prescription' | 'Receipt' | 'PatientCard' | 'Payslip' | 'Report' | 'TestPage' | string;
  paperSize?: 'A4' | '80mm' | 'thermal';
  onDownloadPdf?: () => Promise<void>;
  onGeneratePdf?: () => Promise<any>;
  children: React.ReactNode;
}

export const PrintPreviewModal: React.FC<PrintPreviewModalProps> = ({
  isOpen,
  onClose,
  title,
  documentType = 'Document',
  paperSize = 'A4',
  onDownloadPdf,
  onGeneratePdf,
  children,
}) => {
  const contentRef = useRef<HTMLDivElement>(null);
  const { success, error } = useToast();

  if (!isOpen) return null;

  const handlePrint = () => {
    if (!contentRef.current) return;
    const html = contentRef.current.innerHTML;
    printHtmlViaIframe(html, `${documentType} - ${title}`);
  };

  const handleDownload = async () => {
    try {
      if (onDownloadPdf) {
        await onDownloadPdf();
      } else if (onGeneratePdf) {
        const pdf = await onGeneratePdf();
        if (pdf && typeof pdf.save === 'function') {
          pdf.save(`${title.replace(/[^a-zA-Z0-9_-]/g, '_')}.pdf`);
        }
      }
      success('PDF downloaded successfully!', 'Offline PDF Ready');
    } catch (err: any) {
      error(err.message || 'Failed to download PDF');
    }
  };

  const handleShare = async () => {
    try {
      await shareDocument(title, `Clinical ${documentType}: ${title}`);
      success('Share sheet opened or document downloaded.');
    } catch {
      // Fallback download
      await handleDownload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150">
      <div className="w-full max-w-4xl bg-slate-100 rounded-2xl shadow-2xl border border-slate-300 overflow-hidden my-auto max-h-[94vh] flex flex-col">
        {/* Top Control Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-3.5 bg-white border-b border-slate-200 shrink-0">
          <div>
            <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2">
              <Printer className="w-4 h-4 text-blue-600" />
              Print Preview: {title}
            </h3>
            <p className="text-xs text-slate-500">Preview exactly how the document will appear on paper and PDF</p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 shadow-xs transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              Print
            </button>
            <button
              type="button"
              onClick={handleDownload}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              Download PDF
            </button>
            <button
              type="button"
              onClick={handleShare}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <Share2 className="w-3.5 h-3.5 text-slate-500" />
              Share
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Paper Container Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 flex justify-center bg-slate-200/70">
          <div
            ref={contentRef}
            className="w-full max-w-[210mm] min-h-[297mm] bg-white p-8 sm:p-12 shadow-md rounded-sm text-slate-900 border border-slate-200"
          >
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};
