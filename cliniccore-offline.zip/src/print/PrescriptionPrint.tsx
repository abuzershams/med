import React from 'react';
import type { Prescription, ClinicSettings } from '../types';

interface PrescriptionPrintProps {
  prescription: Prescription;
  settings: ClinicSettings | null;
}

export const PrescriptionPrint: React.FC<PrescriptionPrintProps> = ({ prescription, settings }) => {
  const clinicName = settings?.clinicName || 'City Health Clinic';
  const doctorName = prescription.doctorName || settings?.doctorName || 'Doctor';
  const degree = settings?.degree || 'MBBS, MD';
  const regNo = settings?.registrationNumber || 'MED-REG-0000';
  const phone = settings?.phone || '';
  const address = settings?.address || '';
  const city = settings?.city || '';

  return (
    <div className="font-sans text-slate-800 text-[13px] leading-relaxed">
      {/* Header */}
      <div className="flex items-start justify-between border-b-2 border-slate-800 pb-5 mb-5">
        <div className="flex items-center gap-4">
          {settings?.logoBase64 && (
            <img
              src={settings.logoBase64}
              alt="Logo"
              className="w-16 h-16 object-contain rounded-lg border border-slate-200"
            />
          )}
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{clinicName}</h1>
            <p className="text-sm font-semibold text-slate-700">
              Dr. {doctorName.replace(/^Dr\.\s*/i, '')} - {degree}
            </p>
            <p className="text-xs text-slate-500">
              Reg. No: <span className="font-medium text-slate-700">{regNo}</span> | Phone: {phone}
            </p>
            {(address || city) && <p className="text-xs text-slate-500">{address}{city ? `, ${city}` : ''}</p>}
          </div>
        </div>

        <div className="text-right">
          <span className="inline-block px-3 py-1 bg-blue-900 text-white text-xs font-bold uppercase rounded-md tracking-wider">
            Medical Prescription
          </span>
          <p className="text-xs text-slate-600 mt-2">Date: <span className="font-semibold text-slate-800">{prescription.date}</span></p>
        </div>
      </div>

      {/* Patient Information Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs mb-5">
        <div>
          <span className="text-slate-400 block text-[10px] uppercase font-bold">Patient Name</span>
          <span className="font-bold text-slate-900">{prescription.patientName}</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[10px] uppercase font-bold">Patient ID</span>
          <span className="font-semibold text-slate-800">{prescription.patientCode}</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[10px] uppercase font-bold">Date</span>
          <span className="font-semibold text-slate-800">{prescription.date}</span>
        </div>
        <div>
          <span className="text-slate-400 block text-[10px] uppercase font-bold">Doctor</span>
          <span className="font-semibold text-slate-800">{prescription.doctorName}</span>
        </div>
        {prescription.vitalsSummary && (
          <div className="col-span-full pt-2 border-t border-slate-200/60 text-slate-700">
            <span className="font-semibold text-slate-900">Recorded Vitals: </span>
            {prescription.vitalsSummary}
          </div>
        )}
      </div>

      {/* Diagnosis */}
      <div className="mb-6 flex items-baseline gap-2">
        <span className="text-xs font-bold uppercase tracking-wider text-blue-900">Diagnosis:</span>
        <span className="text-sm font-semibold text-slate-900 bg-blue-50/80 px-2.5 py-0.5 rounded border border-blue-200">
          {prescription.diagnosis}
        </span>
      </div>

      {/* Rx Symbol */}
      <div className="mb-2">
        <span className="text-3xl font-serif font-black text-blue-900">℞</span>
      </div>

      {/* Medicines Table */}
      <table className="w-full border-collapse mb-6 text-xs">
        <thead>
          <tr className="bg-slate-900 text-white text-[11px] uppercase tracking-wider">
            <th className="py-2 px-2.5 text-center w-8">#</th>
            <th className="py-2 px-3 text-left">Medicine & Composition</th>
            <th className="py-2 px-2.5 text-center w-20">Dosage</th>
            <th className="py-2 px-2.5 text-center w-24">Frequency</th>
            <th className="py-2 px-2.5 text-center w-20">Duration</th>
            <th className="py-2 px-2.5 text-left w-24">Food</th>
            <th className="py-2 px-3 text-left">Instructions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-200">
          {prescription.medicines.map((med, index) => (
            <tr key={med.id || index} className="hover:bg-slate-50/60">
              <td className="py-2.5 px-2.5 text-center text-slate-400 font-medium">{index + 1}</td>
              <td className="py-2.5 px-3">
                <span className="font-bold text-slate-900 block">{med.name} {med.strength}</span>
                {med.genericName && (
                  <span className="text-[11px] text-slate-500 italic block">{med.genericName}</span>
                )}
              </td>
              <td className="py-2.5 px-2.5 text-center font-medium text-slate-800">{med.dose || '1 Tab'}</td>
              <td className="py-2.5 px-2.5 text-center font-medium text-slate-800">{med.frequency}</td>
              <td className="py-2.5 px-2.5 text-center font-medium text-slate-800">{med.duration}</td>
              <td className="py-2.5 px-2.5 text-slate-700 font-medium">{med.timing}</td>
              <td className="py-2.5 px-3 text-slate-600 italic">{med.instructions || '-'}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Advices and Investigations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {prescription.testsAdvised && (
          <div className="p-3.5 rounded-xl border border-blue-200 bg-blue-50/50 text-xs">
            <p className="font-bold text-blue-900 uppercase tracking-wider mb-1">Investigations / Tests Advised:</p>
            <p className="text-slate-700 whitespace-pre-line leading-relaxed">{prescription.testsAdvised}</p>
          </div>
        )}

        {prescription.advice && (
          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 text-xs">
            <p className="font-bold text-slate-800 uppercase tracking-wider mb-1">Dietary & General Advice:</p>
            <p className="text-slate-700 whitespace-pre-line leading-relaxed">{prescription.advice}</p>
          </div>
        )}
      </div>

      {/* Follow-up Note */}
      {prescription.followUpDate && (
        <div className="mb-10 p-3 rounded-lg border border-pink-200 bg-pink-50/70 text-xs flex items-center justify-between">
          <span className="font-bold text-pink-900 uppercase tracking-wider">Next Follow-up Consultation:</span>
          <span className="font-bold text-pink-700 text-sm">{prescription.followUpDate}</span>
        </div>
      )}

      {/* Signature and Footer */}
      <div className="mt-16 pt-4 border-t border-slate-300 flex items-end justify-between text-xs">
        <div className="max-w-md text-slate-500">
          <p>{settings?.prescriptionFooterText || 'Please take medicines strictly as advised. Consult immediately if symptoms persist.'}</p>
        </div>
        <div className="text-center">
          <div className="w-44 border-b border-slate-400 mb-1" />
          <p className="font-semibold text-slate-800">Dr. {doctorName.replace(/^Dr\.\s*/i, '')}</p>
          <p className="text-[11px] text-slate-500">{degree}</p>
        </div>
      </div>
    </div>
  );
};
