import React from 'react';
import type { PharmacySale, ClinicSettings } from '../types';

interface ReceiptPrintProps {
  sale: PharmacySale;
  settings: ClinicSettings | null;
  mode?: 'A4' | '80mm';
}

export const ReceiptPrint: React.FC<ReceiptPrintProps> = ({ sale, settings, mode = 'A4' }) => {
  const currency = settings?.currencySymbol || '₹';
  const clinicName = settings?.clinicName || 'City Health Clinic & Pharmacy';
  const phone = settings?.phone || '';
  const address = settings?.address || '';

  if (mode === '80mm') {
    return (
      <div className="thermal-mode font-mono text-[11px] leading-tight text-black max-w-[72mm] mx-auto p-1">
        <div className="text-center pb-2 mb-2 border-b border-dashed border-black">
          <p className="font-bold text-sm uppercase">{clinicName}</p>
          {address && <p className="text-[10px]">{address}</p>}
          {phone && <p className="text-[10px]">Tel: {phone}</p>}
          <p className="font-bold mt-1 text-[11px]">PHARMACY POS RECEIPT</p>
        </div>

        <div className="text-[10px] pb-2 mb-2 border-b border-dashed border-black">
          <p>Receipt No: {sale.receiptNumber}</p>
          <p>Date: {sale.date}</p>
          <p>Customer: {sale.patientName || 'Walk-in Customer'}</p>
          <p>Cashier: {sale.soldBy}</p>
        </div>

        <table className="w-full text-[10px] mb-2 border-collapse">
          <thead>
            <tr className="border-b border-black">
              <th className="text-left py-1">Item</th>
              <th className="text-center py-1">Qty</th>
              <th className="text-right py-1">Price</th>
              <th className="text-right py-1">Amt</th>
            </tr>
          </thead>
          <tbody>
            {sale.items.map((item, idx) => (
              <tr key={idx}>
                <td className="py-0.5">{item.medicineName}</td>
                <td className="text-center py-0.5">{item.quantity}</td>
                <td className="text-right py-0.5">{item.unitPrice.toFixed(1)}</td>
                <td className="text-right py-0.5">{item.total.toFixed(1)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="border-t border-dashed border-black pt-1 space-y-0.5 text-[11px]">
          <div className="flex justify-between">
            <span>Subtotal:</span>
            <span>{currency}{sale.subtotal.toFixed(2)}</span>
          </div>
          {sale.discount > 0 && (
            <div className="flex justify-between">
              <span>Discount:</span>
              <span>-{currency}{sale.discount.toFixed(2)}</span>
            </div>
          )}
          {sale.tax > 0 && (
            <div className="flex justify-between">
              <span>Tax:</span>
              <span>+{currency}{sale.tax.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between font-bold text-xs pt-1 border-t border-black">
            <span>TOTAL:</span>
            <span>{currency}{sale.grandTotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-[10px] pt-1">
            <span>Paid via:</span>
            <span>{sale.paymentMethod}</span>
          </div>
        </div>

        <div className="text-center text-[9px] pt-3 mt-2 border-t border-dashed border-black">
          <p>Medicines once sold cannot be returned without bill.</p>
          <p>Get Well Soon!</p>
        </div>
      </div>
    );
  }

  // A4 Standard
  return (
    <div className="font-sans text-slate-800 text-xs">
      <div className="flex items-center justify-between border-b pb-4 mb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">{clinicName} - Pharmacy</h1>
          <p className="text-slate-500">{address} | Phone: {phone}</p>
        </div>
        <div className="text-right">
          <span className="font-bold text-slate-900 text-sm">Receipt: {sale.receiptNumber}</span>
          <p className="text-slate-500">Date: {sale.date}</p>
        </div>
      </div>

      <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 mb-4 flex justify-between">
        <div>
          <span className="text-slate-400 uppercase text-[10px] block">Customer</span>
          <span className="font-bold text-slate-900">{sale.patientName || 'Walk-in Customer'}</span>
        </div>
        <div>
          <span className="text-slate-400 uppercase text-[10px] block">Payment Mode</span>
          <span className="font-semibold text-slate-800">{sale.paymentMethod}</span>
        </div>
        <div>
          <span className="text-slate-400 uppercase text-[10px] block">Dispensed By</span>
          <span className="font-semibold text-slate-800">{sale.soldBy}</span>
        </div>
      </div>

      <table className="w-full border-collapse mb-4 text-xs">
        <thead>
          <tr className="bg-slate-900 text-white uppercase text-[10px]">
            <th className="py-2 px-3 text-center w-8">#</th>
            <th className="py-2 px-3 text-left">Medicine Description</th>
            <th className="py-2 px-3 text-center">Batch</th>
            <th className="py-2 px-3 text-center">Qty</th>
            <th className="py-2 px-3 text-right">Price</th>
            <th className="py-2 px-3 text-right">Total</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-200">
          {sale.items.map((item, idx) => (
            <tr key={idx}>
              <td className="py-2 px-3 text-center text-slate-400">{idx + 1}</td>
              <td className="py-2 px-3 font-medium text-slate-800">{item.medicineName}</td>
              <td className="py-2 px-3 text-center text-slate-600">{item.batchNumber}</td>
              <td className="py-2 px-3 text-center font-semibold">{item.quantity}</td>
              <td className="py-2 px-3 text-right text-slate-600">{currency}{item.unitPrice.toFixed(2)}</td>
              <td className="py-2 px-3 text-right font-bold text-slate-900">{currency}{item.total.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="flex justify-end mb-6">
        <div className="w-64 space-y-1 text-xs">
          <div className="flex justify-between text-slate-600">
            <span>Subtotal:</span>
            <span>{currency}{sale.subtotal.toFixed(2)}</span>
          </div>
          {sale.discount > 0 && (
            <div className="flex justify-between text-emerald-600">
              <span>Discount:</span>
              <span>-{currency}{sale.discount.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between font-bold text-sm text-slate-900 pt-2 border-t">
            <span>Grand Total:</span>
            <span>{currency}{sale.grandTotal.toFixed(2)}</span>
          </div>
        </div>
      </div>

      <div className="text-center text-slate-400 text-[10px] pt-4 border-t">
        Thank you for your visit. Get well soon!
      </div>
    </div>
  );
};
