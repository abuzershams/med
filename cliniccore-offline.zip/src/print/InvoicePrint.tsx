import React from 'react';
import type { Invoice, ClinicSettings } from '../types';
import { numberToWords } from '../utils/numberToWords';

interface InvoicePrintProps {
  invoice: Invoice;
  settings: ClinicSettings | null;
}

export const InvoicePrint: React.FC<InvoicePrintProps> = ({ invoice, settings }) => {
  const currency = settings?.currencySymbol || '₹';
  const clinicName = settings?.clinicName || 'City Health Clinic';
  const doctorName = settings?.doctorName || invoice.doctorName || 'Consultant Physician';
  const degree = settings?.degree || 'MBBS, MD';
  const regNo = settings?.registrationNumber || 'MED-REG-0000';
  const phone = settings?.phone || '';
  const address = settings?.address || '';
  const city = settings?.city || '';

  return (
    <div className="font-sans text-slate-800 text-[13px] leading-relaxed">
      {/* Header with Logo */}
      <div className="flex items-start justify-between border-b-2 border-slate-800 pb-5 mb-5">
        <div className="flex items-center gap-4">
          {settings?.logoBase64 && (
            <img
              src={settings.logoBase64}
              alt="Logo"
              className="w-16 h-16 object-contain rounded-lg border border-slate-200"
            />
          )}
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{clinicName}</h1>
            <p className="text-xs text-slate-600 font-medium">
              {doctorName} - {degree} | Reg: {regNo}
            </p>
            {(address || city) && <p className="text-xs text-slate-500">{address}{city ? `, ${city}` : ''}</p>}
            {phone && <p className="text-xs text-slate-500">Phone: {phone}</p>}
          </div>
        </div>

        <div className="text-right">
          <span className="inline-block px-3 py-1 bg-slate-900 text-white text-xs font-bold uppercase rounded-md tracking-wider">
            Tax Invoice
          </span>
          <p className="text-xs font-semibold text-slate-900 mt-2">No: {invoice.invoiceNumber}</p>
          <p className="text-xs text-slate-600">Date: {invoice.date}</p>
        </div>
      </div>

      {/* Bill To & Status Stamp */}
      <div className="grid grid-cols-2 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200 mb-6">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Bill To Patient</p>
          <p className="text-sm font-bold text-slate-900 mt-0.5">{invoice.patientName}</p>
          <p className="text-xs text-slate-600">Patient ID: <span className="font-semibold text-slate-800">{invoice.patientCode}</span></p>
          <p className="text-xs text-slate-600">Phone: {invoice.patientPhone || 'N/A'}</p>
          {invoice.doctorName && <p className="text-xs text-slate-600">Consultant: {invoice.doctorName}</p>}
        </div>

        <div className="flex flex-col items-end justify-center">
          <div
            className={`px-4 py-1.5 rounded-lg border-2 text-sm font-black uppercase tracking-widest ${
              invoice.status === 'Paid'
                ? 'bg-emerald-50 border-emerald-500 text-emerald-700'
                : invoice.status === 'Partial'
                ? 'bg-amber-50 border-amber-500 text-amber-700'
                : 'bg-rose-50 border-rose-500 text-rose-700'
            }`}
          >
            {invoice.status}
          </div>
          {invoice.notes && <p className="text-xs text-slate-500 mt-2 text-right italic">{invoice.notes}</p>}
        </div>
      </div>

      {/* Itemized Table */}
      <table className="w-full border-collapse mb-6">
        <thead>
          <tr className="bg-slate-900 text-white text-xs uppercase tracking-wider">
            <th className="py-2.5 px-3 text-center w-10">#</th>
            <th className="py-2.5 px-3 text-left">Description</th>
            <th className="py-2.5 px-3 text-center w-20">Qty</th>
            <th className="py-2.5 px-3 text-right w-28">Price</th>
            <th className="py-2.5 px-3 text-right w-28">Amount</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-200 text-xs">
          {invoice.items.map((item, index) => (
            <tr key={item.id || index} className="hover:bg-slate-50/50">
              <td className="py-2.5 px-3 text-center text-slate-400">{index + 1}</td>
              <td className="py-2.5 px-3 font-medium text-slate-800">{item.description}</td>
              <td className="py-2.5 px-3 text-center">{item.quantity}</td>
              <td className="py-2.5 px-3 text-right text-slate-600">
                {currency} {item.unitPrice.toFixed(2)}
              </td>
              <td className="py-2.5 px-3 text-right font-semibold text-slate-900">
                {currency} {item.amount.toFixed(2)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Calculations & Amount in Words */}
      <div className="grid grid-cols-2 gap-6 mb-8 items-start">
        <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
          <p className="font-semibold text-slate-700 mb-1">Amount in Words:</p>
          <p className="italic text-slate-600 leading-snug">{numberToWords(invoice.grandTotal)}</p>
        </div>

        <div className="space-y-2 text-xs">
          <div className="flex justify-between text-slate-600">
            <span>Subtotal:</span>
            <span className="font-medium text-slate-900">{currency} {invoice.subtotal.toFixed(2)}</span>
          </div>

          {invoice.discountAmount > 0 && (
            <div className="flex justify-between text-emerald-600">
              <span>Discount:</span>
              <span className="font-medium">-{currency} {invoice.discountAmount.toFixed(2)}</span>
            </div>
          )}

          {invoice.taxAmount > 0 && (
            <div className="flex justify-between text-slate-600">
              <span>Tax ({invoice.taxPercent}%):</span>
              <span className="font-medium">+{currency} {invoice.taxAmount.toFixed(2)}</span>
            </div>
          )}

          <div className="flex justify-between text-sm font-bold text-slate-900 pt-2 border-t-2 border-slate-800">
            <span>Grand Total:</span>
            <span>{currency} {invoice.grandTotal.toFixed(2)}</span>
          </div>

          <div className="flex justify-between text-slate-600 pt-1">
            <span>Amount Paid:</span>
            <span className="font-semibold text-slate-900">{currency} {invoice.amountPaid.toFixed(2)}</span>
          </div>

          <div className="flex justify-between text-sm font-bold pt-1">
            <span className={invoice.balanceDue > 0 ? 'text-rose-600' : 'text-slate-700'}>Balance Due:</span>
            <span className={invoice.balanceDue > 0 ? 'text-rose-600' : 'text-slate-700'}>
              {currency} {invoice.balanceDue.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Footer and Signatures */}
      <div className="mt-16 pt-4 border-t border-slate-300 flex items-end justify-between text-xs">
        <div className="max-w-md text-slate-500">
          <p>{settings?.invoiceFooterText || 'Thank you for choosing our clinic. Wishing you good health!'}</p>
        </div>
        <div className="text-center">
          <div className="w-40 border-b border-slate-400 mb-1" />
          <p className="font-semibold text-slate-800">Authorized Signature</p>
        </div>
      </div>
    </div>
  );
};
