import React from 'react';
import type { Patient, ClinicSettings } from '../types';

interface PatientCardPrintProps {
  patient: Patient;
  settings: ClinicSettings | null;
}

export const PatientCardPrint: React.FC<PatientCardPrintProps> = ({ patient, settings }) => {
  const clinicName = settings?.clinicName || 'City Health Clinic';
  const phone = settings?.phone || '';

  return (
    <div className="max-w-[120mm] mx-auto p-6 bg-white border-2 border-slate-800 rounded-2xl font-sans text-slate-800 shadow-lg">
      <div className="flex items-center justify-between border-b-2 border-slate-800 pb-3 mb-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900">{clinicName}</h2>
          <p className="text-[11px] text-slate-500">Official Patient Medical Health Card</p>
        </div>
        <div className="text-right">
          <span className="px-2.5 py-1 bg-slate-900 text-white rounded text-xs font-mono font-bold tracking-wider">
            {patient.patientCode}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-4">
        <div className="col-span-2 space-y-1.5 text-xs">
          <div>
            <span className="text-slate-400 block text-[10px] uppercase font-bold">Full Name</span>
            <span className="text-base font-bold text-slate-900">{patient.name}</span>
          </div>
          <div className="flex gap-4">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Gender</span>
              <span className="font-semibold text-slate-800">{patient.gender}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Age</span>
              <span className="font-semibold text-slate-800">{patient.age ? `${patient.age} yrs` : '-'}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Blood</span>
              <span className="font-bold text-rose-600">{patient.bloodGroup || 'N/A'}</span>
            </div>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase font-bold">Phone Number</span>
            <span className="font-medium text-slate-800">{patient.phone}</span>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center border-l pl-3">
          {/* Simulated QR Code / Barcode block for offline clinical card */}
          <div className="w-20 h-20 bg-slate-100 border border-slate-300 rounded-lg p-1.5 flex flex-col items-center justify-center text-center">
            <div className="grid grid-cols-4 gap-1 w-14 h-14 p-1 bg-white border border-slate-400">
              <div className="bg-slate-900 rounded-xs" />
              <div className="bg-slate-900 rounded-xs" />
              <div className="bg-white" />
              <div className="bg-slate-900 rounded-xs" />
              <div className="bg-white" />
              <div className="bg-slate-900 rounded-xs" />
              <div className="bg-slate-900 rounded-xs" />
              <div className="bg-white" />
              <div className="bg-slate-900 rounded-xs" />
              <div className="bg-white" />
              <div className="bg-slate-900 rounded-xs" />
              <div className="bg-slate-900 rounded-xs" />
              <div className="bg-slate-900 rounded-xs" />
              <div className="bg-slate-900 rounded-xs" />
              <div className="bg-white" />
              <div className="bg-slate-900 rounded-xs" />
            </div>
          </div>
          <span className="text-[9px] font-mono font-semibold text-slate-500 mt-1">
            {patient.patientCode}
          </span>
        </div>
      </div>

      <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs mb-3 space-y-1">
        {patient.emergencyContactName && (
          <p className="text-slate-600">
            <span className="font-semibold text-slate-800">Emergency Contact:</span> {patient.emergencyContactName} ({patient.emergencyContactPhone || 'N/A'})
          </p>
        )}
        {patient.allergies && (
          <p className="text-rose-600 font-medium">
            <span className="font-semibold">Allergies:</span> {patient.allergies}
          </p>
        )}
      </div>

      <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t">
        <span>Please present this card at every visit.</span>
        <span>Clinic Help: {phone}</span>
      </div>
    </div>
  );
};
