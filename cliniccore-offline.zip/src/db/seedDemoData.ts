import { db } from './database';
import { logActivity } from '../services/auditService';

export async function loadDemoData(adminName: string): Promise<void> {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const in3Days = new Date(now.getTime() + 3 * 24 * 60 * 1000 * 60 * 60).toISOString().split('T')[0];
  const in30Days = new Date(now.getTime() + 30 * 24 * 60 * 1000 * 60 * 60).toISOString().split('T')[0];
  const nextYear = new Date(now.getTime() + 365 * 24 * 60 * 1000 * 60 * 60).toISOString().split('T')[0];
  const pastYear = new Date(now.getTime() - 40 * 24 * 60 * 1000 * 60 * 60).toISOString().split('T')[0];

  await db.transaction(
    'rw',
    [
      db.patients,
      db.doctors,
      db.appointments,
      db.vitals,
      db.consultations,
      db.prescriptions,
      db.prescription_templates,
      db.medicines,
      db.medicine_batches,
      db.stock_movements,
      db.suppliers,
      db.purchases,
      db.sales,
      db.categories,
      db.invoices,
      db.payments,
      db.expenses,
      db.payslips,
      db.attendance,
      db.follow_ups,
      db.counters,
      db.activity_logs,
    ],
    async () => {
      // 1. Doctors
      const d1 = await db.doctors.add({
        name: 'Dr. Sarah Jenkins',
        degree: 'MD (General Medicine), MBBS',
        specialization: 'Internal Medicine',
        registrationNumber: 'MED-REG-84729',
        phone: '9876543210',
        email: 'sarah.jenkins@clinic.org',
        room: 'Consultation Room 1',
        consultationFee: 500,
        status: 'active',
        createdAt: todayStr,
      });

      const d2 = await db.doctors.add({
        name: 'Dr. Rajesh Sharma',
        degree: 'MS (Orthopaedics), MBBS',
        specialization: 'Orthopaedics',
        registrationNumber: 'MED-REG-91044',
        phone: '9876543211',
        email: 'rajesh.sharma@clinic.org',
        room: 'Consultation Room 2',
        consultationFee: 700,
        status: 'active',
        createdAt: todayStr,
      });

      // 2. Categories
      await db.categories.bulkAdd([
        { name: 'Antibiotics', type: 'medicine' },
        { name: 'Pain Relief', type: 'medicine' },
        { name: 'Antacids', type: 'medicine' },
        { name: 'Antihistamines', type: 'medicine' },
        { name: 'Antidiabetic', type: 'medicine' },
        { name: 'Antihypertensive', type: 'medicine' },
        { name: 'Supplements', type: 'medicine' },
        { name: 'Rent', type: 'expense' },
        { name: 'Medical Supplies', type: 'expense' },
        { name: 'Electricity & Water', type: 'expense' },
        { name: 'Staff Salaries', type: 'expense' },
        { name: 'Equipment Maintenance', type: 'expense' },
      ]);

      // 3. Medicines & Batches
      const m1 = await db.medicines.add({
        name: 'Amoxicillin 500mg',
        genericName: 'Amoxicillin Trihydrate',
        strength: '500mg',
        form: 'Capsule',
        category: 'Antibiotics',
        defaultDose: '1 Cap',
        defaultFrequency: 'TDS (Three times a day)',
        defaultDuration: '5 Days',
        defaultTiming: 'After Food',
        isFavorite: true,
        status: 'active',
        createdAt: todayStr,
      });
      await db.medicine_batches.add({
        medicineId: m1,
        medicineName: 'Amoxicillin 500mg',
        batchNumber: 'AMX-2024-B1',
        expiryDate: nextYear,
        purchasePrice: 65,
        sellingPrice: 110,
        currentStock: 120,
        unit: 'Strip (10 Caps)',
        createdAt: todayStr,
        updatedAt: todayStr,
      });

      const m2 = await db.medicines.add({
        name: 'Paracetamol 650mg',
        genericName: 'Acetaminophen',
        strength: '650mg',
        form: 'Tablet',
        category: 'Pain Relief',
        defaultDose: '1 Tab',
        defaultFrequency: 'SOS (As needed)',
        defaultDuration: '3 Days',
        defaultTiming: 'After Food',
        isFavorite: true,
        status: 'active',
        createdAt: todayStr,
      });
      await db.medicine_batches.add({
        medicineId: m2,
        medicineName: 'Paracetamol 650mg',
        batchNumber: 'PCM-884',
        expiryDate: nextYear,
        purchasePrice: 18,
        sellingPrice: 35,
        currentStock: 450,
        unit: 'Strip (15 Tabs)',
        createdAt: todayStr,
        updatedAt: todayStr,
      });

      const m3 = await db.medicines.add({
        name: 'Pantoprazole 40mg',
        genericName: 'Pantoprazole Sodium',
        strength: '40mg',
        form: 'Tablet',
        category: 'Antacids',
        defaultDose: '1 Tab',
        defaultFrequency: 'OD (Once a day)',
        defaultDuration: '7 Days',
        defaultTiming: 'Before Food',
        isFavorite: true,
        status: 'active',
        createdAt: todayStr,
      });
      await db.medicine_batches.add({
        medicineId: m3,
        medicineName: 'Pantoprazole 40mg',
        batchNumber: 'PAN-302',
        expiryDate: in30Days, // Expiring soon
        purchasePrice: 40,
        sellingPrice: 85,
        currentStock: 12, // Low stock
        unit: 'Strip (10 Tabs)',
        createdAt: todayStr,
        updatedAt: todayStr,
      });

      const m4 = await db.medicines.add({
        name: 'Cetirizine 10mg',
        genericName: 'Cetirizine Dihydrochloride',
        strength: '10mg',
        form: 'Tablet',
        category: 'Antihistamines',
        defaultDose: '1 Tab',
        defaultFrequency: 'HS (At bedtime)',
        defaultDuration: '5 Days',
        defaultTiming: 'After Food',
        isFavorite: false,
        status: 'active',
        createdAt: todayStr,
      });
      await db.medicine_batches.add({
        medicineId: m4,
        medicineName: 'Cetirizine 10mg',
        batchNumber: 'CET-109',
        expiryDate: pastYear, // Expired sample for alert
        purchasePrice: 15,
        sellingPrice: 30,
        currentStock: 0, // Out of stock
        unit: 'Strip (10 Tabs)',
        createdAt: todayStr,
        updatedAt: todayStr,
      });

      const m5 = await db.medicines.add({
        name: 'Metformin 500mg',
        genericName: 'Metformin Hydrochloride',
        strength: '500mg',
        form: 'Tablet',
        category: 'Antidiabetic',
        defaultDose: '1 Tab',
        defaultFrequency: 'BD (Twice a day)',
        defaultDuration: '30 Days',
        defaultTiming: 'With Food',
        isFavorite: true,
        status: 'active',
        createdAt: todayStr,
      });
      await db.medicine_batches.add({
        medicineId: m5,
        medicineName: 'Metformin 500mg',
        batchNumber: 'MET-554',
        expiryDate: nextYear,
        purchasePrice: 22,
        sellingPrice: 48,
        currentStock: 80,
        unit: 'Strip (10 Tabs)',
        createdAt: todayStr,
        updatedAt: todayStr,
      });

      // 4. Patients
      const p1 = await db.patients.add({
        patientCode: 'PT-0001',
        name: 'Vikram Malhotra',
        gender: 'Male',
        dob: '1988-04-12',
        age: 38,
        phone: '9820112233',
        altPhone: '9820112234',
        email: 'vikram.m@example.com',
        bloodGroup: 'B+',
        allergies: 'Penicillin, Dust',
        address: 'Flat 402, Green Valley Enclave, Sector 14',
        city: 'Mumbai',
        emergencyContactName: 'Priya Malhotra (Wife)',
        emergencyContactPhone: '9820119988',
        notes: 'Hypertensive since 2021. Regular monitoring required.',
        createdAt: yesterday,
        updatedAt: todayStr,
      });

      const p2 = await db.patients.add({
        patientCode: 'PT-0002',
        name: 'Ananya Verma',
        gender: 'Female',
        dob: '1995-09-25',
        age: 30,
        phone: '9845033445',
        email: 'ananya.v@example.com',
        bloodGroup: 'O+',
        allergies: 'None known',
        address: 'B-12, Sunrise Residency, Ring Road',
        city: 'Mumbai',
        emergencyContactName: 'Ramesh Verma (Father)',
        emergencyContactPhone: '9845011223',
        notes: 'Complains of frequent migraine and acid reflux.',
        createdAt: todayStr,
        updatedAt: todayStr,
      });

      const p3 = await db.patients.add({
        patientCode: 'PT-0003',
        name: 'Gurpreet Singh',
        gender: 'Male',
        dob: '1965-11-03',
        age: 60,
        phone: '9811224466',
        bloodGroup: 'A+',
        allergies: 'Sulfa drugs',
        address: 'House 88, Lane 4, Model Town',
        city: 'Mumbai',
        emergencyContactName: 'Manpreet Kaur (Daughter)',
        emergencyContactPhone: '9811229988',
        notes: 'Type 2 Diabetes, Diabetic neuropathy symptoms.',
        createdAt: todayStr,
        updatedAt: todayStr,
      });

      const p4 = await db.patients.add({
        patientCode: 'PT-0004',
        name: 'Sneha Patel',
        gender: 'Female',
        dob: '2002-01-18',
        age: 24,
        phone: '9877001122',
        bloodGroup: 'AB+',
        allergies: 'None',
        address: 'Block C, Silver Palms Apt',
        city: 'Mumbai',
        emergencyContactName: 'Deepak Patel (Brother)',
        emergencyContactPhone: '9877003344',
        notes: 'Routine seasonal flu checkup.',
        createdAt: todayStr,
        updatedAt: todayStr,
      });

      // Update patient counter
      await db.counters.put({ key: 'patient_code', value: 4 });

      // 5. Appointments
      await db.appointments.bulkAdd([
        {
          patientId: p1,
          patientName: 'Vikram Malhotra',
          patientCode: 'PT-0001',
          patientPhone: '9820112233',
          doctorId: d1,
          doctorName: 'Dr. Sarah Jenkins',
          date: todayStr,
          time: '09:30',
          tokenNumber: 1,
          reason: 'Blood pressure review & mild headache',
          status: 'Waiting',
          notes: 'Vitals taken at reception',
          createdAt: todayStr,
          updatedAt: todayStr,
        },
        {
          patientId: p2,
          patientName: 'Ananya Verma',
          patientCode: 'PT-0002',
          patientPhone: '9845033445',
          doctorId: d1,
          doctorName: 'Dr. Sarah Jenkins',
          date: todayStr,
          time: '10:00',
          tokenNumber: 2,
          reason: 'Severe heartburn & acidity',
          status: 'In Consultation',
          notes: 'Previous prescription reviewed',
          createdAt: todayStr,
          updatedAt: todayStr,
        },
        {
          patientId: p3,
          patientName: 'Gurpreet Singh',
          patientCode: 'PT-0003',
          patientPhone: '9811224466',
          doctorId: d2,
          doctorName: 'Dr. Rajesh Sharma',
          date: todayStr,
          time: '11:15',
          tokenNumber: 1,
          reason: 'Knee joint pain & stiffness in morning',
          status: 'Scheduled',
          notes: 'Brought previous X-rays',
          createdAt: todayStr,
          updatedAt: todayStr,
        },
        {
          patientId: p4,
          patientName: 'Sneha Patel',
          patientCode: 'PT-0004',
          patientPhone: '9877001122',
          doctorId: d1,
          doctorName: 'Dr. Sarah Jenkins',
          date: tomorrow,
          time: '10:30',
          tokenNumber: 1,
          reason: 'Follow-up for sore throat',
          status: 'Scheduled',
          createdAt: todayStr,
          updatedAt: todayStr,
        },
      ]);

      // 6. Vitals
      await db.vitals.bulkAdd([
        {
          patientId: p1,
          recordedBy: 'Nurse Emily',
          date: todayStr,
          time: '09:20',
          weightKg: 78,
          heightCm: 175,
          bmi: 25.5,
          bloodPressureSystolic: 138,
          bloodPressureDiastolic: 88,
          pulseBpm: 76,
          temperatureF: 98.4,
          spo2Percent: 99,
          bloodSugarMgDl: 110,
          respiratoryRate: 16,
          notes: 'BP slightly elevated from normal baseline.',
          createdAt: todayStr,
        },
        {
          patientId: p2,
          recordedBy: 'Nurse Emily',
          date: todayStr,
          time: '09:50',
          weightKg: 58,
          heightCm: 162,
          bmi: 22.1,
          bloodPressureSystolic: 118,
          bloodPressureDiastolic: 78,
          pulseBpm: 82,
          temperatureF: 98.6,
          spo2Percent: 98,
          bloodSugarMgDl: 95,
          respiratoryRate: 18,
          notes: 'Vitals within normal limits.',
          createdAt: todayStr,
        },
      ]);

      // 7. Consultations
      const c1 = await db.consultations.add({
        patientId: p1,
        patientName: 'Vikram Malhotra',
        patientCode: 'PT-0001',
        doctorId: d1,
        doctorName: 'Dr. Sarah Jenkins',
        date: yesterday,
        chiefComplaint: 'Mild throbbing headache and occipital tension for 3 days',
        symptoms: 'Heaviness in head, mild dizziness on standing up quickly',
        medicalHistory: 'Known hypertensive on irregular medication',
        examination: 'CVS: S1 S2 normal. Chest: Clear. P/A: Soft, non-tender.',
        diagnosis: 'Stage 1 Essential Hypertension with tension cephalea',
        treatmentPlan: 'Lifestyle modifications, low sodium diet, BP monitoring daily',
        advice: 'Reduce dietary salt. Drink 2.5L water daily. 30 mins brisk walking.',
        followUpDate: in3Days,
        billed: true,
        createdAt: yesterday,
      });

      // 8. Prescriptions
      await db.prescriptions.add({
        patientId: p1,
        patientName: 'Vikram Malhotra',
        patientCode: 'PT-0001',
        doctorId: d1,
        doctorName: 'Dr. Sarah Jenkins',
        consultationId: c1,
        date: yesterday,
        diagnosis: 'Stage 1 Essential Hypertension with tension cephalea',
        vitalsSummary: 'BP: 138/88 mmHg, Pulse: 76 bpm, Wt: 78 kg (BMI: 25.5)',
        medicines: [
          {
            name: 'Paracetamol 650mg',
            genericName: 'Acetaminophen',
            strength: '650mg',
            form: 'Tablet',
            dose: '1 Tab',
            frequency: 'SOS (When pain occurs)',
            duration: '3 Days',
            timing: 'After Food',
            instructions: 'Take only if headache is persistent. Max 3 tabs in 24 hours.',
          },
          {
            name: 'Pantoprazole 40mg',
            genericName: 'Pantoprazole Sodium',
            strength: '40mg',
            form: 'Tablet',
            dose: '1 Tab',
            frequency: 'OD (Once daily in morning)',
            duration: '7 Days',
            timing: 'Before Food',
            instructions: 'Take 30 minutes before breakfast.',
          },
        ],
        advice: 'Avoid excess salt and pickles. Monitor BP twice daily and record in log.',
        testsAdvised: 'Serum Creatinine, Lipid Profile, ECG',
        followUpDate: in3Days,
        createdAt: yesterday,
      });

      // Prescription Templates
      await db.prescription_templates.add({
        title: 'Acute Gastritis / Acid Peptic Disease',
        diagnosis: 'Acute Gastritis / Dyspepsia',
        medicines: [
          {
            name: 'Pantoprazole 40mg',
            genericName: 'Pantoprazole Sodium',
            strength: '40mg',
            form: 'Tablet',
            dose: '1 Tab',
            frequency: 'OD',
            duration: '14 Days',
            timing: 'Before Food',
            instructions: 'Take early morning with water.',
          },
        ],
        advice: 'Avoid spicy and fried foods. Eat small frequent meals. Do not sleep immediately after dinner.',
        testsAdvised: 'USG Abdomen if pain persists',
        createdAt: todayStr,
      });

      // 9. Invoices & Payments
      const year = now.getFullYear();
      const inv1 = await db.invoices.add({
        invoiceNumber: `INV-${year}-0001`,
        patientId: p1,
        patientName: 'Vikram Malhotra',
        patientCode: 'PT-0001',
        patientPhone: '9820112233',
        doctorId: d1,
        doctorName: 'Dr. Sarah Jenkins',
        date: yesterday,
        items: [
          {
            id: 'item-1',
            description: 'Doctor Consultation Fee',
            quantity: 1,
            unitPrice: 500,
            amount: 500,
            referenceType: 'consultation',
          },
          {
            id: 'item-2',
            description: 'Vitals & Blood Pressure Check',
            quantity: 1,
            unitPrice: 100,
            amount: 100,
            referenceType: 'procedure',
          },
        ],
        subtotal: 600,
        discountAmount: 50,
        taxPercent: 0,
        taxAmount: 0,
        grandTotal: 550,
        amountPaid: 550,
        balanceDue: 0,
        status: 'Paid',
        notes: 'Full payment received at checkout.',
        createdAt: yesterday,
        updatedAt: yesterday,
      });

      await db.payments.add({
        invoiceId: inv1,
        invoiceNumber: `INV-${year}-0001`,
        patientId: p1,
        patientName: 'Vikram Malhotra',
        amount: 550,
        method: 'UPI',
        date: yesterday,
        time: '10:45',
        receivedBy: 'Receptionist Sunita',
        note: 'UPI Payment via Google Pay',
        createdAt: yesterday,
      });

      const inv2 = await db.invoices.add({
        invoiceNumber: `INV-${year}-0002`,
        patientId: p2,
        patientName: 'Ananya Verma',
        patientCode: 'PT-0002',
        patientPhone: '9845033445',
        doctorId: d1,
        doctorName: 'Dr. Sarah Jenkins',
        date: todayStr,
        items: [
          {
            id: 'item-3',
            description: 'Comprehensive Specialist Consultation',
            quantity: 1,
            unitPrice: 700,
            amount: 700,
            referenceType: 'consultation',
          },
          {
            id: 'item-4',
            description: 'Diagnostic Blood Glucose Screening',
            quantity: 1,
            unitPrice: 150,
            amount: 150,
            referenceType: 'lab',
          },
        ],
        subtotal: 850,
        discountAmount: 0,
        taxPercent: 0,
        taxAmount: 0,
        grandTotal: 850,
        amountPaid: 400,
        balanceDue: 450,
        status: 'Partial',
        notes: 'Partial payment made. Remaining 450 due next visit.',
        createdAt: todayStr,
        updatedAt: todayStr,
      });

      await db.payments.add({
        invoiceId: inv2,
        invoiceNumber: `INV-${year}-0002`,
        patientId: p2,
        patientName: 'Ananya Verma',
        amount: 400,
        method: 'Cash',
        date: todayStr,
        time: '10:15',
        receivedBy: 'Receptionist Sunita',
        note: 'Initial cash deposit',
        createdAt: todayStr,
      });

      await db.counters.put({ key: `invoice_${year}`, value: 2 });

      // 10. Pharmacy Sale
      await db.sales.add({
        receiptNumber: `REC-${year}-0001`,
        patientId: p1,
        patientName: 'Vikram Malhotra',
        date: yesterday,
        items: [
          {
            medicineId: m2,
            medicineName: 'Paracetamol 650mg',
            batchId: 2,
            batchNumber: 'PCM-884',
            quantity: 1,
            unitPrice: 35,
            total: 35,
          },
          {
            medicineId: m3,
            medicineName: 'Pantoprazole 40mg',
            batchId: 3,
            batchNumber: 'PAN-302',
            quantity: 1,
            unitPrice: 85,
            total: 85,
          },
        ],
        subtotal: 120,
        discount: 0,
        tax: 0,
        grandTotal: 120,
        paymentMethod: 'Cash',
        refunded: false,
        soldBy: 'Pharmacist Dave',
        createdAt: yesterday,
      });
      await db.counters.put({ key: `pharmacy_sale_${year}`, value: 1 });

      // 11. Suppliers & Expenses
      const s1 = await db.suppliers.add({
        name: 'Apollo Pharmaceuticals Dist.',
        companyName: 'Apollo Medisales Pvt Ltd',
        phone: '9899112233',
        email: 'orders@apollomedisales.com',
        address: '42 Industrial Area, Phase II',
        gstNumber: '27AABCU9603R1ZM',
        notes: 'Primary pharmaceutical supplier. 15 days credit terms.',
        createdAt: todayStr,
      });

      await db.expenses.bulkAdd([
        {
          category: 'Rent',
          amount: 25000,
          date: todayStr,
          paymentMethod: 'Bank',
          description: 'Clinic Premises Monthly Lease Rent',
          recordedBy: adminName,
          createdAt: todayStr,
        },
        {
          category: 'Medical Supplies',
          amount: 3450,
          date: yesterday,
          paymentMethod: 'UPI',
          description: 'Surgical Gloves, Syringes, Cotton rolls & Sanitizers',
          recordedBy: adminName,
          createdAt: yesterday,
        },
      ]);

      // 12. Follow-ups
      await db.follow_ups.bulkAdd([
        {
          patientId: p1,
          patientName: 'Vikram Malhotra',
          patientCode: 'PT-0001',
          patientPhone: '9820112233',
          doctorId: d1,
          doctorName: 'Dr. Sarah Jenkins',
          followUpDate: in3Days,
          reason: 'Blood pressure check and review lab blood tests',
          isDone: false,
          createdAt: yesterday,
        },
        {
          patientId: p2,
          patientName: 'Ananya Verma',
          patientCode: 'PT-0002',
          patientPhone: '9845033445',
          doctorId: d1,
          doctorName: 'Dr. Sarah Jenkins',
          followUpDate: todayStr,
          reason: 'Assess response to PPI antacid treatment',
          isDone: false,
          createdAt: yesterday,
        },
      ]);

      // 13. Attendance
      await db.attendance.bulkAdd([
        {
          staffName: 'Dr. Sarah Jenkins',
          role: 'Doctor',
          date: todayStr,
          clockInTime: '08:55',
          status: 'Present',
          note: 'Morning shift on time',
          createdAt: todayStr,
        },
        {
          staffName: 'Sunita Rao',
          role: 'Receptionist',
          date: todayStr,
          clockInTime: '08:45',
          status: 'Present',
          note: 'Front desk ready',
          createdAt: todayStr,
        },
        {
          staffName: 'David Lee',
          role: 'Pharmacist',
          date: todayStr,
          clockInTime: '09:05',
          status: 'Present',
          note: 'Pharmacy open',
          createdAt: todayStr,
        },
      ]);

      // 14. Payslips
      const currentMonth = todayStr.substring(0, 7);
      await db.payslips.add({
        staffName: 'Sunita Rao',
        role: 'Receptionist',
        monthYear: currentMonth,
        baseSalary: 22000,
        allowances: 2000,
        bonus: 1000,
        deductions: 500,
        netSalary: 24500,
        status: 'Paid',
        paymentDate: todayStr,
        paymentMethod: 'Bank',
        notes: 'Disbursed via direct NEFT',
        createdAt: todayStr,
      });

      await logActivity(adminName, 'admin', 'Load Demo Data', 'Settings', 'Populated comprehensive demo clinical and financial records');
    }
  );
}

export async function clearAllDemoData(adminName: string): Promise<void> {
  await db.transaction(
    'rw',
    [
      db.patients,
      db.appointments,
      db.vitals,
      db.consultations,
      db.prescriptions,
      db.medicines,
      db.medicine_batches,
      db.stock_movements,
      db.suppliers,
      db.purchases,
      db.sales,
      db.categories,
      db.invoices,
      db.payments,
      db.expenses,
      db.payslips,
      db.attendance,
      db.documents,
      db.follow_ups,
      db.counters,
      db.activity_logs,
    ],
    async () => {
      await Promise.all([
        db.patients.clear(),
        db.appointments.clear(),
        db.vitals.clear(),
        db.consultations.clear(),
        db.prescriptions.clear(),
        db.medicines.clear(),
        db.medicine_batches.clear(),
        db.stock_movements.clear(),
        db.suppliers.clear(),
        db.purchases.clear(),
        db.sales.clear(),
        db.categories.clear(),
        db.invoices.clear(),
        db.payments.clear(),
        db.expenses.clear(),
        db.payslips.clear(),
        db.attendance.clear(),
        db.documents.clear(),
        db.follow_ups.clear(),
        db.counters.clear(),
      ]);

      await logActivity(adminName, 'admin', 'Clear Demo Data', 'Settings', 'Cleaned all demo data while preserving system accounts');
    }
  );
}

export const clearAllClinicData = clearAllDemoData;
