import Dexie, { type Table } from 'dexie';
import type {
  User,
  SecurityCredentials,
  ClinicSettings,
  Patient,
  Doctor,
  Appointment,
  Vitals,
  Consultation,
  Prescription,
  PrescriptionTemplate,
  Medicine,
  MedicineBatch,
  StockMovement,
  Supplier,
  Purchase,
  PharmacySale,
  Invoice,
  Payment,
  Expense,
  Payslip,
  Attendance,
  MedicalDocument,
  FollowUp,
  ActivityLog,
  Counter,
} from '../types';

export class ClinicDatabase extends Dexie {
  users!: Table<User, number>;
  security_credentials!: Table<SecurityCredentials, number>;
  clinic_settings!: Table<ClinicSettings, number>;
  patients!: Table<Patient, number>;
  doctors!: Table<Doctor, number>;
  appointments!: Table<Appointment, number>;
  vitals!: Table<Vitals, number>;
  consultations!: Table<Consultation, number>;
  prescriptions!: Table<Prescription, number>;
  prescription_templates!: Table<PrescriptionTemplate, number>;
  medicines!: Table<Medicine, number>;
  medicine_batches!: Table<MedicineBatch, number>;
  stock_movements!: Table<StockMovement, number>;
  suppliers!: Table<Supplier, number>;
  purchases!: Table<Purchase, number>;
  sales!: Table<PharmacySale, number>;
  get pharmacy_sales(): Table<PharmacySale, number> {
    return this.sales;
  }
  categories!: Table<{ id?: number; name: string; type: string }, number>;
  invoices!: Table<Invoice, number>;
  payments!: Table<Payment, number>;
  expenses!: Table<Expense, number>;
  payslips!: Table<Payslip, number>;
  attendance!: Table<Attendance, number>;
  documents!: Table<MedicalDocument, number>;
  follow_ups!: Table<FollowUp, number>;
  activity_logs!: Table<ActivityLog, number>;
  counters!: Table<Counter, number>;

  constructor() {
    super('ClinicManagementDB');

    this.version(1).stores({
      users: '++id, &username, role, active',
      security_credentials: '++id, &userId',
      clinic_settings: '++id',
      patients: '++id, &patientCode, name, phone, createdAt',
      doctors: '++id, name, status',
      appointments: '++id, patientId, doctorId, date, time, status, [doctorId+date]',
      vitals: '++id, patientId, date',
      consultations: '++id, patientId, doctorId, date, billed',
      prescriptions: '++id, patientId, doctorId, date',
      prescription_templates: '++id, title',
      medicines: '++id, name, genericName, category, isFavorite, status',
      medicine_batches: '++id, medicineId, batchNumber, expiryDate',
      stock_movements: '++id, medicineId, type, date',
      suppliers: '++id, name',
      purchases: '++id, supplierId, date',
      sales: '++id, &receiptNumber, date, refunded',
      categories: '++id, name, type',
      invoices: '++id, &invoiceNumber, patientId, doctorId, date, status',
      payments: '++id, invoiceId, patientId, date',
      expenses: '++id, category, date',
      payslips: '++id, staffName, monthYear, status',
      attendance: '++id, staffName, date, status',
      documents: '++id, patientId, documentType, date',
      follow_ups: '++id, patientId, followUpDate, isDone',
      activity_logs: '++id, userName, module, timestamp',
      counters: '++id, &key',
    });
  }
}

export const db = new ClinicDatabase();
