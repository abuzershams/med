import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ToastProvider } from './context/ToastContext';
import { ClinicProvider } from './context/ClinicContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppLayout } from './components/layout/AppLayout';
import { LoadingSpinner } from './components/common/EmptyState';

// Auth Pages
import { Login } from './pages/auth/Login';
import { SetupWizard } from './pages/auth/SetupWizard';
import { ForgotPassword } from './pages/auth/ForgotPassword';

// Application Pages
import { DashboardPage } from './pages/dashboard/DashboardPage';
import { PatientsPage } from './pages/patients/PatientsPage';
import { PatientProfilePage } from './pages/patients/PatientProfilePage';
import { AppointmentsPage } from './pages/appointments/AppointmentsPage';
import { DoctorsPage } from './pages/doctors/DoctorsPage';
import { PrescriptionsPage } from './pages/prescriptions/PrescriptionsPage';
import { MedicinesPage } from './pages/medicines/MedicinesPage';
import { PharmacyPOSPage } from './pages/pharmacy/PharmacyPOSPage';
import { InvoicesPage } from './pages/billing/InvoicesPage';
import { FinancePage } from './pages/finance/FinancePage';
import { FollowupsPage } from './pages/followups/FollowupsPage';
import { AttendancePage } from './pages/attendance/AttendancePage';
import { ReportsPage } from './pages/reports/ReportsPage';
import { ActivityLogsPage } from './pages/activity-logs/ActivityLogsPage';
import { UsersPage } from './pages/users/UsersPage';
import { SettingsPage } from './pages/settings/SettingsPage';
import { MyAccountPage } from './pages/account/MyAccountPage';

// Route Guard component
const ProtectedRoute: React.FC<{
  permission?:
    | 'dashboard'
    | 'patients'
    | 'appointments'
    | 'doctors'
    | 'prescriptions'
    | 'medicines'
    | 'pharmacy'
    | 'billing'
    | 'finance'
    | 'followups'
    | 'attendance'
    | 'reports'
    | 'activityLogs'
    | 'users'
    | 'settings';
  element: React.ReactElement;
}> = ({ permission, element }) => {
  const { checkPermission } = useAuth();
  if (permission && !checkPermission(permission)) {
    if (permission !== 'dashboard') {
      return <Navigate to="/" replace />;
    }
    return (
      <div className="p-8 text-center text-slate-500">
        You do not have permission to view the dashboard.
      </div>
    );
  }
  return element;
};

const AppContent: React.FC = () => {
  const { hasAdmin, isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <LoadingSpinner size="lg" message="Initializing offline medical database..." />
      </div>
    );
  }

  // If no admin exists yet, force first-launch setup
  if (!hasAdmin) {
    return (
      <Routes>
        <Route path="/setup" element={<SetupWizard />} />
        <Route path="*" element={<Navigate to="/setup" replace />} />
      </Routes>
    );
  }

  // If admin exists but user is not logged in, show auth routes
  if (!isAuthenticated) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    );
  }

  // Authenticated: Main App layout and protected routes
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<ProtectedRoute permission="dashboard" element={<DashboardPage />} />} />
        <Route path="/login" element={<Navigate to="/" replace />} />
        <Route path="/setup" element={<Navigate to="/" replace />} />
        <Route path="/patients" element={<ProtectedRoute permission="patients" element={<PatientsPage />} />} />
        <Route path="/patients/:id" element={<ProtectedRoute permission="patients" element={<PatientProfilePage />} />} />
        <Route path="/appointments" element={<ProtectedRoute permission="appointments" element={<AppointmentsPage />} />} />
        <Route path="/doctors" element={<ProtectedRoute permission="doctors" element={<DoctorsPage />} />} />
        <Route path="/prescriptions" element={<ProtectedRoute permission="prescriptions" element={<PrescriptionsPage />} />} />
        <Route path="/medicines" element={<ProtectedRoute permission="medicines" element={<MedicinesPage />} />} />
        <Route path="/pharmacy" element={<ProtectedRoute permission="pharmacy" element={<PharmacyPOSPage />} />} />
        <Route path="/invoices" element={<ProtectedRoute permission="billing" element={<InvoicesPage />} />} />
        <Route path="/finance" element={<ProtectedRoute permission="finance" element={<FinancePage />} />} />
        <Route path="/followups" element={<ProtectedRoute permission="followups" element={<FollowupsPage />} />} />
        <Route path="/attendance" element={<ProtectedRoute permission="attendance" element={<AttendancePage />} />} />
        <Route path="/reports" element={<ProtectedRoute permission="reports" element={<ReportsPage />} />} />
        <Route path="/activity-logs" element={<ProtectedRoute permission="activityLogs" element={<ActivityLogsPage />} />} />
        <Route path="/users" element={<ProtectedRoute permission="users" element={<UsersPage />} />} />
        <Route path="/settings" element={<ProtectedRoute permission="settings" element={<SettingsPage />} />} />
        <Route path="/account" element={<MyAccountPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
};

export default function App() {
  return (
    <ToastProvider>
      <ClinicProvider>
        <AuthProvider>
          <HashRouter>
            <AppContent />
          </HashRouter>
        </AuthProvider>
      </ClinicProvider>
    </ToastProvider>
  );
}
