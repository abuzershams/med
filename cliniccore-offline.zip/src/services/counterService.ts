import { db } from '../db/database';

export async function getNextPatientCode(): Promise<string> {
  return await db.transaction('rw', db.counters, async () => {
    const counterKey = 'patient_code';
    let record = await db.counters.where('key').equals(counterKey).first();
    let nextValue = 1;

    if (record && record.value) {
      nextValue = record.value + 1;
      await db.counters.update(record.id!, { value: nextValue });
    } else {
      await db.counters.add({ key: counterKey, value: 1 });
    }

    return `PT-${String(nextValue).padStart(4, '0')}`;
  });
}

export async function getNextInvoiceNumber(prefix = 'INV'): Promise<string> {
  const currentYear = new Date().getFullYear();
  const counterKey = `invoice_${currentYear}`;

  return await db.transaction('rw', db.counters, async () => {
    let record = await db.counters.where('key').equals(counterKey).first();
    let nextValue = 1;

    if (record && record.value) {
      nextValue = record.value + 1;
      await db.counters.update(record.id!, { value: nextValue });
    } else {
      await db.counters.add({ key: counterKey, value: 1 });
    }

    return `${prefix}-${currentYear}-${String(nextValue).padStart(4, '0')}`;
  });
}

export async function getNextSaleReceiptNumber(): Promise<string> {
  const currentYear = new Date().getFullYear();
  const counterKey = `pharmacy_sale_${currentYear}`;

  return await db.transaction('rw', db.counters, async () => {
    let record = await db.counters.where('key').equals(counterKey).first();
    let nextValue = 1;

    if (record && record.value) {
      nextValue = record.value + 1;
      await db.counters.update(record.id!, { value: nextValue });
    } else {
      await db.counters.add({ key: counterKey, value: 1 });
    }

    return `REC-${currentYear}-${String(nextValue).padStart(4, '0')}`;
  });
}

export const getNextReceiptNumber = getNextSaleReceiptNumber;
