import { db } from '../db/database';

export async function logActivity(
  userName: string,
  userRole: string,
  action: string,
  module: string,
  details: string
): Promise<void> {
  try {
    await db.activity_logs.add({
      userName: userName || 'System',
      userRole: userRole || 'system',
      action,
      module,
      details,
      timestamp: new Date().toISOString(),
    });
  } catch {
    // Non-blocking for UI
  }
}
