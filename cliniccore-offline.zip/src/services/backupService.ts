import { db } from '../db/database';
import { logActivity } from './auditService';

// Helper to convert Blob to base64
async function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      // result is "data:mime;base64,...."
      const base64 = result.split(',')[1] || '';
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// Helper to convert base64 back to Blob
function base64ToBlob(base64: string, mimeType: string): Blob {
  const byteCharacters = atob(base64);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  return new Blob([byteArray], { type: mimeType });
}

export async function exportDatabaseBackup(currentUserName: string, userRole = 'admin'): Promise<void> {
  const allDocs = await db.documents.toArray();
  const serializedDocs = await Promise.all(
    allDocs.map(async (doc) => ({
      ...doc,
      fileDataBlob: undefined,
      base64Data: await blobToBase64(doc.fileDataBlob),
    }))
  );

  const backupData = {
    version: 1,
    exportTimestamp: new Date().toISOString(),
    appName: 'Clinic Management System',
    tables: {
      users: await db.users.toArray(),
      security_credentials: await db.security_credentials.toArray(),
      clinic_settings: await db.clinic_settings.toArray(),
      patients: await db.patients.toArray(),
      doctors: await db.doctors.toArray(),
      appointments: await db.appointments.toArray(),
      vitals: await db.vitals.toArray(),
      consultations: await db.consultations.toArray(),
      prescriptions: await db.prescriptions.toArray(),
      prescription_templates: await db.prescription_templates.toArray(),
      medicines: await db.medicines.toArray(),
      medicine_batches: await db.medicine_batches.toArray(),
      stock_movements: await db.stock_movements.toArray(),
      suppliers: await db.suppliers.toArray(),
      purchases: await db.purchases.toArray(),
      sales: await db.sales.toArray(),
      categories: await db.categories.toArray(),
      invoices: await db.invoices.toArray(),
      payments: await db.payments.toArray(),
      expenses: await db.expenses.toArray(),
      payslips: await db.payslips.toArray(),
      attendance: await db.attendance.toArray(),
      documents: serializedDocs,
      follow_ups: await db.follow_ups.toArray(),
      activity_logs: await db.activity_logs.toArray(),
      counters: await db.counters.toArray(),
    },
  };

  // Stamp last backup date in clinic_settings
  const settings = await db.clinic_settings.toCollection().first();
  if (settings && settings.id) {
    await db.clinic_settings.update(settings.id, { lastBackupDate: new Date().toISOString() });
  }

  await logActivity(currentUserName, userRole, 'Export Backup', 'Settings', 'Downloaded full database JSON backup');

  const jsonStr = JSON.stringify(backupData, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  const dateStr = new Date().toISOString().split('T')[0];
  link.href = url;
  link.download = `clinic_backup_${dateStr}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export async function restoreDatabaseBackup(
  jsonInput: File | string,
  currentUserName: string,
  userRole = 'admin'
): Promise<{ success: boolean; message: string }> {
  try {
    const text = typeof jsonInput === 'string' ? jsonInput : await jsonInput.text();
    const parsed = JSON.parse(text);

    if (!parsed.appName || !parsed.tables || !parsed.tables.users) {
      throw new Error('Invalid backup file. Missing required clinic database tables.');
    }

    const { tables } = parsed;

    // Convert documents base64 back to Blobs
    const restoredDocs = (tables.documents || []).map((doc: any) => {
      const blob = doc.base64Data ? base64ToBlob(doc.base64Data, doc.mimeType || 'application/octet-stream') : new Blob([]);
      const { base64Data, ...rest } = doc;
      return {
        ...rest,
        fileDataBlob: blob,
      };
    });

    // Execute atomic restoration transaction
    await db.transaction(
      'rw',
      [
        db.users,
        db.security_credentials,
        db.clinic_settings,
        db.patients,
        db.doctors,
        db.appointments,
        db.vitals,
        db.consultations,
        db.prescriptions,
        db.prescription_templates,
        db.medicines,
        db.medicine_batches,
        db.stock_movements,
        db.suppliers,
        db.purchases,
        db.sales,
        db.categories,
        db.invoices,
        db.payments,
        db.expenses,
        db.payslips,
        db.attendance,
        db.documents,
        db.follow_ups,
        db.activity_logs,
        db.counters,
      ],
      async () => {
        // Clear all tables
        await Promise.all([
          db.users.clear(),
          db.security_credentials.clear(),
          db.clinic_settings.clear(),
          db.patients.clear(),
          db.doctors.clear(),
          db.appointments.clear(),
          db.vitals.clear(),
          db.consultations.clear(),
          db.prescriptions.clear(),
          db.prescription_templates.clear(),
          db.medicines.clear(),
          db.medicine_batches.clear(),
          db.stock_movements.clear(),
          db.suppliers.clear(),
          db.purchases.clear(),
          db.sales.clear(),
          db.categories.clear(),
          db.invoices.clear(),
          db.payments.clear(),
          db.expenses.clear(),
          db.payslips.clear(),
          db.attendance.clear(),
          db.documents.clear(),
          db.follow_ups.clear(),
          db.activity_logs.clear(),
          db.counters.clear(),
        ]);

        // Re-populate all tables
        if (tables.users?.length) await db.users.bulkAdd(tables.users);
        if (tables.security_credentials?.length) await db.security_credentials.bulkAdd(tables.security_credentials);
        if (tables.clinic_settings?.length) await db.clinic_settings.bulkAdd(tables.clinic_settings);
        if (tables.patients?.length) await db.patients.bulkAdd(tables.patients);
        if (tables.doctors?.length) await db.doctors.bulkAdd(tables.doctors);
        if (tables.appointments?.length) await db.appointments.bulkAdd(tables.appointments);
        if (tables.vitals?.length) await db.vitals.bulkAdd(tables.vitals);
        if (tables.consultations?.length) await db.consultations.bulkAdd(tables.consultations);
        if (tables.prescriptions?.length) await db.prescriptions.bulkAdd(tables.prescriptions);
        if (tables.prescription_templates?.length) await db.prescription_templates.bulkAdd(tables.prescription_templates);
        if (tables.medicines?.length) await db.medicines.bulkAdd(tables.medicines);
        if (tables.medicine_batches?.length) await db.medicine_batches.bulkAdd(tables.medicine_batches);
        if (tables.stock_movements?.length) await db.stock_movements.bulkAdd(tables.stock_movements);
        if (tables.suppliers?.length) await db.suppliers.bulkAdd(tables.suppliers);
        if (tables.purchases?.length) await db.purchases.bulkAdd(tables.purchases);
        if (tables.sales?.length) await db.sales.bulkAdd(tables.sales);
        if (tables.categories?.length) await db.categories.bulkAdd(tables.categories);
        if (tables.invoices?.length) await db.invoices.bulkAdd(tables.invoices);
        if (tables.payments?.length) await db.payments.bulkAdd(tables.payments);
        if (tables.expenses?.length) await db.expenses.bulkAdd(tables.expenses);
        if (tables.payslips?.length) await db.payslips.bulkAdd(tables.payslips);
        if (tables.attendance?.length) await db.attendance.bulkAdd(tables.attendance);
        if (restoredDocs?.length) await db.documents.bulkAdd(restoredDocs);
        if (tables.follow_ups?.length) await db.follow_ups.bulkAdd(tables.follow_ups);
        if (tables.activity_logs?.length) await db.activity_logs.bulkAdd(tables.activity_logs);
        if (tables.counters?.length) await db.counters.bulkAdd(tables.counters);
      }
    );

    // Update last backup date
    const settings = await db.clinic_settings.toCollection().first();
    if (settings && settings.id) {
      await db.clinic_settings.update(settings.id, { lastBackupDate: new Date().toISOString() });
    }

    const fileName = typeof jsonInput === 'object' && 'name' in jsonInput ? jsonInput.name : 'backup.json';
    await logActivity(currentUserName, userRole, 'Restore Backup', 'Settings', `Restored database from ${fileName}`);
    return { success: true, message: 'Database restored successfully!' };
  } catch (err: any) {
    return { success: false, message: err.message || 'Failed to restore backup.' };
  }
}

export const importDatabaseBackup = restoreDatabaseBackup;

export function isBackupOverdue(lastBackupDate?: string): boolean {
  if (!lastBackupDate) return true;
  const last = new Date(lastBackupDate).getTime();
  const now = Date.now();
  const diffDays = (now - last) / (1000 * 60 * 60 * 24);
  return diffDays >= 7;
}
