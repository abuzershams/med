import bcrypt from 'bcryptjs';
import { db } from '../db/database';
import type { User, UserRole, ClinicSettings } from '../types';
import { logActivity } from './auditService';

const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 5 * 60 * 1000; // 5 minutes

export interface LockoutStatus {
  isLocked: boolean;
  remainingSeconds: number;
}

export function getLockoutStatus(): LockoutStatus {
  try {
    const raw = localStorage.getItem('clinic_auth_lockout');
    if (!raw) return { isLocked: false, remainingSeconds: 0 };
    const parsed = JSON.parse(raw);
    const now = Date.now();
    if (parsed.lockedUntil && parsed.lockedUntil > now) {
      const remaining = Math.ceil((parsed.lockedUntil - now) / 1000);
      return { isLocked: true, remainingSeconds: remaining };
    }
    // expired
    localStorage.removeItem('clinic_auth_lockout');
    return { isLocked: false, remainingSeconds: 0 };
  } catch {
    return { isLocked: false, remainingSeconds: 0 };
  }
}

export function recordFailedAttempt(): { attempts: number; isLocked: boolean; remainingSeconds: number } {
  try {
    const raw = localStorage.getItem('clinic_auth_lockout');
    let attempts = 1;
    if (raw) {
      const parsed = JSON.parse(raw);
      attempts = (parsed.attempts || 0) + 1;
    }

    if (attempts >= MAX_LOGIN_ATTEMPTS) {
      const lockedUntil = Date.now() + LOCKOUT_DURATION_MS;
      localStorage.setItem('clinic_auth_lockout', JSON.stringify({ attempts, lockedUntil }));
      return { attempts, isLocked: true, remainingSeconds: 300 };
    } else {
      localStorage.setItem('clinic_auth_lockout', JSON.stringify({ attempts, lockedUntil: 0 }));
      return { attempts, isLocked: false, remainingSeconds: 0 };
    }
  } catch {
    return { attempts: 1, isLocked: false, remainingSeconds: 0 };
  }
}

export function clearFailedAttempts(): void {
  try {
    localStorage.removeItem('clinic_auth_lockout');
  } catch {
    // Ignore
  }
}

export function generateRecoveryKey(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let key = 'REC-';
  for (let i = 0; i < 8; i++) {
    if (i === 4) key += '-';
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return key; // e.g. REC-XXXX-XXXX (12 chars total)
}

export async function hasAdminAccount(): Promise<boolean> {
  const admin = await db.users.where('role').equals('admin').first();
  return Boolean(admin);
}

export async function setupFirstClinic(data: {
  doctorName: string;
  degree: string;
  specialization: string;
  registrationNumber: string;
  doctorPhone: string;
  doctorEmail?: string;
  clinicName: string;
  clinicAddress: string;
  clinicCity: string;
  clinicPhone: string;
  workingHours: string;
  consultationFee: number;
  logoBase64?: string;
  username: string;
  password: string;
  securityQuestion: string;
  securityAnswer: string;
  recoveryKey: string;
}): Promise<User> {
  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(data.password, salt);
  const recoveryKeyHash = bcrypt.hashSync(data.recoveryKey.trim().toUpperCase(), salt);
  const securityAnswerHash = bcrypt.hashSync(data.securityAnswer.trim().toLowerCase(), salt);

  return await db.transaction('rw', [db.users, db.security_credentials, db.clinic_settings, db.doctors, db.activity_logs], async () => {
    // 1. Create admin user
    const now = new Date().toISOString();
    const userId = await db.users.add({
      name: data.doctorName,
      username: data.username.trim(),
      passwordHash,
      role: 'admin',
      phone: data.doctorPhone,
      email: data.doctorEmail,
      active: true,
      createdAt: now,
      updatedAt: now,
    });

    // 2. Store security credentials
    await db.security_credentials.add({
      userId,
      recoveryKeyHash,
      securityQuestion: data.securityQuestion,
      securityAnswerHash,
    });

    // 3. Store clinic settings
    await db.clinic_settings.add({
      clinicName: data.clinicName,
      doctorName: data.doctorName,
      degree: data.degree,
      specialization: data.specialization,
      registrationNumber: data.registrationNumber,
      phone: data.clinicPhone,
      whatsapp: data.doctorPhone,
      email: data.doctorEmail,
      address: data.clinicAddress,
      city: data.clinicCity,
      workingHours: data.workingHours || '09:00 AM - 08:00 PM',
      currencySymbol: '₹',
      defaultConsultationFee: data.consultationFee || 500,
      taxEnabled: false,
      taxPercent: 0,
      paperSize: 'A4',
      idleTimeoutMinutes: 30,
      lowStockThreshold: 15,
      expiryAlertDays: 60,
      invoicePrefix: 'INV',
      invoiceFooterText: 'Thank you for choosing our clinic. Wishing you good health!',
      prescriptionFooterText: 'Please take medicines strictly as advised. Consult immediately if symptoms persist.',
      logoBase64: data.logoBase64,
      lastBackupDate: undefined,
    });

    // 4. Create doctor entry in doctors directory
    await db.doctors.add({
      name: data.doctorName,
      degree: data.degree,
      specialization: data.specialization,
      registrationNumber: data.registrationNumber,
      phone: data.doctorPhone,
      email: data.doctorEmail,
      room: 'Room 1',
      consultationFee: data.consultationFee || 500,
      status: 'active',
      createdAt: now,
    });

    await logActivity(data.username, 'admin', 'Setup Clinic Account', 'Auth', 'Initialized clinic and primary admin account');

    const createdUser = await db.users.get(userId);
    return createdUser!;
  });
}

export async function loginUser(username: string, password: string): Promise<User> {
  const lockout = getLockoutStatus();
  if (lockout.isLocked) {
    throw new Error(`Account locked due to multiple failed attempts. Please wait ${lockout.remainingSeconds} seconds.`);
  }

  const cleanUser = username.trim();
  // Try exact match first, then case-insensitive search
  let user = await db.users.where('username').equals(cleanUser).first();
  if (!user) {
    const allUsers = await db.users.toArray();
    user = allUsers.find((u) => u.username.toLowerCase() === cleanUser.toLowerCase());
  }

  if (!user) {
    const status = recordFailedAttempt();
    if (status.isLocked) {
      throw new Error(`Invalid credentials. Account locked for 5 minutes.`);
    }
    const remainingAttempts = MAX_LOGIN_ATTEMPTS - status.attempts;
    throw new Error(`Invalid username or password. (${remainingAttempts} attempt${remainingAttempts === 1 ? '' : 's'} remaining)`);
  }

  // Check active flag or status
  const isActive = user.active !== false && user.status !== 'inactive';
  if (!isActive) {
    throw new Error('This user account has been disabled. Please contact the administrator.');
  }

  const isMatch = bcrypt.compareSync(password, user.passwordHash);
  if (!isMatch) {
    const status = recordFailedAttempt();
    if (status.isLocked) {
      throw new Error(`Invalid credentials. Account locked for 5 minutes.`);
    }
    const remainingAttempts = MAX_LOGIN_ATTEMPTS - status.attempts;
    throw new Error(`Invalid username or password. (${remainingAttempts} attempt${remainingAttempts === 1 ? '' : 's'} remaining)`);
  }

  clearFailedAttempts();
  await logActivity(user.username, user.role, 'User Login', 'Auth', 'Successful login');
  return user;
}

export async function resetPasswordWithRecoveryKey(
  username: string,
  recoveryKey: string,
  newPassword: string
): Promise<void> {
  const user = await db.users.where('username').equals(username.trim()).first();
  if (!user) throw new Error('User not found.');

  const creds = await db.security_credentials.where('userId').equals(user.id!).first();
  if (!creds) throw new Error('Recovery credentials not found for this user.');

  const isKeyValid = bcrypt.compareSync(recoveryKey.trim().toUpperCase(), creds.recoveryKeyHash);
  if (!isKeyValid) {
    throw new Error('Invalid Recovery Key. Please check the 12-character key you saved during setup.');
  }

  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(newPassword, salt);
  await db.users.update(user.id!, {
    passwordHash,
    updatedAt: new Date().toISOString(),
  });

  clearFailedAttempts();
  await logActivity(user.username, user.role, 'Password Reset', 'Auth', 'Password reset using Recovery Key');
}

export async function resetPasswordWithSecurityQuestion(
  username: string,
  securityAnswer: string,
  newPassword: string
): Promise<void> {
  const user = await db.users.where('username').equals(username.trim()).first();
  if (!user) throw new Error('User not found.');

  const creds = await db.security_credentials.where('userId').equals(user.id!).first();
  if (!creds) throw new Error('Recovery credentials not found for this user.');

  const isAnswerValid = bcrypt.compareSync(securityAnswer.trim().toLowerCase(), creds.securityAnswerHash);
  if (!isAnswerValid) {
    throw new Error('Incorrect answer to the security question.');
  }

  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(newPassword, salt);
  await db.users.update(user.id!, {
    passwordHash,
    updatedAt: new Date().toISOString(),
  });

  clearFailedAttempts();
  await logActivity(user.username, user.role, 'Password Reset', 'Auth', 'Password reset using Security Question');
}

export async function getUserSecurityQuestion(username: string): Promise<string> {
  const user = await db.users.where('username').equals(username.trim()).first();
  if (!user) throw new Error('User not found.');

  const creds = await db.security_credentials.where('userId').equals(user.id!).first();
  if (!creds) throw new Error('No security question configured for this user.');

  return creds.securityQuestion;
}

// Role Permissions Matrix
export const ROLE_PERMISSIONS: Record<
  UserRole,
  {
    dashboard: boolean;
    patients: boolean;
    doctors: boolean;
    appointments: boolean;
    vitals: boolean;
    consultations: boolean;
    prescriptions: boolean;
    medicines: boolean;
    pharmacy: boolean;
    billing: boolean;
    finance: boolean;
    documents: boolean;
    followups: boolean;
    attendance: boolean;
    reports: boolean;
    activityLogs: boolean;
    users: boolean;
    settings: boolean;
  }
> = {
  admin: {
    dashboard: true,
    patients: true,
    doctors: true,
    appointments: true,
    vitals: true,
    consultations: true,
    prescriptions: true,
    medicines: true,
    pharmacy: true,
    billing: true,
    finance: true,
    documents: true,
    followups: true,
    attendance: true,
    reports: true,
    activityLogs: true,
    users: true,
    settings: true,
  },
  doctor: {
    dashboard: true,
    patients: true,
    doctors: true,
    appointments: true,
    vitals: true,
    consultations: true,
    prescriptions: true,
    medicines: true,
    pharmacy: false,
    billing: false,
    finance: false,
    documents: true,
    followups: true,
    attendance: true,
    reports: true,
    activityLogs: false,
    users: false,
    settings: false,
  },
  receptionist: {
    dashboard: true,
    patients: true,
    doctors: true,
    appointments: true,
    vitals: true,
    consultations: false,
    prescriptions: false,
    medicines: false,
    pharmacy: false,
    billing: true,
    finance: false,
    documents: true,
    followups: true,
    attendance: true,
    reports: true,
    activityLogs: false,
    users: false,
    settings: false,
  },
  pharmacist: {
    dashboard: true,
    patients: false,
    doctors: false,
    appointments: false,
    vitals: false,
    consultations: false,
    prescriptions: true,
    medicines: true,
    pharmacy: true,
    billing: false,
    finance: false,
    documents: false,
    followups: false,
    attendance: true,
    reports: true,
    activityLogs: false,
    users: false,
    settings: false,
  },
  staff: {
    dashboard: true,
    patients: true,
    doctors: false,
    appointments: true,
    vitals: true,
    consultations: false,
    prescriptions: false,
    medicines: false,
    pharmacy: false,
    billing: false,
    finance: false,
    documents: false,
    followups: false,
    attendance: true,
    reports: false,
    activityLogs: false,
    users: false,
    settings: false,
  },
};

export function hasPermission(role: UserRole, module: keyof typeof ROLE_PERMISSIONS['admin']): boolean {
  return Boolean(ROLE_PERMISSIONS[role]?.[module]);
}
