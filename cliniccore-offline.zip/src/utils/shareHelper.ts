import { Share } from '@capacitor/share';

export async function shareDocument(title: string, text: string, pdfBlob?: Blob, fallbackDownloadName?: string): Promise<void> {
  try {
    // Check if Capacitor Share is available
    const canShare = await Share.canShare();
    if (canShare.value) {
      await Share.share({
        title,
        text,
        dialogTitle: `Share ${title}`,
      });
      return;
    }
  } catch {
    // Ignore and fallback
  }

  // Web Share API fallback if supported
  if (navigator.share) {
    try {
      await navigator.share({
        title,
        text,
      });
      return;
    } catch {
      // User cancelled or not supported
    }
  }

  // Fallback to downloading the file
  if (pdfBlob && fallbackDownloadName) {
    const url = URL.createObjectURL(pdfBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fallbackDownloadName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}
