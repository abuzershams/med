import React from 'react';

export type BadgeVariant =
  | 'success'
  | 'warning'
  | 'danger'
  | 'info'
  | 'neutral'
  | 'purple'
  | 'teal';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  size?: 'sm' | 'md';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  size = 'md',
  className = '',
}) => {
  const variantStyles: Record<BadgeVariant, string> = {
    success: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    warning: 'bg-amber-50 text-amber-700 border-amber-200',
    danger: 'bg-rose-50 text-rose-700 border-rose-200',
    info: 'bg-blue-50 text-blue-700 border-blue-200',
    neutral: 'bg-slate-100 text-slate-700 border-slate-200',
    purple: 'bg-purple-50 text-purple-700 border-purple-200',
    teal: 'bg-teal-50 text-teal-700 border-teal-200',
  };

  const sizeStyles = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-1 text-xs',
  };

  return (
    <span
      className={`inline-flex items-center font-medium rounded-full border ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
    >
      {children}
    </span>
  );
};

// Automatic status badge mapper for Appointments, Invoices, Stock
export const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const lower = status.toLowerCase();

  if (lower === 'paid' || lower === 'completed' || lower === 'active' || lower === 'present') {
    return <Badge variant="success">{status}</Badge>;
  }
  if (lower === 'partial' || lower === 'waiting' || lower === 'in consultation' || lower === 'low stock' || lower === 'late') {
    return <Badge variant="warning">{status}</Badge>;
  }
  if (lower === 'pending' || lower === 'scheduled') {
    return <Badge variant="info">{status}</Badge>;
  }
  if (lower === 'cancelled' || lower === 'out of stock' || lower === 'expired' || lower === 'absent' || lower === 'inactive') {
    return <Badge variant="danger">{status}</Badge>;
  }
  if (lower === 'no-show') {
    return <Badge variant="purple">{status}</Badge>;
  }
  return <Badge variant="neutral">{status}</Badge>;
};
