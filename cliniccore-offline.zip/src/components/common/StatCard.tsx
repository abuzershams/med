import React from 'react';
import type { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  colorScheme?: 'blue' | 'emerald' | 'amber' | 'rose' | 'purple' | 'teal';
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  colorScheme = 'blue',
  onClick,
}) => {
  const schemeStyles = {
    blue: {
      bg: 'bg-blue-50/80',
      iconBg: 'bg-blue-600',
      border: 'border-blue-100',
      text: 'text-blue-900',
    },
    emerald: {
      bg: 'bg-emerald-50/80',
      iconBg: 'bg-emerald-600',
      border: 'border-emerald-100',
      text: 'text-emerald-900',
    },
    amber: {
      bg: 'bg-amber-50/80',
      iconBg: 'bg-amber-500',
      border: 'border-amber-100',
      text: 'text-amber-900',
    },
    rose: {
      bg: 'bg-rose-50/80',
      iconBg: 'bg-rose-600',
      border: 'border-rose-100',
      text: 'text-rose-900',
    },
    purple: {
      bg: 'bg-purple-50/80',
      iconBg: 'bg-purple-600',
      border: 'border-purple-100',
      text: 'text-purple-900',
    },
    teal: {
      bg: 'bg-teal-50/80',
      iconBg: 'bg-teal-600',
      border: 'border-teal-100',
      text: 'text-teal-900',
    },
  }[colorScheme];

  return (
    <div
      onClick={onClick}
      className={`relative p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-md transition-all ${
        onClick ? 'cursor-pointer hover:border-slate-300' : ''
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">{title}</p>
          <p className="text-2xl font-bold text-slate-900 mt-1 tracking-tight">{value}</p>
          {subtitle && <p className="text-xs text-slate-500 mt-1.5 flex items-center gap-1">{subtitle}</p>}
        </div>
        <div className={`p-3 rounded-xl text-white shadow-xs shrink-0 ${schemeStyles.iconBg}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
};
