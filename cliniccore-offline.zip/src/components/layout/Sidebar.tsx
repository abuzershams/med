import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  UserCheck,
  Calendar,
  Stethoscope,
  FileText,
  Pill,
  ShoppingBag,
  Receipt,
  Wallet,
  Clock,
  BarChart3,
  ScrollText,
  ShieldCheck,
  Settings,
  ChevronLeft,
  ChevronRight,
  Activity,
  HeartPulse,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useClinic } from '../../context/ClinicContext';

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
}) => {
  const { user, checkPermission } = useAuth();
  const { settings } = useClinic();

  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard, permission: 'dashboard' as const },
    { name: 'Patients', path: '/patients', icon: Users, permission: 'patients' as const },
    { name: 'Appointments', path: '/appointments', icon: Calendar, permission: 'appointments' as const },
    { name: 'Doctors', path: '/doctors', icon: Stethoscope, permission: 'doctors' as const },
    { name: 'Prescriptions', path: '/prescriptions', icon: FileText, permission: 'prescriptions' as const },
    { name: 'Medicine Master', path: '/medicines', icon: Pill, permission: 'medicines' as const },
    { name: 'Pharmacy & POS', path: '/pharmacy', icon: ShoppingBag, permission: 'pharmacy' as const },
    { name: 'Billing & Invoices', path: '/invoices', icon: Receipt, permission: 'billing' as const },
    { name: 'Finance & Payroll', path: '/finance', icon: Wallet, permission: 'finance' as const },
    { name: 'Follow-ups', path: '/followups', icon: HeartPulse, permission: 'followups' as const },
    { name: 'Staff Attendance', path: '/attendance', icon: Clock, permission: 'attendance' as const },
    { name: 'Reports', path: '/reports', icon: BarChart3, permission: 'reports' as const },
    { name: 'Activity Logs', path: '/activity-logs', icon: ScrollText, permission: 'activityLogs' as const },
    { name: 'User Management', path: '/users', icon: ShieldCheck, permission: 'users' as const },
    { name: 'Settings', path: '/settings', icon: Settings, permission: 'settings' as const },
  ];

  const visibleItems = navItems.filter((item) => checkPermission(item.permission));

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden"
        />
      )}

      {/* Sidebar Container: Navy blue modern SaaS theme */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 bg-slate-950 text-slate-300 flex flex-col border-r border-slate-800 transition-all duration-300 ${
          collapsed ? 'w-20' : 'w-64'
        } ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
      >
        {/* Brand / Logo Header */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800/80 shrink-0">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shrink-0 shadow-md shadow-blue-500/20">
              <Activity className="w-5 h-5" />
            </div>
            {!collapsed && (
              <div className="min-w-0">
                <h1 className="text-sm font-bold text-white truncate tracking-tight">
                  {settings?.clinicName || 'Clinic MS'}
                </h1>
                <p className="text-[10px] text-blue-400 font-medium uppercase tracking-wider">100% Offline</p>
              </div>
            )}
          </div>

          <button
            onClick={onToggleCollapse}
            className="hidden lg:flex p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 transition-colors"
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {visibleItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={onCloseMobile}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                } ${collapsed ? 'justify-center px-2' : ''}`
              }
              title={collapsed ? item.name : undefined}
            >
              <item.icon className="w-5 h-5 shrink-0 transition-transform group-hover:scale-105" />
              {!collapsed && <span className="truncate">{item.name}</span>}
            </NavLink>
          ))}
        </nav>

        {/* User Mini Profile in Sidebar Footer */}
        <div className="p-3 border-t border-slate-800/80 shrink-0 bg-slate-950/60">
          <div className={`flex items-center gap-3 p-2 rounded-xl bg-slate-900/80 ${collapsed ? 'justify-center' : ''}`}>
            <div className="w-8 h-8 rounded-lg bg-slate-800 text-blue-400 flex items-center justify-center font-bold text-xs shrink-0 border border-slate-700">
              {user?.name?.charAt(0) || 'U'}
            </div>
            {!collapsed && (
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold text-white truncate">{user?.name}</p>
                <p className="text-[10px] text-slate-400 capitalize font-medium">{user?.role}</p>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};
