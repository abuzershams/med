import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Menu,
  Search,
  Plus,
  LogOut,
  User,
  WifiOff,
  UserPlus,
  CalendarPlus,
  FilePlus,
  Receipt,
  Pill,
  ChevronDown,
  Clock,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../db/database';
import { ConfirmDialog } from '../common/ConfirmDialog';
import type { Patient, Appointment, Invoice, Prescription } from '../../types';

interface HeaderProps {
  onToggleMobileMenu: () => void;
  onOpenNewPatient?: () => void;
  onOpenNewAppointment?: () => void;
  onOpenNewInvoice?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleMobileMenu }) => {
  const { user, logout, checkPermission } = useAuth();
  const navigate = useNavigate();

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{
    patients: Patient[];
    appointments: Appointment[];
    invoices: Invoice[];
    prescriptions: Prescription[];
  }>({ patients: [], appointments: [], invoices: [], prescriptions: [] });
  const [showSearchResults, setShowSearchResults] = useState(false);

  const [showQuickMenu, setShowQuickMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const searchRef = useRef<HTMLDivElement>(null);
  const quickMenuRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  // Global search effect
  useEffect(() => {
    if (!searchQuery.trim() || searchQuery.length < 2) {
      setSearchResults({ patients: [], appointments: [], invoices: [], prescriptions: [] });
      setShowSearchResults(false);
      return;
    }

    const timer = setTimeout(async () => {
      const q = searchQuery.trim().toLowerCase();

      // Search Patients
      const allPatients = await db.patients.toArray();
      const patients = allPatients
        .filter(
          (p) =>
            p.name.toLowerCase().includes(q) ||
            p.patientCode.toLowerCase().includes(q) ||
            p.phone.includes(q)
        )
        .slice(0, 5);

      // Search Appointments
      const allAppts = await db.appointments.toArray();
      const appointments = allAppts
        .filter(
          (a) =>
            a.patientName.toLowerCase().includes(q) ||
            a.doctorName.toLowerCase().includes(q) ||
            a.date.includes(q)
        )
        .slice(0, 4);

      // Search Invoices
      const allInvoices = await db.invoices.toArray();
      const invoices = allInvoices
        .filter(
          (i) =>
            i.invoiceNumber.toLowerCase().includes(q) ||
            i.patientName.toLowerCase().includes(q)
        )
        .slice(0, 4);

      // Search Prescriptions
      const allRx = await db.prescriptions.toArray();
      const prescriptions = allRx
        .filter(
          (r) =>
            r.patientName.toLowerCase().includes(q) ||
            r.diagnosis.toLowerCase().includes(q)
        )
        .slice(0, 4);

      setSearchResults({ patients, appointments, invoices, prescriptions });
      setShowSearchResults(true);
    }, 200);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Outside click listeners
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowSearchResults(false);
      }
      if (quickMenuRef.current && !quickMenuRef.current.contains(e.target as Node)) {
        setShowQuickMenu(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setShowUserMenu(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const handleLogout = async () => {
    setShowLogoutConfirm(false);
    await logout();
    navigate('/login');
  };

  const totalResults =
    searchResults.patients.length +
    searchResults.appointments.length +
    searchResults.invoices.length +
    searchResults.prescriptions.length;

  return (
    <>
      <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4 sticky top-0 z-30 shadow-2xs">
        {/* Left: Mobile hamburger & Global Search */}
        <div className="flex items-center gap-3 flex-1 max-w-xl">
          <button
            onClick={onToggleMobileMenu}
            className="p-2 text-slate-500 hover:text-slate-800 lg:hidden rounded-lg hover:bg-slate-100 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Global Search Box */}
          <div ref={searchRef} className="relative flex-1">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search patient name, ID, phone, invoice, appointment..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => searchQuery.length >= 2 && setShowSearchResults(true)}
                className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all placeholder:text-slate-400"
              />
            </div>

            {/* Global Search Results Dropdown */}
            {showSearchResults && (
              <div className="absolute top-full left-0 right-0 mt-1.5 bg-white rounded-2xl shadow-xl border border-slate-200 max-h-96 overflow-y-auto z-50 p-2 divide-y divide-slate-100">
                {totalResults === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-400">
                    No records found for "{searchQuery}"
                  </div>
                ) : (
                  <>
                    {/* Patients */}
                    {searchResults.patients.length > 0 && (
                      <div className="py-2">
                        <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                          Patients ({searchResults.patients.length})
                        </p>
                        {searchResults.patients.map((p) => (
                          <div
                            key={p.id}
                            onClick={() => {
                              navigate(`/patients/${p.id}`);
                              setShowSearchResults(false);
                              setSearchQuery('');
                            }}
                            className="px-3 py-2 hover:bg-blue-50 rounded-xl cursor-pointer flex items-center justify-between text-xs transition-colors"
                          >
                            <div>
                              <p className="font-semibold text-slate-900">{p.name}</p>
                              <p className="text-slate-500 text-[11px]">{p.phone} • {p.gender}</p>
                            </div>
                            <span className="font-mono text-[11px] font-bold text-blue-600 bg-blue-100/60 px-2 py-0.5 rounded">
                              {p.patientCode}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Appointments */}
                    {searchResults.appointments.length > 0 && (
                      <div className="py-2">
                        <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                          Appointments ({searchResults.appointments.length})
                        </p>
                        {searchResults.appointments.map((a) => (
                          <div
                            key={a.id}
                            onClick={() => {
                              navigate('/appointments');
                              setShowSearchResults(false);
                              setSearchQuery('');
                            }}
                            className="px-3 py-2 hover:bg-blue-50 rounded-xl cursor-pointer flex items-center justify-between text-xs transition-colors"
                          >
                            <div>
                              <p className="font-semibold text-slate-900">{a.patientName}</p>
                              <p className="text-slate-500 text-[11px]">{a.date} at {a.time} • {a.doctorName}</p>
                            </div>
                            <span className="text-[11px] font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                              {a.status}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Invoices */}
                    {searchResults.invoices.length > 0 && (
                      <div className="py-2">
                        <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                          Invoices ({searchResults.invoices.length})
                        </p>
                        {searchResults.invoices.map((inv) => (
                          <div
                            key={inv.id}
                            onClick={() => {
                              navigate('/invoices');
                              setShowSearchResults(false);
                              setSearchQuery('');
                            }}
                            className="px-3 py-2 hover:bg-blue-50 rounded-xl cursor-pointer flex items-center justify-between text-xs transition-colors"
                          >
                            <div>
                              <p className="font-semibold text-slate-900">{inv.patientName}</p>
                              <p className="text-slate-500 text-[11px]">{inv.date} • ₹{inv.grandTotal.toFixed(2)}</p>
                            </div>
                            <span className="font-mono text-[11px] font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                              {inv.invoiceNumber}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Prescriptions */}
                    {searchResults.prescriptions.length > 0 && (
                      <div className="py-2">
                        <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                          Prescriptions ({searchResults.prescriptions.length})
                        </p>
                        {searchResults.prescriptions.map((rx) => (
                          <div
                            key={rx.id}
                            onClick={() => {
                              navigate('/prescriptions');
                              setShowSearchResults(false);
                              setSearchQuery('');
                            }}
                            className="px-3 py-2 hover:bg-blue-50 rounded-xl cursor-pointer flex items-center justify-between text-xs transition-colors"
                          >
                            <div>
                              <p className="font-semibold text-slate-900">{rx.patientName}</p>
                              <p className="text-slate-500 text-[11px]">{rx.diagnosis} • {rx.date}</p>
                            </div>
                            <span className="text-[11px] font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                              View Rx
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Header Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* 100% Offline Badge */}
          <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            100% Offline Mode
          </div>

          {/* Quick Actions Dropdown */}
          <div ref={quickMenuRef} className="relative">
            <button
              onClick={() => setShowQuickMenu(!showQuickMenu)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Quick Action</span>
              <ChevronDown className="w-3.5 h-3.5 opacity-80" />
            </button>

            {showQuickMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-slate-200 p-1.5 z-50 text-xs animate-in fade-in zoom-in-95 duration-100">
                {checkPermission('patients') && (
                  <button
                    onClick={() => {
                      setShowQuickMenu(false);
                      navigate('/patients');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-slate-700 hover:bg-slate-50 rounded-xl transition-colors text-left"
                  >
                    <UserPlus className="w-4 h-4 text-blue-600" />
                    New Patient
                  </button>
                )}

                {checkPermission('appointments') && (
                  <button
                    onClick={() => {
                      setShowQuickMenu(false);
                      navigate('/appointments');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-slate-700 hover:bg-slate-50 rounded-xl transition-colors text-left"
                  >
                    <CalendarPlus className="w-4 h-4 text-emerald-600" />
                    New Appointment
                  </button>
                )}

                {checkPermission('prescriptions') && (
                  <button
                    onClick={() => {
                      setShowQuickMenu(false);
                      navigate('/prescriptions/new');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-slate-700 hover:bg-slate-50 rounded-xl transition-colors text-left"
                  >
                    <FilePlus className="w-4 h-4 text-purple-600" />
                    New Prescription
                  </button>
                )}

                {checkPermission('billing') && (
                  <button
                    onClick={() => {
                      setShowQuickMenu(false);
                      navigate('/invoices');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-slate-700 hover:bg-slate-50 rounded-xl transition-colors text-left"
                  >
                    <Receipt className="w-4 h-4 text-amber-600" />
                    Create Invoice
                  </button>
                )}

                {checkPermission('medicines') && (
                  <button
                    onClick={() => {
                      setShowQuickMenu(false);
                      navigate('/medicines');
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-slate-700 hover:bg-slate-50 rounded-xl transition-colors text-left"
                  >
                    <Pill className="w-4 h-4 text-rose-600" />
                    Add Medicine
                  </button>
                )}
              </div>
            )}
          </div>

          {/* User Profile & Logout */}
          <div ref={userMenuRef} className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 transition-colors"
            >
              <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs border border-blue-200">
                {user?.name?.charAt(0) || 'U'}
              </div>
              <div className="hidden lg:block text-left">
                <p className="text-xs font-semibold text-slate-800 leading-tight">{user?.name}</p>
                <p className="text-[10px] text-slate-500 capitalize">{user?.role}</p>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden lg:block" />
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-52 bg-white rounded-2xl shadow-xl border border-slate-200 p-1.5 z-50 text-xs animate-in fade-in zoom-in-95 duration-100">
                <div className="px-3 py-2.5 border-b border-slate-100 mb-1">
                  <p className="font-semibold text-slate-900">{user?.name}</p>
                  <p className="text-[11px] text-slate-500">{user?.username} ({user?.role})</p>
                </div>

                <Link
                  to="/account"
                  onClick={() => setShowUserMenu(false)}
                  className="flex items-center gap-2 px-3 py-2 text-slate-700 hover:bg-slate-50 rounded-xl transition-colors"
                >
                  <User className="w-4 h-4 text-slate-500" />
                  My Account Profile
                </Link>

                <button
                  type="button"
                  onClick={() => {
                    setShowUserMenu(false);
                    setShowLogoutConfirm(true);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-colors text-left font-medium"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Logout ConfirmDialog */}
      <ConfirmDialog
        isOpen={showLogoutConfirm}
        title="Sign Out of Clinic"
        message="Are you sure you want to log out of your clinic management session?"
        confirmLabel="Logout Now"
        cancelLabel="Stay Logged In"
        variant="warning"
        iconType="logout"
        onConfirm={handleLogout}
        onCancel={() => setShowLogoutConfirm(false)}
      />
    </>
  );
};
