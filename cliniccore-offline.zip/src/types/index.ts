// Application TypeScript Definitions

export type UserRole = 'admin' | 'doctor' | 'receptionist' | 'pharmacist' | 'staff';

export interface User {
  id?: number;
  name: string;
  username: string;
  passwordHash: string;
  role: UserRole;
  phone?: string;
  email?: string;
  active?: boolean;
  status?: 'active' | 'inactive';
  createdAt?: string;
  updatedAt?: string;
}

export interface SecurityCredentials {
  id?: number;
  userId: number;
  recoveryKeyHash: string;
  securityQuestion: string;
  securityAnswerHash: string;
}

export interface ClinicSettings {
  id?: number;
  clinicName: string;
  tagline?: string;
  doctorName?: string;
  degree?: string;
  specialization?: string;
  registrationNumber?: string;
  phone: string;
  whatsapp?: string;
  email?: string;
  address: string;
  city: string;
  workingHours: string;
  currencySymbol: string;
  defaultConsultationFee?: number;
  consultationFee?: number;
  taxEnabled?: boolean;
  taxPercent: number;
  paperSize?: 'A4' | '80mm';
  idleTimeoutMinutes: number;
  lowStockThreshold: number;
  expiryAlertDays?: number;
  invoicePrefix?: string;
  invoiceFooterText?: string;
  invoiceFooter?: string;
  prescriptionFooterText?: string;
  logoBase64?: string;
  lastBackupDate?: string;
}

export interface Patient {
  id?: number;
  patientCode: string; // PT-0001
  name: string;
  gender: 'Male' | 'Female' | 'Other';
  dob?: string;
  age?: number;
  phone: string;
  altPhone?: string;
  email?: string;
  bloodGroup?: string;
  allergies?: string;
  address?: string;
  city?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  notes?: string;
  photoBase64?: string;
  registrationDate?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Doctor {
  id?: number;
  name: string;
  degree: string;
  specialization: string;
  registrationNumber: string;
  phone: string;
  email?: string;
  room?: string;
  consultationFee: number;
  status: 'active' | 'inactive';
  createdAt: string;
}

export type AppointmentStatus = 'Scheduled' | 'Waiting' | 'In Consultation' | 'Completed' | 'Cancelled' | 'No-show';

export interface Appointment {
  id?: number;
  patientId: number;
  patientName: string;
  patientCode: string;
  patientPhone: string;
  doctorId: number;
  doctorName: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  tokenNumber: number;
  reason?: string;
  status: AppointmentStatus;
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface Vitals {
  id?: number;
  patientId: number;
  appointmentId?: number;
  recordedBy: string; // Staff/Doctor name
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  weightKg?: number;
  heightCm?: number;
  bmi?: number;
  bloodPressureSystolic?: number;
  bloodPressureDiastolic?: number;
  pulseBpm?: number;
  temperatureF?: number;
  spo2Percent?: number;
  bloodSugarMgDl?: number;
  respiratoryRate?: number;
  notes?: string;
  createdAt: string;
}

export interface Consultation {
  id?: number;
  patientId: number;
  patientName: string;
  patientCode: string;
  doctorId: number;
  doctorName: string;
  appointmentId?: number;
  date: string; // YYYY-MM-DD
  chiefComplaint: string;
  symptoms?: string;
  medicalHistory?: string;
  examination?: string;
  diagnosis: string;
  treatmentPlan?: string;
  advice?: string;
  followUpDate?: string;
  billed: boolean;
  createdAt: string;
}

export interface PrescriptionMedicine {
  id?: string;
  medicineId?: number;
  name?: string;
  medicineName?: string;
  genericName?: string;
  strength?: string;
  form?: string; // Tablet, Syrup, etc.
  dose?: string; // e.g. 1 tab, 5 ml
  dosage?: string;
  frequency?: string; // e.g. 1-0-1, OD, BD, TDS
  duration?: string; // e.g. 5 days, 1 month
  timing?: string; // After Food, Before Food, With Food
  instructions?: string;
}

export interface Prescription {
  id?: number;
  patientId: number;
  patientName: string;
  patientCode: string;
  doctorId: number;
  doctorName: string;
  consultationId?: number;
  date: string; // YYYY-MM-DD
  diagnosis: string;
  symptoms?: string;
  vitalsSummary?: string;
  medicines: PrescriptionMedicine[];
  advice?: string;
  instructions?: string;
  testsAdvised?: string;
  followUpDate?: string;
  templateName?: string;
  createdAt?: string;
}

export interface PrescriptionTemplate {
  id?: number;
  title?: string;
  name?: string;
  doctorId?: number;
  diagnosis?: string;
  medicines: PrescriptionMedicine[];
  advice?: string;
  instructions?: string;
  testsAdvised?: string;
  createdAt?: string;
}

export interface Medicine {
  id?: number;
  name: string;
  genericName?: string;
  strength?: string;
  form?: string; // Tablet, Capsule, Syrup, Injection, Drops, Cream, Ointment, Other
  dosageForm?: string;
  category?: string;
  stockQuantity?: number;
  unitPrice?: number;
  sellingPrice?: number;
  purchasePrice?: number;
  costPrice?: number;
  minStockAlert?: number;
  defaultDose?: string;
  defaultFrequency?: string;
  defaultDuration?: string;
  defaultTiming?: string;
  isFavorite?: boolean;
  status?: 'active' | 'inactive';
  createdAt?: string;
}

export interface MedicineBatch {
  id?: number;
  medicineId: number;
  medicineName?: string;
  batchNumber: string;
  expiryDate: string; // YYYY-MM-DD
  purchasePrice?: number;
  sellingPrice?: number;
  quantity: number;
  currentStock?: number;
  unit?: string; // Tab, Bottle, Strip, Box
  createdAt?: string;
  updatedAt?: string;
}

export type StockMovementType = 'IN' | 'OUT' | 'ADJUSTMENT' | 'SALE' | 'REFUND' | 'purchase' | 'sale';

export interface StockMovement {
  id?: number;
  medicineId: number;
  medicineName: string;
  batchId?: number;
  batchNumber?: string;
  type: StockMovementType;
  quantity: number;
  previousStock?: number;
  newStock?: number;
  reference?: string;
  notes?: string;
  reason?: string;
  performedBy?: string;
  date: string;
  createdAt?: string;
}

export interface Supplier {
  id?: number;
  name: string;
  companyName: string;
  phone: string;
  email?: string;
  address?: string;
  gstNumber?: string;
  notes?: string;
  createdAt: string;
}

export interface PurchaseItem {
  medicineId: number;
  medicineName: string;
  batchNumber: string;
  expiryDate: string;
  quantity: number;
  unitPrice: number;
  total: number;
  sellingPrice: number;
}

export interface Purchase {
  id?: number;
  supplierId: number;
  supplierName: string;
  purchaseInvoiceNumber: string;
  date: string;
  totalAmount: number;
  items: PurchaseItem[];
  notes?: string;
  createdAt: string;
}

export interface PharmacySaleItem {
  medicineId: number;
  medicineName: string;
  batchNumber: string;
  expiryDate: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface SaleItem {
  medicineId: number;
  medicineName: string;
  batchId?: number;
  batchNumber: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface PharmacySale {
  id?: number;
  receiptNumber: string; // REC-2026-0001
  patientId?: number;
  patientName?: string;
  customerName: string;
  customerPhone?: string;
  date: string;
  time?: string;
  items: (PharmacySaleItem | SaleItem)[];
  subtotal: number;
  discount: number;
  tax: number;
  grandTotal: number;
  paymentMethod: 'Cash' | 'UPI' | 'Card' | 'Other';
  refunded?: boolean;
  refundDate?: string;
  refundReason?: string;
  soldBy?: string;
  createdAt?: string;
}

export interface InvoiceItem {
  id?: string;
  description: string;
  quantity: number;
  unitPrice: number;
  amount: number;
  referenceType?: 'consultation' | 'prescription' | 'procedure' | 'lab' | 'other';
  referenceId?: number;
}

export type InvoiceStatus = 'Paid' | 'Partial' | 'Pending' | 'paid' | 'partial' | 'pending' | 'cancelled' | 'Cancelled';

export interface Invoice {
  id?: number;
  invoiceNumber: string; // INV-2026-0001
  patientId: number;
  patientName: string;
  patientCode: string;
  patientPhone?: string;
  doctorId?: number;
  doctorName?: string;
  date: string; // YYYY-MM-DD
  items: InvoiceItem[];
  subtotal: number;
  discountAmount?: number;
  discount?: number;
  taxPercent: number;
  taxAmount?: number;
  tax?: number;
  grandTotal: number;
  amountPaid?: number;
  paidAmount?: number;
  balanceDue?: number;
  dueAmount?: number;
  status: InvoiceStatus;
  paymentMethod?: string;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
}

export type PaymentMethod = 'Cash' | 'UPI' | 'Card' | 'Bank' | 'Bank Transfer' | 'Other';

export interface Payment {
  id?: number;
  invoiceId?: number;
  invoiceNumber?: string;
  patientId: number;
  patientName: string;
  amount: number;
  method: PaymentMethod;
  date: string; // YYYY-MM-DD
  time?: string; // HH:MM
  receivedBy?: string;
  note?: string;
  notes?: string;
  createdAt?: string;
}

export interface Expense {
  id?: number;
  title?: string;
  category: string; // Rent, Utilities, Supplies, Maintenance, Salaries, Marketing, Other
  amount: number;
  date: string; // YYYY-MM-DD
  paidTo?: string;
  paymentMethod?: PaymentMethod | string;
  description?: string;
  notes?: string;
  recordedBy?: string;
  createdAt?: string;
}

export interface Payslip {
  id?: number;
  staffName?: string;
  employeeName?: string;
  role: string;
  monthYear?: string; // YYYY-MM
  month?: string;
  baseSalary?: number;
  basicSalary?: number;
  allowances?: number;
  bonus?: number;
  deductions?: number;
  netSalary?: number;
  status: 'Pending' | 'Paid' | 'pending' | 'paid';
  paymentDate?: string;
  paymentMethod?: PaymentMethod | string;
  notes?: string;
  createdAt?: string;
}

export type AttendanceStatus = 'Present' | 'On Break' | 'Absent' | 'Late' | 'present' | 'absent' | 'half_day' | 'leave';

export interface Attendance {
  id?: number;
  employeeId?: number;
  employeeName?: string;
  employeeType?: 'doctor' | 'staff';
  staffName?: string;
  role?: string;
  date: string; // YYYY-MM-DD
  inTime?: string;
  outTime?: string;
  clockInTime?: string;
  clockOutTime?: string;
  breakMinutes?: number;
  status: AttendanceStatus;
  note?: string;
  notes?: string;
  createdAt?: string;
}

export interface MedicalDocument {
  id?: number;
  patientId: number;
  documentName: string;
  documentType: 'Lab Report' | 'X-Ray' | 'Prescription Scan' | 'Discharge Summary' | 'ID Proof' | 'Other';
  fileDataBlob: Blob;
  mimeType: string;
  fileSizeBytes: number;
  date: string;
  notes?: string;
  uploadedBy: string;
  createdAt: string;
}

export interface FollowUp {
  id?: number;
  patientId: number;
  patientName: string;
  patientCode?: string;
  patientPhone?: string;
  doctorId?: number;
  doctorName?: string;
  consultationId?: number;
  followUpDate?: string; // YYYY-MM-DD
  scheduledDate?: string;
  reason: string;
  notes?: string;
  isDone?: boolean;
  status?: 'pending' | 'completed' | string;
  doneDate?: string;
  createdAt?: string;
}

export interface ActivityLog {
  id?: number;
  userName: string;
  userRole: string;
  action: string; // e.g. "Create Patient", "Delete Invoice"
  module: string; // Patients, Billing, Pharmacy, Auth, Settings, etc.
  details: string;
  timestamp: string;
}

export interface Counter {
  id?: number;
  key: string; // 'patient', 'invoice_2026', 'sale_2026'
  value: number;
}
