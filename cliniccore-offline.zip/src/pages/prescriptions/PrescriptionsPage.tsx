import React, { useState, useEffect } from 'react';
import {
  FileText,
  Plus,
  Search,
  Printer,
  Edit,
  Trash2,
  Calendar,
  User,
  Stethoscope,
  Pill,
} from 'lucide-react';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { Pagination } from '../../components/common/Pagination';
import { EmptyState, LoadingSpinner } from '../../components/common/EmptyState';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { PrescriptionModal } from './PrescriptionModal';
import { PrintPreviewModal } from '../../print/PrintPreviewModal';
import { PrescriptionPrint } from '../../print/PrescriptionPrint';
import { generatePrescriptionPDF } from '../../print/pdfGenerator';
import { logActivity } from '../../services/auditService';
import type { Prescription } from '../../types';

export const PrescriptionsPage: React.FC = () => {
  const { settings, formatDate } = useClinic();
  const { user } = useAuth();
  const { success, error } = useToast();

  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPrescription, setEditingPrescription] = useState<Prescription | null>(null);

  // Print
  const [isPrintOpen, setIsPrintOpen] = useState(false);
  const [printingPrescription, setPrintingPrescription] = useState<Prescription | null>(null);

  // Delete
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [prescriptionToDelete, setPrescriptionToDelete] = useState<Prescription | null>(null);

  const loadPrescriptions = async () => {
    setLoading(true);
    try {
      const list = await db.prescriptions.reverse().sortBy('date');
      setPrescriptions(list);
    } catch (err) {
      console.error(err);
      error('Failed to load prescriptions');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPrescriptions();
  }, []);

  const filteredPrescriptions = prescriptions.filter((p) => {
    const q = search.toLowerCase();
    return (
      p.patientName.toLowerCase().includes(q) ||
      (p.patientCode && p.patientCode.toLowerCase().includes(q)) ||
      (p.doctorName && p.doctorName.toLowerCase().includes(q)) ||
      p.diagnosis.toLowerCase().includes(q) ||
      p.medicines.some((m) => m.medicineName.toLowerCase().includes(q))
    );
  });

  const totalItems = filteredPrescriptions.length;
  const startIndex = (currentPage - 1) * pageSize;
  const paginated = filteredPrescriptions.slice(startIndex, startIndex + pageSize);

  const handleDelete = async () => {
    if (!prescriptionToDelete || !prescriptionToDelete.id) return;
    try {
      await db.prescriptions.delete(prescriptionToDelete.id);
      await logActivity(
        user?.name || 'User',
        user?.role || 'doctor',
        'DELETE_PRESCRIPTION',
        'prescriptions',
        `Deleted prescription #${prescriptionToDelete.id} for ${prescriptionToDelete.patientName}`
      );
      success('Prescription deleted');
      loadPrescriptions();
    } catch (err) {
      console.error(err);
      error('Failed to delete prescription');
    } finally {
      setIsDeleteOpen(false);
      setPrescriptionToDelete(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Prescriptions</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Manage patient medical prescriptions, dosages, and printable Rx slips
          </p>
        </div>
        <button
          onClick={() => {
            setEditingPrescription(null);
            setIsModalOpen(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm shadow-sm shadow-blue-500/20 transition-all self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          New Prescription
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by patient, doctor, diagnosis, medicine..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-9 pr-4 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {loading ? (
          <div className="p-12 flex justify-center">
            <LoadingSpinner size="lg" message="Loading prescriptions..." />
          </div>
        ) : filteredPrescriptions.length === 0 ? (
          <EmptyState
            icon={FileText}
            title="No prescriptions found"
            description={
              search
                ? 'Try a different search query.'
                : 'No prescriptions created yet. Click "New Prescription" to write one.'
            }
            actionLabel={!search ? 'New Prescription' : undefined}
            onAction={
              !search
                ? () => {
                    setEditingPrescription(null);
                    setIsModalOpen(true);
                  }
                : undefined
            }
          />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-semibold text-slate-500 tracking-wider">
                  <tr>
                    <th className="px-5 py-3.5">Rx #</th>
                    <th className="px-4 py-3.5">Date</th>
                    <th className="px-4 py-3.5">Patient</th>
                    <th className="px-4 py-3.5">Doctor</th>
                    <th className="px-4 py-3.5">Diagnosis</th>
                    <th className="px-4 py-3.5">Prescribed Medicines</th>
                    <th className="px-4 py-3.5">Follow-up</th>
                    <th className="px-5 py-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {paginated.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-3.5 font-semibold text-blue-600">
                        #{p.id}
                      </td>
                      <td className="px-4 py-3.5 text-slate-500">
                        {formatDate(p.date)}
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-medium text-slate-900">{p.patientName}</div>
                        <div className="text-xs text-slate-400">{p.patientCode}</div>
                      </td>
                      <td className="px-4 py-3.5 text-slate-700">
                        {p.doctorName ? `Dr. ${p.doctorName}` : '—'}
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="font-medium text-slate-900">{p.diagnosis}</span>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="flex flex-wrap gap-1 max-w-xs">
                          {p.medicines.slice(0, 3).map((m, idx) => (
                            <span
                              key={idx}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 text-[11px] text-slate-700 font-medium"
                            >
                              <Pill className="w-3 h-3 text-blue-500" />
                              {m.medicineName}
                            </span>
                          ))}
                          {p.medicines.length > 3 && (
                            <span className="text-[11px] text-slate-400 self-center">
                              +{p.medicines.length - 3} more
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-slate-600 text-xs">
                        {p.followUpDate ? formatDate(p.followUpDate) : '—'}
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setPrintingPrescription(p);
                              setIsPrintOpen(true);
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                            title="Print Prescription Slip"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              setEditingPrescription(p);
                              setIsModalOpen(true);
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                            title="Edit Prescription"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              setPrescriptionToDelete(p);
                              setIsDeleteOpen(true);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            title="Delete Prescription"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-4 border-t border-slate-200">
              <Pagination
                currentPage={currentPage}
                totalItems={totalItems}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1);
                }}
              />
            </div>
          </>
        )}
      </div>

      {/* Prescription Editor Modal */}
      {isModalOpen && (
        <PrescriptionModal
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
            setEditingPrescription(null);
          }}
          prescriptionToEdit={editingPrescription}
          onSaved={() => {
            loadPrescriptions();
          }}
        />
      )}

      {/* Print Preview Modal */}
      {isPrintOpen && printingPrescription && (
        <PrintPreviewModal
          isOpen={isPrintOpen}
          onClose={() => {
            setIsPrintOpen(false);
            setPrintingPrescription(null);
          }}
          title={`Prescription #${printingPrescription.id}`}
          onGeneratePdf={() => generatePrescriptionPDF(printingPrescription, settings)}
        >
          <PrescriptionPrint prescription={printingPrescription} settings={settings} />
        </PrintPreviewModal>
      )}

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={isDeleteOpen}
        title="Delete Prescription"
        message={`Are you sure you want to delete prescription #${prescriptionToDelete?.id} for ${prescriptionToDelete?.patientName}?`}
        confirmLabel="Delete"
        variant="danger"
        onConfirm={handleDelete}
        onCancel={() => {
          setIsDeleteOpen(false);
          setPrescriptionToDelete(null);
        }}
      />
    </div>
  );
};
