import React, { useState, useEffect } from 'react';
import { Plus, Trash2, BookmarkPlus, FileText, Search } from 'lucide-react';
import { Modal } from '../../components/common/Modal';
import { DatePicker } from '../../components/common/DatePicker';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { logActivity } from '../../services/auditService';
import type {
  Prescription,
  PrescriptionMedicine,
  Patient,
  Doctor,
  Medicine,
  PrescriptionTemplate,
} from '../../types';

interface PrescriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedPatient?: Patient | null;
  prescriptionToEdit?: Prescription | null;
  onSaved: (prescription: Prescription) => void;
}

export const PrescriptionModal: React.FC<PrescriptionModalProps> = ({
  isOpen,
  onClose,
  preselectedPatient,
  prescriptionToEdit,
  onSaved,
}) => {
  const { user } = useAuth();
  const { success, error } = useToast();

  const [patients, setPatients] = useState<Patient[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [templates, setTemplates] = useState<PrescriptionTemplate[]>([]);

  const [selectedPatientId, setSelectedPatientId] = useState<number | ''>('');
  const [selectedDoctorId, setSelectedDoctorId] = useState<number | ''>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [diagnosis, setDiagnosis] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [instructions, setInstructions] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');
  const [prescribedMedicines, setPrescribedMedicines] = useState<PrescriptionMedicine[]>([]);

  // Template saving modal or prompt
  const [templateName, setTemplateName] = useState('');
  const [showSaveTemplate, setShowSaveTemplate] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadData() {
      const allP = await db.patients.toArray();
      setPatients(allP);
      const allD = await db.doctors.where('status').equals('active').toArray();
      setDoctors(allD);
      const allM = await db.medicines.toArray();
      setMedicines(allM);
      const allT = await db.prescription_templates.toArray();
      setTemplates(allT);

      if (prescriptionToEdit) {
        setSelectedPatientId(prescriptionToEdit.patientId);
        setSelectedDoctorId(prescriptionToEdit.doctorId);
        setDate(prescriptionToEdit.date);
        setDiagnosis(prescriptionToEdit.diagnosis);
        setSymptoms(prescriptionToEdit.symptoms || '');
        setInstructions(prescriptionToEdit.instructions || '');
        setFollowUpDate(prescriptionToEdit.followUpDate || '');
        setPrescribedMedicines(prescriptionToEdit.medicines || []);
      } else if (preselectedPatient?.id) {
        setSelectedPatientId(preselectedPatient.id);
        if (allD.length > 0) setSelectedDoctorId(allD[0].id!);
        handleAddMedicineRow();
      } else {
        if (allD.length > 0) setSelectedDoctorId(allD[0].id!);
        handleAddMedicineRow();
      }
    }
    loadData();
  }, [prescriptionToEdit, preselectedPatient]);

  const handleAddMedicineRow = () => {
    const newMed: PrescriptionMedicine = {
      medicineName: '',
      dosage: '1 Tab',
      frequency: '1-0-1',
      duration: '5 days',
      timing: 'After Food',
      instructions: '',
    };
    setPrescribedMedicines((prev) => [...prev, newMed]);
  };

  const handleUpdateMedicine = (
    index: number,
    field: keyof PrescriptionMedicine,
    value: string
  ) => {
    setPrescribedMedicines((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const handleMedicineSelect = (index: number, medName: string) => {
    const med = medicines.find((m) => m.name === medName);
    setPrescribedMedicines((prev) => {
      const updated = [...prev];
      updated[index] = {
        ...updated[index],
        medicineId: med?.id,
        medicineName: medName,
        dosage: med?.dosageForm ? `1 ${med.dosageForm}` : updated[index].dosage,
      };
      return updated;
    });
  };

  const handleRemoveMedicine = (index: number) => {
    setPrescribedMedicines((prev) => prev.filter((_, i) => i !== index));
  };

  const handleApplyTemplate = (templateId: number) => {
    const t = templates.find((tmp) => tmp.id === templateId);
    if (!t) return;
    setDiagnosis(t.diagnosis || diagnosis);
    setInstructions(t.instructions || instructions);
    setPrescribedMedicines(t.medicines || []);
    success(`Applied template: ${t.name}`);
  };

  const handleSaveAsTemplate = async () => {
    if (!templateName.trim()) {
      error('Please enter a template name');
      return;
    }
    try {
      const newTemplate: PrescriptionTemplate = {
        name: templateName.trim(),
        doctorId: typeof selectedDoctorId === 'number' ? selectedDoctorId : undefined,
        diagnosis,
        medicines: prescribedMedicines,
        instructions,
      };
      const id = await db.prescription_templates.add(newTemplate);
      newTemplate.id = Number(id);
      setTemplates((prev) => [...prev, newTemplate]);
      success('Template saved successfully');
      setShowSaveTemplate(false);
      setTemplateName('');
    } catch (err) {
      console.error(err);
      error('Failed to save template');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatientId) {
      error('Please select a patient');
      return;
    }
    if (!selectedDoctorId) {
      error('Please select a doctor');
      return;
    }
    if (!diagnosis.trim()) {
      error('Please enter diagnosis');
      return;
    }

    const patient = patients.find((p) => p.id === selectedPatientId);
    const doctor = doctors.find((d) => d.id === selectedDoctorId);

    const validMeds = prescribedMedicines.filter((m) => m.medicineName.trim().length > 0);
    if (validMeds.length === 0) {
      error('Please prescribe at least one medicine');
      return;
    }

    setLoading(true);
    try {
      const prescriptionData: Prescription = {
        patientId: Number(selectedPatientId),
        patientName: patient?.name || '',
        patientCode: patient?.patientCode || '',
        doctorId: Number(selectedDoctorId),
        doctorName: doctor?.name || '',
        date,
        diagnosis: diagnosis.trim(),
        symptoms: symptoms.trim(),
        medicines: validMeds,
        instructions: instructions.trim(),
        followUpDate: followUpDate || undefined,
      };

      if (prescriptionToEdit?.id) {
        prescriptionData.id = prescriptionToEdit.id;
        const { id: _, ...dataToUpdate } = prescriptionData;
        await db.prescriptions.update(prescriptionToEdit.id, dataToUpdate as any);
        await logActivity(
          user?.name || 'User',
          user?.role || 'doctor',
          'UPDATE_PRESCRIPTION',
          'prescriptions',
          `Updated prescription #${prescriptionToEdit.id} for ${patient?.name}`
        );
        success('Prescription updated successfully');
      } else {
        const id = await db.prescriptions.add(prescriptionData);
        prescriptionData.id = Number(id);

        // Also create a follow-up record if followUpDate was specified
        if (followUpDate) {
          await db.follow_ups.add({
            patientId: Number(selectedPatientId),
            patientName: patient?.name || '',
            patientPhone: patient?.phone || '',
            doctorId: Number(selectedDoctorId),
            doctorName: doctor?.name || '',
            scheduledDate: followUpDate,
            reason: `Follow-up for ${diagnosis.trim()}`,
            status: 'pending',
          });
        }

        await logActivity(
          user?.name || 'User',
          user?.role || 'doctor',
          'CREATE_PRESCRIPTION',
          'prescriptions',
          `Created prescription for ${patient?.name} (${diagnosis})`
        );
        success('Prescription created successfully');
      }

      onSaved(prescriptionData);
      onClose();
    } catch (err) {
      console.error(err);
      error('Failed to save prescription');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={prescriptionToEdit ? 'Edit Prescription' : 'New Medical Prescription'}
      subtitle="Record clinical diagnosis, prescribed medicines, and advice"
      maxWidth="xl"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Header selections & Template loader */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 bg-blue-50/70 border border-blue-100 rounded-xl">
          <div className="flex items-center gap-2 text-sm text-blue-900 font-medium">
            <FileText className="w-4 h-4 text-blue-600" />
            <span>Prescription Presets:</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select
              onChange={(e) => {
                if (e.target.value) handleApplyTemplate(Number(e.target.value));
              }}
              defaultValue=""
              className="text-xs px-2.5 py-1.5 rounded-lg border border-blue-200 bg-white text-slate-700 focus:outline-none focus:border-blue-500 w-full sm:w-auto"
            >
              <option value="">Load from saved template...</option>
              {templates.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={() => setShowSaveTemplate(true)}
              className="inline-flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-lg bg-white border border-blue-200 text-blue-700 hover:bg-blue-100/50 font-medium shrink-0 cursor-pointer"
            >
              <BookmarkPlus className="w-3.5 h-3.5" />
              Save As Template
            </button>
          </div>
        </div>

        {/* Save Template Modal Box */}
        {showSaveTemplate && (
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center gap-3">
            <input
              type="text"
              placeholder="Template Name (e.g., Acute Viral Pharyngitis)"
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              className="flex-1 text-xs px-3 py-1.5 rounded-lg border border-amber-300 bg-white focus:outline-none"
            />
            <button
              type="button"
              onClick={handleSaveAsTemplate}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-medium cursor-pointer"
            >
              Save Template
            </button>
            <button
              type="button"
              onClick={() => setShowSaveTemplate(false)}
              className="text-xs text-slate-500 hover:text-slate-700 cursor-pointer"
            >
              Cancel
            </button>
          </div>
        )}

        {/* Primary Meta Fields */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Patient *
            </label>
            <select
              value={selectedPatientId}
              onChange={(e) => setSelectedPatientId(Number(e.target.value))}
              disabled={!!preselectedPatient}
              required
              className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:border-blue-500"
            >
              <option value="">Select Patient...</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.patientCode}) - {p.phone}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Doctor *
            </label>
            <select
              value={selectedDoctorId}
              onChange={(e) => setSelectedDoctorId(Number(e.target.value))}
              required
              className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:border-blue-500"
            >
              <option value="">Select Doctor...</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  Dr. {d.name} ({d.specialization})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Date *
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
              className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Clinical Diagnosis & Symptoms */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Diagnosis / Clinical Impression *
            </label>
            <input
              type="text"
              placeholder="e.g., Essential Hypertension, Acute Bronchitis"
              value={diagnosis}
              onChange={(e) => setDiagnosis(e.target.value)}
              required
              className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Chief Complaints / Symptoms
            </label>
            <input
              type="text"
              placeholder="e.g., Headache for 3 days, low grade fever"
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Rx Medicines Table */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <span className="font-serif italic text-blue-600 text-lg">Rx</span> Prescribed
              Medicines
            </h4>
            <button
              type="button"
              onClick={handleAddMedicineRow}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-medium cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Medicine
            </button>
          </div>

          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-600 uppercase">
                <tr>
                  <th className="p-2.5">Medicine Name</th>
                  <th className="p-2.5 w-28">Dosage</th>
                  <th className="p-2.5 w-28">Frequency</th>
                  <th className="p-2.5 w-28">Duration</th>
                  <th className="p-2.5 w-32">Timing</th>
                  <th className="p-2.5">Instructions</th>
                  <th className="p-2.5 w-10 text-center"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {prescribedMedicines.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50">
                    <td className="p-2">
                      <input
                        list="medicines-list"
                        type="text"
                        placeholder="Search or type medicine..."
                        value={item.medicineName}
                        onChange={(e) => handleMedicineSelect(idx, e.target.value)}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 font-medium"
                      />
                    </td>
                    <td className="p-2">
                      <input
                        type="text"
                        placeholder="1 Tab / 5 ml"
                        value={item.dosage}
                        onChange={(e) => handleUpdateMedicine(idx, 'dosage', e.target.value)}
                        className="w-full px-2 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500"
                      />
                    </td>
                    <td className="p-2">
                      <select
                        value={item.frequency}
                        onChange={(e) => handleUpdateMedicine(idx, 'frequency', e.target.value)}
                        className="w-full px-2 py-1.5 rounded-lg border border-slate-200 bg-white focus:outline-none focus:border-blue-500"
                      >
                        <option value="1-0-1">1-0-1 (BD)</option>
                        <option value="1-1-1">1-1-1 (TDS)</option>
                        <option value="1-0-0">1-0-0 (OD Morn)</option>
                        <option value="0-0-1">0-0-1 (OD Night)</option>
                        <option value="1-1-1-1">1-1-1-1 (QID)</option>
                        <option value="SOS">SOS (When needed)</option>
                        <option value="Stat">Stat (Immediately)</option>
                      </select>
                    </td>
                    <td className="p-2">
                      <input
                        type="text"
                        placeholder="5 days"
                        value={item.duration}
                        onChange={(e) => handleUpdateMedicine(idx, 'duration', e.target.value)}
                        className="w-full px-2 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500"
                      />
                    </td>
                    <td className="p-2">
                      <select
                        value={item.timing}
                        onChange={(e) => handleUpdateMedicine(idx, 'timing', e.target.value)}
                        className="w-full px-2 py-1.5 rounded-lg border border-slate-200 bg-white focus:outline-none focus:border-blue-500"
                      >
                        <option value="After Food">After Food</option>
                        <option value="Before Food">Before Food</option>
                        <option value="With Food">With Food</option>
                        <option value="Empty Stomach">Empty Stomach</option>
                      </select>
                    </td>
                    <td className="p-2">
                      <input
                        type="text"
                        placeholder="Specific notes..."
                        value={item.instructions || ''}
                        onChange={(e) => handleUpdateMedicine(idx, 'instructions', e.target.value)}
                        className="w-full px-2 py-1.5 rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500"
                      />
                    </td>
                    <td className="p-2 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveMedicine(idx)}
                        className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                        title="Remove"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <datalist id="medicines-list">
            {medicines.map((m) => (
              <option key={m.id} value={m.name}>
                {m.strength ? `${m.strength} - ` : ''} {m.genericName || ''}
              </option>
            ))}
          </datalist>
        </div>

        {/* General Advice & Follow-up */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              General Advice & Special Instructions
            </label>
            <textarea
              rows={2}
              placeholder="e.g., Drink warm water, avoid oily/spicy foods, rest for 2 days..."
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
              Follow-up Review Date
            </label>
            <input
              type="date"
              value={followUpDate}
              onChange={(e) => setFollowUpDate(e.target.value)}
              className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:border-blue-500"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              Will automatically schedule a follow-up reminder
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium shadow-sm shadow-blue-500/20 disabled:opacity-50 cursor-pointer"
          >
            {loading ? 'Saving...' : prescriptionToEdit ? 'Update Prescription' : 'Save Prescription'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
