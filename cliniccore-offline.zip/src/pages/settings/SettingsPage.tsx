import React, { useState, useEffect, useRef } from 'react';
import {
  Settings,
  Building,
  Upload,
  Download,
  RotateCcw,
  Database,
  Trash2,
  Save,
  CheckCircle2,
  AlertTriangle,
  Clock,
  DollarSign,
  ShieldAlert,
} from 'lucide-react';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { exportDatabaseBackup, restoreDatabaseBackup } from '../../services/backupService';
import { loadDemoData, clearAllClinicData } from '../../db/seedDemoData';
import { logActivity } from '../../services/auditService';
import type { ClinicSettings } from '../../types';

export const SettingsPage: React.FC = () => {
  const { settings, reloadSettings } = useClinic();
  const { user } = useAuth();
  const { success, error, warning } = useToast();

  const [clinicName, setClinicName] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [workingHours, setWorkingHours] = useState('');
  const [consultationFee, setConsultationFee] = useState<number>(500);
  const [currencySymbol, setCurrencySymbol] = useState('₹');
  const [taxPercent, setTaxPercent] = useState<number>(0);
  const [invoiceFooter, setInvoiceFooter] = useState('');
  const [idleTimeoutMinutes, setIdleTimeoutMinutes] = useState<number>(30);
  const [lowStockThreshold, setLowStockThreshold] = useState<number>(10);
  const [logoBase64, setLogoBase64] = useState<string | undefined>(undefined);

  const [saving, setSaving] = useState(false);

  // Backup file input ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Dialogs
  const [isDemoOpen, setIsDemoOpen] = useState(false);
  const [isResetOpen, setIsResetOpen] = useState(false);

  useEffect(() => {
    if (settings) {
      setClinicName(settings.clinicName || '');
      setAddress(settings.address || '');
      setCity(settings.city || '');
      setPhone(settings.phone || '');
      setEmail(settings.email || '');
      setWorkingHours(settings.workingHours || '');
      setConsultationFee(settings.consultationFee || 500);
      setCurrencySymbol(settings.currencySymbol || '₹');
      setTaxPercent(settings.taxPercent || 0);
      setInvoiceFooter(settings.invoiceFooter || '');
      setIdleTimeoutMinutes(settings.idleTimeoutMinutes || 30);
      setLowStockThreshold(settings.lowStockThreshold || 10);
      setLogoBase64(settings.logoBase64);
    }
  }, [settings]);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      error('Logo size must be under 2 MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setLogoBase64(reader.result as string);
      success('Logo loaded (click Save to store)');
    };
    reader.readAsDataURL(file);
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updated: ClinicSettings = {
        clinicName: clinicName.trim() || 'My Clinic',
        address: address.trim(),
        city: city.trim(),
        phone: phone.trim(),
        email: email.trim(),
        workingHours: workingHours.trim(),
        consultationFee,
        currencySymbol,
        taxPercent,
        invoiceFooter: invoiceFooter.trim(),
        idleTimeoutMinutes,
        lowStockThreshold,
        logoBase64,
        lastBackupDate: settings?.lastBackupDate,
      };

      await db.clinic_settings.put({ id: 1, ...updated });
      await logActivity(
        user?.name || 'Admin',
        user?.role || 'admin',
        'UPDATE_SETTINGS',
        'settings',
        'Updated clinic profile and preferences'
      );

      await reloadSettings();
      success('Settings saved successfully');
    } catch (err) {
      console.error(err);
      error('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleExportBackup = async () => {
    try {
      await exportDatabaseBackup(user?.name || 'Admin');
      await reloadSettings();
      success('Database backup exported successfully');
    } catch (err) {
      console.error(err);
      error('Failed to export backup');
    }
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const res = await restoreDatabaseBackup(text, user?.name || 'Admin');
      if (res.success) {
        success('Database restored successfully! Reloading...');
        setTimeout(() => {
          window.location.reload();
        }, 1200);
      } else {
        error(res.message || 'Restore failed');
      }
    } catch (err) {
      console.error(err);
      error('Invalid backup file');
    }
  };

  const handleLoadDemo = async () => {
    try {
      await loadDemoData(user?.name || 'Admin');
      success('Sample demo data loaded successfully!');
      setIsDemoOpen(false);
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (err) {
      console.error(err);
      error('Failed to load demo data');
    }
  };

  const handleClearAll = async () => {
    try {
      await clearAllClinicData(user?.name || 'Admin');
      success('Clinic records wiped successfully. Admin user preserved.');
      setIsResetOpen(false);
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (err) {
      console.error(err);
      error('Failed to clear data');
    }
  };

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Top Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Clinic Settings</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Configure clinic branding, offline database backup, print headers, and system preferences
        </p>
      </div>

      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* Clinic Identity & Contact */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <Building className="w-5 h-5 text-blue-600" />
            Clinic Branding & Contact
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Clinic / Hospital Name *
              </label>
              <input
                type="text"
                value={clinicName}
                onChange={(e) => setClinicName(e.target.value)}
                required
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 font-semibold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Phone Number
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Working Hours
              </label>
              <input
                type="text"
                placeholder="e.g., Mon - Sat: 9:00 AM - 8:00 PM"
                value={workingHours}
                onChange={(e) => setWorkingHours(e.target.value)}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Clinic Street Address
              </label>
              <input
                type="text"
                placeholder="e.g., Shop 4, Lotus Plaza, Station Road"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                City / Location
              </label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Default Consultation Fee
              </label>
              <input
                type="number"
                min="0"
                value={consultationFee}
                onChange={(e) => setConsultationFee(Number(e.target.value))}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>
          </div>

          {/* Logo Upload Box */}
          <div className="pt-3 border-t border-slate-100 flex items-center gap-4">
            <div className="w-16 h-16 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0">
              {logoBase64 ? (
                <img src={logoBase64} alt="Clinic Logo" className="w-full h-full object-contain" />
              ) : (
                <Building className="w-7 h-7 text-slate-400" />
              )}
            </div>

            <div>
              <label className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 cursor-pointer shadow-xs">
                <Upload className="w-4 h-4 text-blue-600" />
                Upload Clinic Logo (PNG/JPG)
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
              </label>
              <p className="text-[11px] text-slate-400 mt-1">
                Stored offline in IndexedDB; appears on invoices, prescriptions, and cards.
              </p>
            </div>
          </div>
        </div>

        {/* Financial & Document Configuration */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-600" />
            Financial & Document Print Terms
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Currency Symbol *
              </label>
              <select
                value={currencySymbol}
                onChange={(e) => setCurrencySymbol(e.target.value)}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white font-semibold"
              >
                <option value="₹">₹ (Indian Rupee - INR)</option>
                <option value="$">$ (US Dollar - USD)</option>
                <option value="€">€ (Euro - EUR)</option>
                <option value="£">£ (British Pound - GBP)</option>
                <option value="AED">AED (UAE Dirham)</option>
                <option value="SAR">SAR (Saudi Riyal)</option>
                <option value="Rs.">Rs. (Rupees)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Default Tax / GST (%)
              </label>
              <input
                type="number"
                min="0"
                max="50"
                value={taxPercent}
                onChange={(e) => setTaxPercent(Number(e.target.value))}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Invoice & Prescription Print Footer Notes
              </label>
              <textarea
                rows={2}
                placeholder="e.g., Medicines once sold will not be taken back. Emergency services available 24/7."
                value={invoiceFooter}
                onChange={(e) => setInvoiceFooter(e.target.value)}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>
          </div>
        </div>

        {/* System & Security Preferences */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-500" />
            System & Security Preferences
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Idle Auto-Logout (Minutes)
              </label>
              <input
                type="number"
                min="5"
                max="180"
                value={idleTimeoutMinutes}
                onChange={(e) => setIdleTimeoutMinutes(Number(e.target.value))}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Automatically logs out unattended sessions after idle time
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Low Medicine Stock Alert Threshold
              </label>
              <input
                type="number"
                min="1"
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(Number(e.target.value))}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Warns in pharmacy and dashboard when stock drops below this count
              </p>
            </div>
          </div>

          <div className="flex justify-end pt-3">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-sm shadow-blue-500/20 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {saving ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </div>
      </form>

      {/* Database Backup & Disaster Recovery */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <Database className="w-5 h-5 text-blue-600" />
              Offline Database Backup & Restore
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Export all clinic patients, invoices, prescriptions and medical records into a single portable JSON file
            </p>
          </div>

          {settings?.lastBackupDate ? (
            <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 font-semibold">
              Last Backup: {new Date(settings.lastBackupDate).toLocaleDateString()}
            </span>
          ) : (
            <span className="text-xs px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 font-semibold flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              Never Backed Up
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between space-y-3">
            <div>
              <h4 className="font-semibold text-slate-900 text-sm">Download Local Backup</h4>
              <p className="text-xs text-slate-500 mt-1">
                Saves an encrypted snapshot of the IndexedDB database to your downloads folder.
              </p>
            </div>
            <button
              type="button"
              onClick={handleExportBackup}
              className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-800 text-xs font-semibold shadow-xs transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-blue-600" />
              Export Full Database Backup (.json)
            </button>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between space-y-3">
            <div>
              <h4 className="font-semibold text-slate-900 text-sm">Restore from Backup</h4>
              <p className="text-xs text-slate-500 mt-1">
                Restore clinic state from a previous JSON export file on a new device or PC.
              </p>
            </div>
            <label className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-800 text-xs font-semibold shadow-xs transition-all cursor-pointer">
              <RotateCcw className="w-4 h-4 text-emerald-600" />
              Restore Database from File
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleRestoreFile}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>

      {/* Demo Data & Danger Zone */}
      {user?.role === 'admin' && (
        <div className="bg-white p-6 rounded-2xl border border-rose-200 shadow-xs space-y-4">
          <h3 className="font-bold text-rose-900 text-base flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-600" />
            Clinic Data Controls & Testing
          </h3>

          <div className="flex flex-col sm:flex-row gap-4 pt-1">
            <button
              type="button"
              onClick={() => setIsDemoOpen(true)}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold transition-all cursor-pointer"
            >
              <Database className="w-4 h-4" />
              Load Sample Demo Data
            </button>

            <button
              type="button"
              onClick={() => setIsResetOpen(true)}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs font-semibold transition-all cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              Wipe All Clinic Records (Reset)
            </button>
          </div>
        </div>
      )}

      {/* Load Demo Data Confirm */}
      <ConfirmDialog
        isOpen={isDemoOpen}
        title="Load Sample Demo Data"
        message="This will populate sample patients, appointments, prescriptions, inventory, and invoices so you can test all screens immediately. Existing accounts will remain intact."
        confirmLabel="Load Demo Data"
        variant="warning"
        onConfirm={handleLoadDemo}
        onCancel={() => setIsDemoOpen(false)}
      />

      {/* Clear All Data Confirm */}
      <ConfirmDialog
        isOpen={isResetOpen}
        title="WIPE ALL CLINIC RECORDS"
        message="WARNING: This will permanently delete all patients, appointments, invoices, prescriptions, and pharmacy sales from local IndexedDB! Your admin login will be kept. Are you absolutely certain?"
        confirmLabel="WIPE CLINIC DATA"
        variant="danger"
        onConfirm={handleClearAll}
        onCancel={() => setIsResetOpen(false)}
      />
    </div>
  );
};
