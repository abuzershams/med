import React, { useState } from 'react';
import { Modal } from '../../components/common/Modal';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { logActivity } from '../../services/auditService';
import type { Vitals } from '../../types';

interface VitalsModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientId: number;
  patientName: string;
  onSaved: () => void;
}

export const VitalsModal: React.FC<VitalsModalProps> = ({
  isOpen,
  onClose,
  patientId,
  patientName,
  onSaved,
}) => {
  const { user } = useAuth();
  const { success, error } = useToast();

  const [weightKg, setWeightKg] = useState<number | ''>('');
  const [heightCm, setHeightCm] = useState<number | ''>('');
  const [systolic, setSystolic] = useState<number | ''>('');
  const [diastolic, setDiastolic] = useState<number | ''>('');
  const [pulse, setPulse] = useState<number | ''>('');
  const [temperature, setTemperature] = useState<number | ''>('');
  const [spo2, setSpo2] = useState<number | ''>('');
  const [bloodSugar, setBloodSugar] = useState<number | ''>('');
  const [respiratoryRate, setRespiratoryRate] = useState<number | ''>('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  // Auto calculate BMI
  const bmi =
    typeof weightKg === 'number' && typeof heightCm === 'number' && heightCm > 0
      ? Number((weightKg / Math.pow(heightCm / 100, 2)).toFixed(1))
      : undefined;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const now = new Date();
      const dateStr = now.toISOString().split('T')[0];
      const timeStr = now.toTimeString().split(' ')[0].substring(0, 5);

      await db.vitals.add({
        patientId,
        recordedBy: user?.name || 'Staff',
        date: dateStr,
        time: timeStr,
        weightKg: typeof weightKg === 'number' ? weightKg : undefined,
        heightCm: typeof heightCm === 'number' ? heightCm : undefined,
        bmi,
        bloodPressureSystolic: typeof systolic === 'number' ? systolic : undefined,
        bloodPressureDiastolic: typeof diastolic === 'number' ? diastolic : undefined,
        pulseBpm: typeof pulse === 'number' ? pulse : undefined,
        temperatureF: typeof temperature === 'number' ? temperature : undefined,
        spo2Percent: typeof spo2 === 'number' ? spo2 : undefined,
        bloodSugarMgDl: typeof bloodSugar === 'number' ? bloodSugar : undefined,
        respiratoryRate: typeof respiratoryRate === 'number' ? respiratoryRate : undefined,
        notes: notes.trim() || undefined,
        createdAt: now.toISOString(),
      });

      await logActivity(
        user?.username || 'Staff',
        user?.role || 'staff',
        'Record Vitals',
        'Vitals',
        `Recorded vitals for patient ${patientName}`
      );

      success('Vitals recorded successfully!');
      onSaved();
      onClose();
    } catch (err: any) {
      error(err.message || 'Failed to save vitals');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Record Patient Vitals: ${patientName}`}
      subtitle="Digital physiological metrics with automatic BMI calculation"
      maxWidth="2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Height, Weight & Auto BMI */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Weight (kg)</label>
            <input
              type="number"
              step="0.1"
              placeholder="e.g. 70"
              value={weightKg}
              onChange={(e) => setWeightKg(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Height (cm)</label>
            <input
              type="number"
              step="0.5"
              placeholder="e.g. 172"
              value={heightCm}
              onChange={(e) => setHeightCm(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Auto BMI (kg/m²)</label>
            <div className="px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm font-bold text-blue-700 flex items-center justify-between">
              <span>{bmi !== undefined ? bmi : '-'}</span>
              {bmi && (
                <span className="text-[10px] font-medium text-slate-500">
                  {bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Normal' : bmi < 30 ? 'Overweight' : 'Obese'}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Blood Pressure & Pulse */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">BP Systolic (mmHg)</label>
            <input
              type="number"
              placeholder="e.g. 120"
              value={systolic}
              onChange={(e) => setSystolic(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">BP Diastolic (mmHg)</label>
            <input
              type="number"
              placeholder="e.g. 80"
              value={diastolic}
              onChange={(e) => setDiastolic(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Pulse (bpm)</label>
            <input
              type="number"
              placeholder="e.g. 72"
              value={pulse}
              onChange={(e) => setPulse(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Temp, SpO2, Blood Sugar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Temperature (°F)</label>
            <input
              type="number"
              step="0.1"
              placeholder="e.g. 98.6"
              value={temperature}
              onChange={(e) => setTemperature(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Oxygen Sat. SpO2 (%)</label>
            <input
              type="number"
              placeholder="e.g. 98"
              value={spo2}
              onChange={(e) => setSpo2(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Blood Sugar (mg/dL)</label>
            <input
              type="number"
              placeholder="e.g. 110"
              value={bloodSugar}
              onChange={(e) => setBloodSugar(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Clinical Observation Notes</label>
          <input
            type="text"
            placeholder="e.g. Patient appeared flushed, rested for 5 minutes prior to BP check"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex justify-end gap-3 pt-3 border-t">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 text-sm font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs disabled:opacity-50"
          >
            {loading ? 'Saving...' : 'Record Vitals'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
