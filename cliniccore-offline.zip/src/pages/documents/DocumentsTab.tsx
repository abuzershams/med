import React, { useState, useEffect } from 'react';
import {
  FileText,
  Upload,
  Download,
  Trash2,
  Eye,
  FileCheck,
  AlertCircle,
  Plus,
} from 'lucide-react';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { logActivity } from '../../services/auditService';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { Modal } from '../../components/common/Modal';
import type { MedicalDocument } from '../../types';

interface DocumentsTabProps {
  patientId: number;
  patientName: string;
}

const DOC_TYPES: MedicalDocument['documentType'][] = [
  'Lab Report',
  'X-Ray',
  'Prescription Scan',
  'Discharge Summary',
  'ID Proof',
  'Other',
];

const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB limit

export const DocumentsTab: React.FC<DocumentsTabProps> = ({ patientId, patientName }) => {
  const { user } = useAuth();
  const { success, error } = useToast();

  const [docs, setDocs] = useState<MedicalDocument[]>([]);
  const [loading, setLoading] = useState(true);

  // Upload modal state
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [docName, setDocName] = useState('');
  const [docType, setDocType] = useState<MedicalDocument['documentType']>('Lab Report');
  const [docDate, setDocDate] = useState(new Date().toISOString().split('T')[0]);
  const [docNotes, setDocNotes] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Preview & Delete state
  const [previewDoc, setPreviewDoc] = useState<{ url: string; mimeType: string; name: string } | null>(null);
  const [docToDelete, setDocToDelete] = useState<MedicalDocument | null>(null);

  const fetchDocs = async () => {
    setLoading(true);
    try {
      const all = await db.documents.where('patientId').equals(patientId).toArray();
      all.sort((a, b) => (b.id || 0) - (a.id || 0));
      setDocs(all);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDocs();
  }, [patientId]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > MAX_FILE_SIZE_BYTES) {
        error('File exceeds maximum size limit of 10 MB.');
        return;
      }
      setSelectedFile(file);
      if (!docName.trim()) {
        setDocName(file.name.replace(/\.[^/.]+$/, ''));
      }
    }
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile || !docName.trim()) {
      error('Please select a file and provide a document title.');
      return;
    }

    try {
      const now = new Date().toISOString();
      await db.documents.add({
        patientId,
        documentName: docName.trim(),
        documentType: docType,
        fileDataBlob: selectedFile,
        mimeType: selectedFile.type || 'application/octet-stream',
        fileSizeBytes: selectedFile.size,
        date: docDate,
        notes: docNotes.trim() || undefined,
        uploadedBy: user?.name || 'Staff',
        createdAt: now,
      });

      await logActivity(
        user?.username || 'Staff',
        user?.role || 'staff',
        'Upload Document',
        'Documents',
        `Uploaded ${docType} "${docName.trim()}" for ${patientName}`
      );

      success('Medical document saved successfully!');
      setIsUploadOpen(false);
      setSelectedFile(null);
      setDocName('');
      setDocNotes('');
      await fetchDocs();
    } catch (err: any) {
      error(err.message || 'Failed to save document');
    }
  };

  const handleDownload = (doc: MedicalDocument) => {
    const url = URL.createObjectURL(doc.fileDataBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${doc.documentName}_${doc.date}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    success('File downloaded.');
  };

  const handlePreview = (doc: MedicalDocument) => {
    const url = URL.createObjectURL(doc.fileDataBlob);
    setPreviewDoc({ url, mimeType: doc.mimeType, name: doc.documentName });
  };

  const handleDelete = async () => {
    if (!docToDelete || !docToDelete.id) return;
    try {
      await db.documents.delete(docToDelete.id);
      await logActivity(
        user?.username || 'Staff',
        user?.role || 'staff',
        'Delete Document',
        'Documents',
        `Deleted ${docToDelete.documentName} for ${patientName}`
      );
      success('Document deleted.');
      setDocToDelete(null);
      await fetchDocs();
    } catch (err: any) {
      error(err.message || 'Failed to delete document');
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between pb-2 border-b">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Medical Reports, Scans & Files</h3>
          <p className="text-xs text-slate-500">Stored locally as binary Blobs in IndexedDB (Max 10 MB)</p>
        </div>
        <button
          onClick={() => setIsUploadOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition-colors shadow-xs"
        >
          <Plus className="w-3.5 h-3.5" />
          Upload Document
        </button>
      </div>

      {docs.length === 0 ? (
        <div className="p-8 text-center bg-slate-50 border border-dashed rounded-xl text-slate-400 text-xs">
          No medical documents or scans uploaded for this patient yet.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {docs.map((doc) => (
            <div
              key={doc.id}
              className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 border border-blue-200">
                    {doc.documentType}
                  </span>
                  <span className="text-[11px] text-slate-400">{doc.date}</span>
                </div>
                <h4 className="font-semibold text-slate-900 text-sm truncate" title={doc.documentName}>
                  {doc.documentName}
                </h4>
                <p className="text-[11px] text-slate-500 mt-1">
                  Size: {formatFileSize(doc.fileSizeBytes)} • By: {doc.uploadedBy}
                </p>
                {doc.notes && <p className="text-xs text-slate-600 italic mt-2 line-clamp-2">{doc.notes}</p>}
              </div>

              <div className="flex items-center justify-end gap-1 pt-3 mt-3 border-t border-slate-100">
                <button
                  onClick={() => handlePreview(doc)}
                  className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors"
                  title="Preview"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDownload(doc)}
                  className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-slate-100 rounded-lg transition-colors"
                  title="Download"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setDocToDelete(doc)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  title="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Upload Modal */}
      <Modal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        title="Upload Patient Document / Scan"
        subtitle="Supported formats: Images (PNG, JPG), PDF reports, Lab documents up to 10 MB"
      >
        <form onSubmit={handleUploadSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Select File *</label>
            <input
              type="file"
              required
              onChange={handleFileChange}
              className="w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer"
            />
            {selectedFile && (
              <p className="text-[11px] text-emerald-600 mt-1 font-medium">
                Selected: {selectedFile.name} ({formatFileSize(selectedFile.size)})
              </p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Document Title *</label>
            <input
              type="text"
              required
              placeholder="e.g. Chest X-Ray PA View, Lipid Profile Report"
              value={docName}
              onChange={(e) => setDocName(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Document Category</label>
              <select
                value={docType}
                onChange={(e) => setDocType(e.target.value as any)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              >
                {DOC_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Report Date</label>
              <input
                type="date"
                required
                value={docDate}
                onChange={(e) => setDocDate(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Clinical Remarks / Notes</label>
            <input
              type="text"
              placeholder="e.g. Normal sinus rhythm confirmed by radiologist"
              value={docNotes}
              onChange={(e) => setDocNotes(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t">
            <button
              type="button"
              onClick={() => setIsUploadOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 text-sm font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs"
            >
              Save Document
            </button>
          </div>
        </form>
      </Modal>

      {/* Document Preview Modal */}
      {previewDoc && (
        <Modal
          isOpen={Boolean(previewDoc)}
          onClose={() => setPreviewDoc(null)}
          title={`Document Preview: ${previewDoc.name}`}
          maxWidth="4xl"
        >
          <div className="flex justify-center p-2 bg-slate-100 rounded-xl max-h-[70vh] overflow-auto">
            {previewDoc.mimeType.startsWith('image/') ? (
              <img src={previewDoc.url} alt={previewDoc.name} className="max-w-full h-auto rounded-lg shadow-sm" />
            ) : previewDoc.mimeType === 'application/pdf' ? (
              <iframe src={previewDoc.url} title={previewDoc.name} className="w-full h-[65vh] rounded-lg border" />
            ) : (
              <div className="p-8 text-center text-slate-500">
                <FileText className="w-12 h-12 mx-auto mb-2 text-slate-400" />
                <p className="text-sm font-semibold text-slate-700">Preview not supported for this file format.</p>
                <p className="text-xs text-slate-400 mt-1">Please download the document to view it on your device.</p>
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* Delete ConfirmDialog */}
      <ConfirmDialog
        isOpen={Boolean(docToDelete)}
        title="Delete Medical Document"
        message={`Are you sure you want to permanently delete "${docToDelete?.documentName}"?`}
        confirmLabel="Yes, Delete"
        cancelLabel="Cancel"
        variant="danger"
        iconType="trash"
        onConfirm={handleDelete}
        onCancel={() => setDocToDelete(null)}
      />
    </div>
  );
};
