import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  User,
  Stethoscope,
  FileText,
  Search,
  CheckCircle2,
  Tag,
} from 'lucide-react';
import { Modal } from '../../components/common/Modal';
import { DatePicker } from '../../components/common/DatePicker';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { logActivity } from '../../services/auditService';
import type { Appointment, Patient, Doctor, AppointmentStatus } from '../../types';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedPatient?: Patient | null;
  appointmentToEdit?: Appointment | null;
  onSaved: () => void;
}

const APPT_STATUSES: AppointmentStatus[] = [
  'Scheduled',
  'Waiting',
  'In Consultation',
  'Completed',
  'No-show',
  'Cancelled',
];

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  preselectedPatient,
  appointmentToEdit,
  onSaved,
}) => {
  const { user } = useAuth();
  const { success, error } = useToast();

  const [patients, setPatients] = useState<Patient[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);

  const [selectedPatientId, setSelectedPatientId] = useState<number | ''>('');
  const [patientSearch, setPatientSearch] = useState('');
  const [selectedDoctorId, setSelectedDoctorId] = useState<number | ''>('');
  const [date, setDate] = useState<string>('');
  const [time, setTime] = useState<string>('09:30');
  const [reason, setReason] = useState<string>('');
  const [status, setStatus] = useState<AppointmentStatus>('Scheduled');
  const [notes, setNotes] = useState<string>('');
  const [tokenNumber, setTokenNumber] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);

  // Load patients and active doctors
  useEffect(() => {
    async function loadData() {
      const allP = await db.patients.toArray();
      setPatients(allP);
      const allD = await db.doctors.where('status').equals('active').toArray();
      setDoctors(allD);

      if (appointmentToEdit) {
        setSelectedPatientId(appointmentToEdit.patientId);
        setSelectedDoctorId(appointmentToEdit.doctorId);
        setDate(appointmentToEdit.date);
        setTime(appointmentToEdit.time);
        setReason(appointmentToEdit.reason || '');
        setStatus(appointmentToEdit.status);
        setNotes(appointmentToEdit.notes || '');
        setTokenNumber(appointmentToEdit.tokenNumber);
      } else {
        const todayStr = new Date().toISOString().split('T')[0];
        setDate(todayStr);
        if (preselectedPatient?.id) {
          setSelectedPatientId(preselectedPatient.id);
        } else if (allP.length > 0) {
          setSelectedPatientId(allP[0].id!);
        }
        if (allD.length > 0) {
          setSelectedDoctorId(allD[0].id!);
        }
        setStatus('Scheduled');
        setReason('');
        setNotes('');
      }
    }
    if (isOpen) {
      loadData();
    }
  }, [isOpen, appointmentToEdit, preselectedPatient]);

  // Auto calculate next token number for selected doctor and date
  useEffect(() => {
    async function calculateToken() {
      if (!appointmentToEdit && selectedDoctorId && date) {
        const existing = await db.appointments
          .where('[doctorId+date]')
          .equals([Number(selectedDoctorId), date])
          .toArray();
        setTokenNumber(existing.length + 1);
      }
    }
    calculateToken();
  }, [selectedDoctorId, date, appointmentToEdit]);

  // Filtered patients for searchable select
  const filteredPatients = patients.filter((p) => {
    if (!patientSearch.trim()) return true;
    const q = patientSearch.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.patientCode.toLowerCase().includes(q) ||
      p.phone.includes(q)
    );
  });

  const selectedPatientObj = patients.find((p) => p.id === selectedPatientId);
  const selectedDoctorObj = doctors.find((d) => d.id === selectedDoctorId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatientId || !selectedDoctorId || !date || !time) {
      error('Please select patient, doctor, appointment date and time.');
      return;
    }

    setLoading(true);
    try {
      const patient = await db.patients.get(Number(selectedPatientId));
      const doctor = await db.doctors.get(Number(selectedDoctorId));

      if (!patient || !doctor) {
        throw new Error('Selected patient or doctor not found.');
      }

      // Check double-booking constraint: same doctor, same date, same time
      const conflicting = await db.appointments
        .where('[doctorId+date]')
        .equals([doctor.id!, date])
        .filter((a) => a.time === time && a.id !== appointmentToEdit?.id && a.status !== 'Cancelled')
        .first();

      if (conflicting) {
        throw new Error(
          `Dr. ${doctor.name} already has an appointment booked at ${time} on ${date} for ${conflicting.patientName}. Double-booking is blocked.`
        );
      }

      const now = new Date().toISOString();

      if (appointmentToEdit && appointmentToEdit.id) {
        await db.appointments.update(appointmentToEdit.id, {
          patientId: patient.id!,
          patientName: patient.name,
          patientCode: patient.patientCode,
          patientPhone: patient.phone,
          doctorId: doctor.id!,
          doctorName: doctor.name,
          date,
          time,
          tokenNumber,
          reason: reason.trim() || undefined,
          status,
          notes: notes.trim() || undefined,
          updatedAt: now,
        });

        await logActivity(
          user?.username || 'Staff',
          user?.role || 'staff',
          'Reschedule/Update Appointment',
          'Appointments',
          `Updated appointment for ${patient.name} with ${doctor.name} on ${date}`
        );

        success('Appointment updated successfully!');
      } else {
        await db.appointments.add({
          patientId: patient.id!,
          patientName: patient.name,
          patientCode: patient.patientCode,
          patientPhone: patient.phone,
          doctorId: doctor.id!,
          doctorName: doctor.name,
          date,
          time,
          tokenNumber,
          reason: reason.trim() || undefined,
          status,
          notes: notes.trim() || undefined,
          createdAt: now,
          updatedAt: now,
        });

        await logActivity(
          user?.username || 'Staff',
          user?.role || 'staff',
          'Book Appointment',
          'Appointments',
          `Booked token #${tokenNumber} for ${patient.name} with ${doctor.name} at ${time}`
        );

        success(`Appointment booked! Token #${tokenNumber}`);
      }

      onSaved();
      onClose();
    } catch (err: any) {
      error(err.message || 'Failed to book appointment');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={appointmentToEdit ? 'Reschedule / Update Appointment' : 'Book Clinical Appointment'}
      subtitle="Token-based scheduling with conflict and double-booking prevention"
      maxWidth="xl"
    >
      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Patient Selection Card */}
        <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/80 space-y-3">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-semibold text-slate-700 flex items-center gap-1.5">
              <User className="w-4 h-4 text-blue-600" />
              Patient Selection <span className="text-rose-500">*</span>
            </label>
            {selectedPatientObj && (
              <span className="text-[11px] font-mono text-blue-600 font-semibold bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200">
                {selectedPatientObj.patientCode}
              </span>
            )}
          </div>

          {/* Quick Search filter if many patients */}
          {patients.length > 5 && (
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Type to filter patients (name, ID or phone)..."
                value={patientSearch}
                onChange={(e) => setPatientSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>
          )}

          <select
            value={selectedPatientId}
            onChange={(e) => setSelectedPatientId(Number(e.target.value))}
            className="w-full min-h-[44px] px-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15 focus:outline-hidden transition-all cursor-pointer"
          >
            {filteredPatients.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.patientCode} · {p.phone} · {p.gender} {p.age ? `${p.age}y` : ''})
              </option>
            ))}
          </select>
        </div>

        {/* Consulting Doctor Selection */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <Stethoscope className="w-4 h-4 text-teal-600" />
            Consulting Doctor <span className="text-rose-500">*</span>
          </label>
          <select
            value={selectedDoctorId}
            onChange={(e) => setSelectedDoctorId(Number(e.target.value))}
            className="w-full min-h-[44px] px-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15 focus:outline-hidden transition-all cursor-pointer"
          >
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                Dr. {d.name} ({d.specialization} · Fee: ₹{d.consultationFee})
              </option>
            ))}
          </select>
        </div>

        {/* Date, Time & Token Details */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <DatePicker
              label="Date"
              required
              value={date}
              onChange={setDate}
              placeholder="Select date"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              Time Slot <span className="text-rose-500">*</span>
            </label>
            <input
              type="time"
              required
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full min-h-[44px] px-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15 focus:outline-hidden transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
              <Tag className="w-3.5 h-3.5 text-blue-600" />
              Day Token
            </label>
            <div className="min-h-[44px] px-3.5 py-2 bg-blue-50/80 border border-blue-200 rounded-xl text-base font-bold text-blue-700 flex items-center justify-center tracking-wide">
              Token #{tokenNumber}
            </div>
          </div>
        </div>

        {/* Status Selection */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">Appointment Status</label>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 p-1 bg-slate-100 rounded-xl">
            {APPT_STATUSES.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStatus(s)}
                className={`py-2 px-1 text-[11px] font-semibold rounded-lg transition-all text-center truncate ${
                  status === s
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                }`}
                title={s}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Reason for Visit */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Chief Reason for Visit</label>
          <input
            type="text"
            placeholder="e.g. High fever, hypertension followup, knee pain..."
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full min-h-[44px] px-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15 focus:outline-hidden transition-all"
          />
        </div>

        {/* Staff Notes */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
            <FileText className="w-3.5 h-3.5 text-slate-400" />
            Staff Notes / Pre-visit Preparation
          </label>
          <input
            type="text"
            placeholder="e.g. Fasting required for lipid profile, wheel-chair assist..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full min-h-[44px] px-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15 focus:outline-hidden transition-all"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 text-xs sm:text-sm font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors shadow-2xs"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center gap-2 px-6 py-2.5 text-xs sm:text-sm font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition-colors shadow-xs disabled:opacity-50"
          >
            {loading && <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />}
            {appointmentToEdit ? 'Save Changes' : 'Confirm Appointment'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
