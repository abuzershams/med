import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  Plus,
  ChevronLeft,
  ChevronRight,
  Clock,
  User,
  MessageCircle,
  Filter,
  CheckCircle2,
  XCircle,
  AlertCircle,
  RotateCcw,
} from 'lucide-react';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useClinic } from '../../context/ClinicContext';
import { logActivity } from '../../services/auditService';
import { StatusBadge } from '../../components/common/Badge';
import { EmptyState, LoadingSpinner } from '../../components/common/EmptyState';
import { AppointmentModal } from './AppointmentModal';
import type { Appointment, Doctor, AppointmentStatus } from '../../types';

export const AppointmentsPage: React.FC = () => {
  const { user, checkPermission } = useAuth();
  const { settings, formatDate } = useClinic();
  const { success, error } = useToast();

  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedDoctorFilter, setSelectedDoctorFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'day' | 'table'>('day');

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [appointmentToEdit, setAppointmentToEdit] = useState<Appointment | null>(null);

  const fetchAppointments = async () => {
    setLoading(true);
    try {
      const allAppts = await db.appointments.toArray();
      setAppointments(allAppts);

      const allDocs = await db.doctors.toArray();
      setDoctors(allDocs);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  // Date controls
  const handleDateShift = (deltaDays: number) => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + deltaDays);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const handleToday = () => {
    setSelectedDate(new Date().toISOString().split('T')[0]);
  };

  // Status changer
  const handleStatusChange = async (appt: Appointment, newStatus: AppointmentStatus) => {
    try {
      await db.appointments.update(appt.id!, {
        status: newStatus,
        updatedAt: new Date().toISOString(),
      });
      await logActivity(
        user?.username || 'Staff',
        user?.role || 'staff',
        'Update Appointment Status',
        'Appointments',
        `Changed status of token #${appt.tokenNumber} (${appt.patientName}) to ${newStatus}`
      );
      success(`Token #${appt.tokenNumber} marked as ${newStatus}`);
      await fetchAppointments();
    } catch (err: any) {
      error(err.message || 'Failed to update status');
    }
  };

  // Filtered appointments for the chosen date & doctor
  const dayAppointments = useMemo(() => {
    return appointments.filter((a) => {
      const matchDate = a.date === selectedDate;
      const matchDoc = selectedDoctorFilter === 'all' || String(a.doctorId) === selectedDoctorFilter;
      return matchDate && matchDoc;
    }).sort((a, b) => a.tokenNumber - b.tokenNumber || a.time.localeCompare(b.time));
  }, [appointments, selectedDate, selectedDoctorFilter]);

  // Grouped by Doctor for Day View
  const doctorGroups = useMemo(() => {
    const groups: { doctor: Doctor | { id: number; name: string }; appts: Appointment[] }[] = [];
    const targetDocs =
      selectedDoctorFilter === 'all'
        ? doctors
        : doctors.filter((d) => String(d.id) === selectedDoctorFilter);

    targetDocs.forEach((doc) => {
      const docAppts = dayAppointments.filter((a) => a.doctorId === doc.id);
      groups.push({ doctor: doc, appts: docAppts });
    });

    return groups;
  }, [doctors, dayAppointments, selectedDoctorFilter]);

  // WhatsApp Reminder Link
  const getWhatsAppLink = (appt: Appointment) => {
    const text = encodeURIComponent(
      `Hello ${appt.patientName}, this is a reminder from ${settings?.clinicName || 'our clinic'} for your appointment with ${appt.doctorName} on ${appt.date} at ${appt.time} (Token #${appt.tokenNumber}). Please arrive 10 minutes early.`
    );
    const cleanPhone = (appt.patientPhone || '').replace(/[^0-9]/g, '');
    return `https://wa.me/${cleanPhone.length === 10 ? '91' + cleanPhone : cleanPhone}?text=${text}`;
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <CalendarIcon className="w-6 h-6 text-blue-600" />
            Appointments & Token Queue
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time day scheduling, doctor consultation token tracking & status pipeline
          </p>
        </div>

        {checkPermission('appointments') && (
          <button
            onClick={() => {
              setAppointmentToEdit(null);
              setIsModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            Book Appointment
          </button>
        )}
      </div>

      {/* Date Navigation & View Mode Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
        {/* Date Navigator */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => handleDateShift(-1)}
            className="p-1.5 border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-600"
            title="Previous Day"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={handleToday}
            className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            Today
          </button>

          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
          />

          <button
            type="button"
            onClick={() => handleDateShift(1)}
            className="p-1.5 border border-slate-300 rounded-lg hover:bg-slate-50 text-slate-600"
            title="Next Day"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <span className="text-xs font-semibold text-slate-500 ml-2 hidden md:inline">
            ({formatDate(selectedDate)})
          </span>
        </div>

        {/* Doctor Filter & View Toggle */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedDoctorFilter}
              onChange={(e) => setSelectedDoctorFilter(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-700"
            >
              <option value="all">All Doctors</option>
              {doctors.map((d) => (
                <option key={d.id} value={String(d.id)}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-semibold">
            <button
              onClick={() => setViewMode('day')}
              className={`px-3 py-1 rounded-lg transition-all ${
                viewMode === 'day' ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Doctor Tokens
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1 rounded-lg transition-all ${
                viewMode === 'table' ? 'bg-white text-blue-700 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Table View
            </button>
          </div>
        </div>
      </div>

      {/* Main Body */}
      {loading ? (
        <LoadingSpinner message="Loading appointment schedule..." />
      ) : dayAppointments.length === 0 ? (
        <EmptyState
          icon={CalendarIcon}
          title={`No appointments booked for ${formatDate(selectedDate)}`}
          description="Click Book Appointment to schedule a patient consultation with automatic token assignment."
          actionLabel={checkPermission('appointments') ? 'Book Appointment' : undefined}
          onAction={() => {
            setAppointmentToEdit(null);
            setIsModalOpen(true);
          }}
        />
      ) : viewMode === 'day' ? (
        /* DAY VIEW (Grouped by Doctor with Token Boards) */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {doctorGroups.map(({ doctor, appts }) => (
            <div
              key={doctor.id}
              className="p-5 bg-white rounded-3xl border border-slate-200/90 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between pb-3 mb-4 border-b">
                  <div>
                    <h3 className="text-base font-bold text-slate-900">{doctor.name}</h3>
                    <p className="text-[11px] text-slate-500">
                      {'specialization' in doctor ? doctor.specialization : ''}
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                    {appts.length} Token{appts.length === 1 ? '' : 's'}
                  </span>
                </div>

                {appts.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-8 italic">No tokens assigned today.</p>
                ) : (
                  <div className="space-y-3">
                    {appts.map((appt) => (
                      <div
                        key={appt.id}
                        className="p-3.5 rounded-2xl bg-slate-50/80 border border-slate-200/80 text-xs space-y-2 hover:border-slate-300 transition-all"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2.5">
                            <span className="w-8 h-8 rounded-xl bg-blue-600 text-white font-extrabold flex items-center justify-center text-sm shadow-xs">
                              #{appt.tokenNumber}
                            </span>
                            <div>
                              <p className="font-bold text-slate-900 text-sm">{appt.patientName}</p>
                              <p className="text-[11px] text-slate-500 flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-400" />
                                {appt.time} • {appt.patientCode}
                              </p>
                            </div>
                          </div>
                          <StatusBadge status={appt.status} />
                        </div>

                        {appt.reason && (
                          <p className="text-slate-600 text-[11px] bg-white p-2 rounded-lg border border-slate-200">
                            <strong className="text-slate-700">Reason:</strong> {appt.reason}
                          </p>
                        )}

                        {/* Status Pipeline Buttons */}
                        <div className="flex flex-wrap items-center justify-between gap-1 pt-2 border-t border-slate-200/60">
                          <div className="flex items-center gap-1">
                            {appt.status !== 'Waiting' && appt.status !== 'Completed' && (
                              <button
                                onClick={() => handleStatusChange(appt, 'Waiting')}
                                className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-800 hover:bg-amber-200"
                              >
                                Waiting
                              </button>
                            )}
                            {appt.status !== 'In Consultation' && appt.status !== 'Completed' && (
                              <button
                                onClick={() => handleStatusChange(appt, 'In Consultation')}
                                className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-100 text-purple-800 hover:bg-purple-200"
                              >
                                In Cabin
                              </button>
                            )}
                            {appt.status !== 'Completed' && (
                              <button
                                onClick={() => handleStatusChange(appt, 'Completed')}
                                className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800 hover:bg-emerald-200"
                              >
                                Done
                              </button>
                            )}
                          </div>

                          <div className="flex items-center gap-1">
                            {appt.patientPhone && (
                              <a
                                href={getWhatsAppLink(appt)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                                title="WhatsApp Reminder"
                              >
                                <MessageCircle className="w-3.5 h-3.5" />
                              </a>
                            )}
                            <button
                              onClick={() => {
                                setAppointmentToEdit(appt);
                                setIsModalOpen(true);
                              }}
                              className="text-[11px] text-blue-600 hover:underline font-semibold"
                            >
                              Edit
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* TABLE VIEW */
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden text-xs">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b text-[11px] uppercase font-semibold text-slate-500">
              <tr>
                <th className="py-3 px-4">Token</th>
                <th className="py-3 px-4">Patient</th>
                <th className="py-3 px-4">Doctor</th>
                <th className="py-3 px-4">Time</th>
                <th className="py-3 px-4">Reason</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {dayAppointments.map((appt) => (
                <tr key={appt.id} className="hover:bg-slate-50/50">
                  <td className="py-3 px-4 font-mono font-bold text-blue-600">#{appt.tokenNumber}</td>
                  <td className="py-3 px-4 font-semibold text-slate-900">
                    {appt.patientName} <span className="text-[11px] text-slate-400 font-normal">({appt.patientCode})</span>
                  </td>
                  <td className="py-3 px-4 text-slate-700">{appt.doctorName}</td>
                  <td className="py-3 px-4 text-slate-700">{appt.time}</td>
                  <td className="py-3 px-4 text-slate-600">{appt.reason || '-'}</td>
                  <td className="py-3 px-4">
                    <StatusBadge status={appt.status} />
                  </td>
                  <td className="py-3 px-4 text-right space-x-2">
                    {appt.patientPhone && (
                      <a
                        href={getWhatsAppLink(appt)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-emerald-600 hover:underline font-semibold"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        WA
                      </a>
                    )}
                    <button
                      onClick={() => {
                        setAppointmentToEdit(appt);
                        setIsModalOpen(true);
                      }}
                      className="text-blue-600 hover:underline font-semibold"
                    >
                      Reschedule
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Appointment Modal */}
      <AppointmentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        appointmentToEdit={appointmentToEdit}
        onSaved={fetchAppointments}
      />
    </div>
  );
};
