import React, { useState, useEffect } from 'react';
import {
  HeartPulse,
  Plus,
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Phone,
  User,
  Trash2,
  Edit,
  Search,
} from 'lucide-react';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { StatCard } from '../../components/common/StatCard';
import { StatusBadge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { logActivity } from '../../services/auditService';
import type { FollowUp, Patient, Doctor } from '../../types';

export const FollowupsPage: React.FC = () => {
  const { formatDate } = useClinic();
  const { user } = useAuth();
  const { success, error } = useToast();

  const [followups, setFollowups] = useState<FollowUp[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);

  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'completed' | 'overdue'>('all');
  const [search, setSearch] = useState('');

  // New / Edit Followup Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<FollowUp | null>(null);

  const [selectedPatientId, setSelectedPatientId] = useState<number | ''>('');
  const [selectedDoctorId, setSelectedDoctorId] = useState<number | ''>('');
  const [scheduledDate, setScheduledDate] = useState(
    new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [reason, setReason] = useState('Routine review / check-up');

  // Delete
  const [itemToDelete, setItemToDelete] = useState<FollowUp | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const allF = await db.follow_ups.reverse().sortBy('scheduledDate');
      setFollowups(allF);
      const allP = await db.patients.toArray();
      setPatients(allP);
      const allD = await db.doctors.where('status').equals('active').toArray();
      setDoctors(allD);
    } catch (err) {
      console.error(err);
      error('Failed to load follow-ups');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const todayStr = new Date().toISOString().split('T')[0];

  const pendingCount = followups.filter((f) => f.status === 'pending' && f.scheduledDate >= todayStr).length;
  const overdueCount = followups.filter((f) => f.status === 'pending' && f.scheduledDate < todayStr).length;
  const completedCount = followups.filter((f) => f.status === 'completed').length;
  const todayDueCount = followups.filter((f) => f.status === 'pending' && f.scheduledDate === todayStr).length;

  const filtered = followups.filter((f) => {
    const q = search.toLowerCase();
    const matchesSearch =
      f.patientName.toLowerCase().includes(q) ||
      (f.patientPhone && f.patientPhone.includes(q)) ||
      (f.doctorName && f.doctorName.toLowerCase().includes(q)) ||
      f.reason.toLowerCase().includes(q);

    let matchesStatus = true;
    if (statusFilter === 'pending') {
      matchesStatus = f.status === 'pending' && f.scheduledDate >= todayStr;
    } else if (statusFilter === 'overdue') {
      matchesStatus = f.status === 'pending' && f.scheduledDate < todayStr;
    } else if (statusFilter === 'completed') {
      matchesStatus = f.status === 'completed';
    }

    return matchesSearch && matchesStatus;
  });

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatientId || !selectedDoctorId) {
      error('Please select both patient and doctor');
      return;
    }

    const pat = patients.find((p) => p.id === selectedPatientId);
    const doc = doctors.find((d) => d.id === selectedDoctorId);

    try {
      if (editingItem?.id) {
        await db.follow_ups.update(editingItem.id, {
          patientId: Number(selectedPatientId),
          patientName: pat?.name || '',
          patientPhone: pat?.phone || '',
          doctorId: Number(selectedDoctorId),
          doctorName: doc?.name || '',
          scheduledDate,
          reason: reason.trim(),
        });
        success('Follow-up updated');
      } else {
        await db.follow_ups.add({
          patientId: Number(selectedPatientId),
          patientName: pat?.name || '',
          patientPhone: pat?.phone || '',
          doctorId: Number(selectedDoctorId),
          doctorName: doc?.name || '',
          scheduledDate,
          reason: reason.trim(),
          status: 'pending',
        });
        success('Follow-up scheduled successfully');
      }

      await logActivity(
        user?.name || 'User',
        user?.role || 'doctor',
        'SCHEDULE_FOLLOWUP',
        'followups',
        `Scheduled follow-up for ${pat?.name} on ${scheduledDate}`
      );

      setIsModalOpen(false);
      setEditingItem(null);
      loadData();
    } catch (err) {
      console.error(err);
      error('Failed to save follow-up');
    }
  };

  const handleMarkCompleted = async (item: FollowUp) => {
    if (!item.id) return;
    try {
      await db.follow_ups.update(item.id, { status: 'completed' });
      await logActivity(
        user?.name || 'User',
        user?.role || 'doctor',
        'COMPLETE_FOLLOWUP',
        'followups',
        `Marked follow-up completed for ${item.patientName}`
      );
      success('Marked as completed');
      loadData();
    } catch (err) {
      console.error(err);
      error('Failed to update follow-up');
    }
  };

  const handleDelete = async () => {
    if (!itemToDelete || !itemToDelete.id) return;
    try {
      await db.follow_ups.delete(itemToDelete.id);
      success('Follow-up deleted');
      setItemToDelete(null);
      loadData();
    } catch (err) {
      console.error(err);
      error('Failed to delete follow-up');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Patient Follow-ups</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Track routine reviews, recovery calls, lab review dates, and scheduled revisits
          </p>
        </div>

        <button
          onClick={() => {
            setEditingItem(null);
            if (patients.length > 0) setSelectedPatientId(patients[0].id!);
            if (doctors.length > 0) setSelectedDoctorId(doctors[0].id!);
            setIsModalOpen(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm shadow-sm shadow-blue-500/20 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Schedule Follow-up
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Due Today"
          value={todayDueCount}
          subtitle="Scheduled for today"
          icon={Calendar}
          colorScheme="blue"
        />
        <StatCard
          title="Upcoming"
          value={pendingCount}
          subtitle="Scheduled future dates"
          icon={Clock}
          colorScheme="amber"
        />
        <StatCard
          title="Overdue"
          value={overdueCount}
          subtitle="Past date, pending review"
          icon={AlertTriangle}
          colorScheme="rose"
        />
        <StatCard
          title="Completed"
          value={completedCount}
          subtitle="Successfully attended"
          icon={CheckCircle2}
          colorScheme="emerald"
        />
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative flex-1 w-full sm:max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by patient, phone, doctor, or reason..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 self-stretch sm:self-auto">
          {(['all', 'pending', 'overdue', 'completed'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg capitalize transition-all cursor-pointer ${
                statusFilter === tab
                  ? 'bg-white text-blue-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Follow-ups Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-semibold text-slate-500">
              <tr>
                <th className="px-5 py-3.5">Scheduled Date</th>
                <th className="px-4 py-3.5">Patient</th>
                <th className="px-4 py-3.5">Doctor</th>
                <th className="px-4 py-3.5">Reason / Notes</th>
                <th className="px-4 py-3.5 text-center">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-slate-400 text-xs">
                    No follow-ups found for the selected filter.
                  </td>
                </tr>
              ) : (
                filtered.map((item) => {
                  const isOverdue = item.status === 'pending' && item.scheduledDate < todayStr;
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/80">
                      <td className="px-5 py-3.5">
                        <div className="font-semibold text-slate-900">{formatDate(item.scheduledDate)}</div>
                        {isOverdue && (
                          <span className="text-[10px] text-rose-600 font-bold uppercase tracking-wider">
                            Overdue
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-medium text-slate-900">{item.patientName}</div>
                        {item.patientPhone && (
                          <div className="text-xs text-slate-400 flex items-center gap-1">
                            <Phone className="w-3 h-3 text-slate-400" />
                            {item.patientPhone}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3.5 text-slate-700">
                        {item.doctorName ? `Dr. ${item.doctorName}` : '—'}
                      </td>
                      <td className="px-4 py-3.5 text-slate-900 font-medium max-w-xs truncate">
                        {item.reason}
                      </td>
                      <td className="px-4 py-3.5 text-center">
                        <StatusBadge status={item.status} />
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {item.status === 'pending' && (
                            <button
                              onClick={() => handleMarkCompleted(item)}
                              className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                              title="Mark as Completed"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Done
                            </button>
                          )}
                          <button
                            onClick={() => {
                              setEditingItem(item);
                              setSelectedPatientId(item.patientId);
                              setSelectedDoctorId(item.doctorId);
                              setScheduledDate(item.scheduledDate);
                              setReason(item.reason);
                              setIsModalOpen(true);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50"
                            title="Edit"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setItemToDelete(item)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Schedule / Edit Modal */}
      {isModalOpen && (
        <Modal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          title={editingItem ? 'Edit Follow-up' : 'Schedule Patient Follow-up'}
          subtitle="Set next review date and reminder notes"
          maxWidth="md"
        >
          <form onSubmit={handleSave} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Patient *
              </label>
              <select
                value={selectedPatientId}
                onChange={(e) => setSelectedPatientId(Number(e.target.value))}
                required
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white"
              >
                <option value="">Select Patient...</option>
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.patientCode}) - {p.phone}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Doctor *
              </label>
              <select
                value={selectedDoctorId}
                onChange={(e) => setSelectedDoctorId(Number(e.target.value))}
                required
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white"
              >
                <option value="">Select Doctor...</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    Dr. {d.name} ({d.specialization})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Scheduled Follow-up Date *
              </label>
              <input
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                required
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Reason / Clinical Purpose *
              </label>
              <textarea
                rows={2}
                placeholder="e.g., Check BP response, review thyroid panel reports..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                required
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium shadow-sm shadow-blue-500/20 cursor-pointer"
              >
                {editingItem ? 'Update Follow-up' : 'Schedule Follow-up'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!itemToDelete}
        title="Delete Follow-up"
        message={`Delete scheduled follow-up for "${itemToDelete?.patientName}"?`}
        confirmLabel="Delete"
        variant="danger"
        onConfirm={handleDelete}
        onCancel={() => setItemToDelete(null)}
      />
    </div>
  );
};
