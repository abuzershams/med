import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  Plus,
  Search,
  Trash2,
  Printer,
  CreditCard,
  DollarSign,
  Package,
  AlertTriangle,
  Clock,
  History,
  TrendingDown,
  CheckCircle2,
  Calendar,
} from 'lucide-react';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { StatCard } from '../../components/common/StatCard';
import { StatusBadge } from '../../components/common/Badge';
import { EmptyState, LoadingSpinner } from '../../components/common/EmptyState';
import { PrintPreviewModal } from '../../print/PrintPreviewModal';
import { ReceiptPrint } from '../../print/ReceiptPrint';
import { generateReceiptPDF } from '../../print/pdfGenerator';
import { getNextReceiptNumber } from '../../services/counterService';
import { logActivity } from '../../services/auditService';
import type {
  PharmacySale,
  PharmacySaleItem,
  Medicine,
  MedicineBatch,
  Patient,
  PaymentMethod,
} from '../../types';

export const PharmacyPOSPage: React.FC = () => {
  const { settings, formatCurrency, formatDate } = useClinic();
  const { user } = useAuth();
  const { success, error, warning } = useToast();

  const [activeTab, setActiveTab] = useState<'pos' | 'history' | 'batches' | 'purchases'>('pos');
  const [loading, setLoading] = useState(false);

  // POS State
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [batches, setBatches] = useState<MedicineBatch[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);

  // Current Cart
  const [cartItems, setCartItems] = useState<
    (PharmacySaleItem & { maxStock: number; unitPrice: number })[]
  >([]);
  const [selectedPatientId, setSelectedPatientId] = useState<number | ''>('');
  const [customerName, setCustomerName] = useState('Walk-in Customer');
  const [customerPhone, setCustomerPhone] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [taxPercent, setTaxPercent] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');

  // Sales History State
  const [salesHistory, setSalesHistory] = useState<PharmacySale[]>([]);
  const [searchHistory, setSearchHistory] = useState('');

  // Print Preview
  const [isPrintOpen, setIsPrintOpen] = useState(false);
  const [printingSale, setPrintingSale] = useState<PharmacySale | null>(null);

  // New Purchase / Stock-in Form state
  const [selectedMedForStock, setSelectedMedForStock] = useState<number | ''>('');
  const [purchaseBatchNumber, setPurchaseBatchNumber] = useState('');
  const [purchaseExpiryDate, setPurchaseExpiryDate] = useState('');
  const [purchaseQuantity, setPurchaseQuantity] = useState<number>(100);
  const [purchaseCostPrice, setPurchaseCostPrice] = useState<number>(0);
  const [purchaseSellingPrice, setPurchaseSellingPrice] = useState<number>(0);
  const [supplierName, setSupplierName] = useState('');

  const loadData = async () => {
    setLoading(true);
    try {
      const allMeds = await db.medicines.toArray();
      setMedicines(allMeds);
      const allBatches = await db.medicine_batches.toArray();
      setBatches(allBatches);
      const allPatients = await db.patients.toArray();
      setPatients(allPatients);
      const sales = await db.pharmacy_sales.reverse().sortBy('date');
      setSalesHistory(sales);
    } catch (err) {
      console.error(err);
      error('Failed to load pharmacy data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handlePatientChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const pId = e.target.value ? Number(e.target.value) : '';
    setSelectedPatientId(pId);
    if (pId) {
      const p = patients.find((pat) => pat.id === pId);
      if (p) {
        setCustomerName(p.name);
        setCustomerPhone(p.phone || '');
      }
    } else {
      setCustomerName('Walk-in Customer');
      setCustomerPhone('');
    }
  };

  const handleAddMedicineToCart = (medicineId: number) => {
    const med = medicines.find((m) => m.id === medicineId);
    if (!med) return;

    // Find active non-expired batch with stock
    const availableBatches = batches.filter(
      (b) => b.medicineId === medicineId && b.quantity > 0
    );

    if (availableBatches.length === 0 && med.stockQuantity <= 0) {
      warning(`No available stock for ${med.name}`);
      return;
    }

    const bestBatch = availableBatches[0];
    const unitPrice = bestBatch?.sellingPrice || med.unitPrice || 0;
    const batchNo = bestBatch?.batchNumber || 'GEN-01';
    const expiry = bestBatch?.expiryDate || 'N/A';
    const maxStock = bestBatch?.quantity || med.stockQuantity || 999;

    // Check if already in cart
    const existingIndex = cartItems.findIndex((ci) => ci.medicineId === medicineId);
    if (existingIndex >= 0) {
      const updated = [...cartItems];
      if (updated[existingIndex].quantity < maxStock) {
        updated[existingIndex].quantity += 1;
        updated[existingIndex].total = updated[existingIndex].quantity * updated[existingIndex].unitPrice;
        setCartItems(updated);
      } else {
        warning(`Maximum available stock reached for ${med.name}`);
      }
    } else {
      setCartItems((prev) => [
        ...prev,
        {
          medicineId: med.id!,
          medicineName: med.name,
          batchNumber: batchNo,
          expiryDate: expiry,
          quantity: 1,
          unitPrice,
          total: unitPrice,
          maxStock,
        },
      ]);
    }
  };

  const handleUpdateCartQty = (index: number, qty: number) => {
    if (qty <= 0) return;
    setCartItems((prev) => {
      const updated = [...prev];
      const max = updated[index].maxStock;
      const actualQty = Math.min(qty, max);
      updated[index].quantity = actualQty;
      updated[index].total = actualQty * updated[index].unitPrice;
      return updated;
    });
  };

  const handleRemoveFromCart = (index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
  };

  // Calculations
  const subtotal = cartItems.reduce((sum, item) => sum + item.total, 0);
  const discountAmount = Math.round((subtotal * discountPercent) / 100);
  const taxAmount = Math.round(((subtotal - discountAmount) * taxPercent) / 100);
  const grandTotal = Math.max(0, subtotal - discountAmount + taxAmount);

  // Complete POS Sale with Dexie transaction
  const handleCompleteSale = async () => {
    if (cartItems.length === 0) {
      error('Please add items to cart');
      return;
    }

    setLoading(true);
    try {
      const receiptNo = await getNextReceiptNumber();
      const now = new Date();
      const dateStr = now.toISOString().split('T')[0];
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      await db.transaction(
        'rw',
        [db.pharmacy_sales, db.medicines, db.medicine_batches, db.stock_movements, db.counters],
        async () => {
          // 1. Create Pharmacy Sale record
          const saleRecord: PharmacySale = {
            receiptNumber: receiptNo,
            patientId: typeof selectedPatientId === 'number' ? selectedPatientId : undefined,
            customerName: customerName.trim(),
            customerPhone: customerPhone.trim(),
            date: dateStr,
            time: timeStr,
            items: cartItems.map((ci) => ({
              medicineId: ci.medicineId,
              medicineName: ci.medicineName,
              batchNumber: ci.batchNumber,
              expiryDate: ci.expiryDate,
              quantity: ci.quantity,
              unitPrice: ci.unitPrice,
              total: ci.total,
            })),
            subtotal,
            discount: discountAmount,
            tax: taxAmount,
            grandTotal,
            paymentMethod,
          };

          const saleId = await db.pharmacy_sales.add(saleRecord);
          saleRecord.id = Number(saleId);

          // 2. Deduct stock from medicines and batches, record movements
          for (const item of cartItems) {
            // Deduct main medicine stock
            const med = await db.medicines.get(item.medicineId);
            if (med) {
              const newStock = Math.max(0, med.stockQuantity - item.quantity);
              await db.medicines.update(item.medicineId, { stockQuantity: newStock });
            }

            // Deduct batch stock
            const batch = await db.medicine_batches
              .where('medicineId')
              .equals(item.medicineId)
              .and((b) => b.batchNumber === item.batchNumber)
              .first();

            if (batch && batch.id) {
              const newBatchStock = Math.max(0, batch.quantity - item.quantity);
              await db.medicine_batches.update(batch.id, { quantity: newBatchStock });
            }

            // Record movement
            await db.stock_movements.add({
              medicineId: item.medicineId,
              medicineName: item.medicineName,
              batchNumber: item.batchNumber,
              type: 'sale',
              quantity: -item.quantity,
              date: dateStr,
              reference: receiptNo,
              notes: `POS Counter Sale to ${customerName}`,
            });
          }

          setPrintingSale(saleRecord);
        }
      );

      await logActivity(
        user?.name || 'User',
        user?.role || 'pharmacist',
        'PHARMACY_SALE',
        'pharmacy',
        `Completed pharmacy sale #${receiptNo} (${formatCurrency(grandTotal)})`
      );

      success(`Sale completed! Receipt #${receiptNo}`);
      setCartItems([]);
      setSelectedPatientId('');
      setCustomerName('Walk-in Customer');
      setCustomerPhone('');
      setDiscountPercent(0);
      setIsPrintOpen(true);
      loadData();
    } catch (err) {
      console.error(err);
      error('Failed to complete transaction');
    } finally {
      setLoading(false);
    }
  };

  // Record Stock In / Purchase
  const handleAddStockIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMedForStock || purchaseQuantity <= 0) {
      error('Please select medicine and valid quantity');
      return;
    }

    const med = medicines.find((m) => m.id === selectedMedForStock);
    if (!med) return;

    try {
      const todayStr = new Date().toISOString().split('T')[0];
      const batchNo = purchaseBatchNumber.trim() || `BATCH-${Date.now().toString().slice(-4)}`;

      await db.transaction('rw', [db.medicines, db.medicine_batches, db.stock_movements], async () => {
        // Add batch record
        await db.medicine_batches.add({
          medicineId: Number(selectedMedForStock),
          batchNumber: batchNo,
          expiryDate: purchaseExpiryDate || '2028-12-31',
          purchasePrice: purchaseCostPrice || med.costPrice || 0,
          sellingPrice: purchaseSellingPrice || med.unitPrice || 0,
          quantity: purchaseQuantity,
        });

        // Update medicine stock
        await db.medicines.update(Number(selectedMedForStock), {
          stockQuantity: med.stockQuantity + purchaseQuantity,
          unitPrice: purchaseSellingPrice || med.unitPrice,
          costPrice: purchaseCostPrice || med.costPrice,
        });

        // Record movement
        await db.stock_movements.add({
          medicineId: Number(selectedMedForStock),
          medicineName: med.name,
          batchNumber: batchNo,
          type: 'purchase',
          quantity: purchaseQuantity,
          date: todayStr,
          reference: supplierName || 'Stock In',
          notes: `Added ${purchaseQuantity} units from ${supplierName || 'Supplier'}`,
        });
      });

      await logActivity(
        user?.name || 'User',
        user?.role || 'pharmacist',
        'STOCK_IN',
        'pharmacy',
        `Stock In: +${purchaseQuantity} units for ${med.name} (Batch ${batchNo})`
      );

      success(`Stock added for ${med.name}`);
      setSelectedMedForStock('');
      setPurchaseBatchNumber('');
      setPurchaseExpiryDate('');
      setPurchaseQuantity(100);
      setSupplierName('');
      loadData();
    } catch (err) {
      console.error(err);
      error('Failed to add stock');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Pharmacy & POS</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Counter medicine sales, stock replenishment, and thermal receipts
          </p>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl self-start sm:self-auto border border-slate-200">
          <button
            onClick={() => setActiveTab('pos')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              activeTab === 'pos'
                ? 'bg-white text-blue-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            POS Terminal
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              activeTab === 'history'
                ? 'bg-white text-blue-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Sales History
          </button>
          <button
            onClick={() => setActiveTab('purchases')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              activeTab === 'purchases'
                ? 'bg-white text-blue-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Stock In / Purchases
          </button>
        </div>
      </div>

      {/* POS TERMINAL TAB */}
      {activeTab === 'pos' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Product Selector */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
              <div className="relative mb-4">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Quick search medicines by name, generic or dosage form..."
                  className="w-full pl-9 pr-4 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-blue-500"
                  onChange={(e) => {
                    const q = e.target.value.toLowerCase();
                    if (!q) {
                      db.medicines.toArray().then(setMedicines);
                    } else {
                      db.medicines
                        .filter(
                          (m) =>
                            m.name.toLowerCase().includes(q) ||
                            (m.genericName && m.genericName.toLowerCase().includes(q))
                        )
                        .toArray()
                        .then(setMedicines);
                    }
                  }}
                />
              </div>

              {/* Medicine Grid Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[500px] overflow-y-auto pr-1">
                {medicines.map((m) => {
                  const isOutOfStock = m.stockQuantity <= 0;
                  return (
                    <div
                      key={m.id}
                      onClick={() => !isOutOfStock && handleAddMedicineToCart(m.id!)}
                      className={`p-3 rounded-xl border transition-all text-left flex flex-col justify-between ${
                        isOutOfStock
                          ? 'border-slate-200 bg-slate-50/70 opacity-60 cursor-not-allowed'
                          : 'border-slate-200 bg-white hover:border-blue-300 hover:shadow-sm cursor-pointer'
                      }`}
                    >
                      <div>
                        <div className="flex items-start justify-between gap-1">
                          <h4 className="font-semibold text-slate-900 text-sm">{m.name}</h4>
                          <span className="text-xs font-bold text-blue-600 shrink-0">
                            {formatCurrency(m.unitPrice)}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                          {m.dosageForm} {m.strength ? `• ${m.strength}` : ''}
                        </p>
                      </div>

                      <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-100 text-xs">
                        <span
                          className={`font-medium ${
                            isOutOfStock
                              ? 'text-rose-500'
                              : m.stockQuantity <= (m.minStockAlert || 10)
                              ? 'text-amber-600'
                              : 'text-slate-500'
                          }`}
                        >
                          {isOutOfStock
                            ? 'Out of Stock'
                            : `Stock: ${m.stockQuantity}`}
                        </span>
                        {!isOutOfStock && (
                          <span className="text-blue-600 font-semibold flex items-center gap-0.5">
                            <Plus className="w-3.5 h-3.5" /> Add
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right: Cart & Checkout */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs flex flex-col">
              <div className="p-4 border-b border-slate-200">
                <h3 className="font-bold text-slate-900 text-base flex items-center justify-between">
                  <span>Current Cart</span>
                  <span className="text-xs px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 font-semibold">
                    {cartItems.length} items
                  </span>
                </h3>

                {/* Customer / Patient Selection */}
                <div className="mt-3 space-y-2">
                  <select
                    value={selectedPatientId}
                    onChange={handlePatientChange}
                    className="w-full text-xs px-3 py-1.5 rounded-lg border border-slate-200 bg-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="">Walk-in Customer (Non-registered)</option>
                    {patients.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.patientCode})
                      </option>
                    ))}
                  </select>

                  {!selectedPatientId && (
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder="Customer Name"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-200"
                      />
                      <input
                        type="text"
                        placeholder="Phone No."
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-200"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Cart Items List */}
              <div className="p-4 flex-1 overflow-y-auto max-h-[260px] divide-y divide-slate-100">
                {cartItems.length === 0 ? (
                  <div className="py-8 text-center text-slate-400 text-xs">
                    Cart is empty. Select medicines from the left to add.
                  </div>
                ) : (
                  cartItems.map((item, idx) => (
                    <div key={idx} className="py-2.5 flex items-center justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold text-slate-900 truncate">
                          {item.medicineName}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          Batch: {item.batchNumber} • {formatCurrency(item.unitPrice)}/ea
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min="1"
                          max={item.maxStock}
                          value={item.quantity}
                          onChange={(e) => handleUpdateCartQty(idx, Number(e.target.value))}
                          className="w-14 px-1.5 py-1 text-center text-xs border border-slate-200 rounded-md focus:outline-none"
                        />
                        <span className="text-xs font-semibold text-slate-900 w-16 text-right">
                          {formatCurrency(item.total)}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleRemoveFromCart(idx)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Bill Summary & Payment */}
              <div className="p-4 bg-slate-50 border-t border-slate-200 rounded-b-2xl space-y-3">
                <div className="space-y-1.5 text-xs text-slate-600">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span className="font-medium text-slate-900">{formatCurrency(subtotal)}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Discount (%):</span>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={discountPercent}
                      onChange={(e) => setDiscountPercent(Number(e.target.value))}
                      className="w-16 px-1.5 py-0.5 text-right text-xs border border-slate-200 rounded bg-white"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <span>Tax / GST (%):</span>
                    <input
                      type="number"
                      min="0"
                      max="50"
                      value={taxPercent}
                      onChange={(e) => setTaxPercent(Number(e.target.value))}
                      className="w-16 px-1.5 py-0.5 text-right text-xs border border-slate-200 rounded bg-white"
                    />
                  </div>

                  <div className="flex justify-between text-sm font-bold text-slate-900 pt-2 border-t border-slate-200">
                    <span>Grand Total:</span>
                    <span className="text-blue-600 text-base">{formatCurrency(grandTotal)}</span>
                  </div>
                </div>

                {/* Payment Mode */}
                <div>
                  <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-1">
                    Payment Method
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {(['Cash', 'Card', 'UPI', 'Other'] as PaymentMethod[]).map((mode) => (
                      <button
                        key={mode}
                        type="button"
                        onClick={() => setPaymentMethod(mode)}
                        className={`py-1.5 text-xs font-medium rounded-lg border transition-all cursor-pointer ${
                          paymentMethod === mode
                            ? 'bg-blue-600 border-blue-600 text-white font-semibold'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {mode}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Checkout Button */}
                <button
                  type="button"
                  disabled={cartItems.length === 0 || loading}
                  onClick={handleCompleteSale}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm shadow-sm shadow-emerald-600/20 disabled:opacity-50 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  {loading ? 'Processing...' : `Complete & Print (${formatCurrency(grandTotal)})`}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SALES HISTORY TAB */}
      {activeTab === 'history' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by receipt # or customer..."
                value={searchHistory}
                onChange={(e) => setSearchHistory(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-semibold text-slate-500">
                <tr>
                  <th className="px-5 py-3.5">Receipt #</th>
                  <th className="px-4 py-3.5">Date & Time</th>
                  <th className="px-4 py-3.5">Customer</th>
                  <th className="px-4 py-3.5">Items</th>
                  <th className="px-4 py-3.5 text-right">Total</th>
                  <th className="px-4 py-3.5 text-center">Payment</th>
                  <th className="px-5 py-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {salesHistory
                  .filter(
                    (s) =>
                      s.receiptNumber.toLowerCase().includes(searchHistory.toLowerCase()) ||
                      s.customerName.toLowerCase().includes(searchHistory.toLowerCase())
                  )
                  .map((sale) => (
                    <tr key={sale.id} className="hover:bg-slate-50/80">
                      <td className="px-5 py-3.5 font-semibold text-blue-600">
                        {sale.receiptNumber}
                      </td>
                      <td className="px-4 py-3.5 text-xs text-slate-500">
                        {formatDate(sale.date)} {sale.time}
                      </td>
                      <td className="px-4 py-3.5 font-medium text-slate-900">
                        {sale.customerName}
                      </td>
                      <td className="px-4 py-3.5 text-xs text-slate-500">
                        {sale.items.length} medicines
                      </td>
                      <td className="px-4 py-3.5 text-right font-bold text-slate-900">
                        {formatCurrency(sale.grandTotal)}
                      </td>
                      <td className="px-4 py-3.5 text-center">
                        <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium">
                          {sale.paymentMethod}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <button
                          onClick={() => {
                            setPrintingSale(sale);
                            setIsPrintOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                          title="Reprint Receipt"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* STOCK IN / PURCHASES TAB */}
      {activeTab === 'purchases' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-6 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
            <h3 className="font-bold text-slate-900 text-base mb-4 flex items-center gap-2">
              <Package className="w-5 h-5 text-blue-600" />
              Record Supplier Stock In
            </h3>

            <form onSubmit={handleAddStockIn} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Medicine *
                </label>
                <select
                  value={selectedMedForStock}
                  onChange={(e) => setSelectedMedForStock(Number(e.target.value))}
                  required
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-none focus:border-blue-500"
                >
                  <option value="">Select Medicine to restock...</option>
                  {medicines.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} (Current stock: {m.stockQuantity})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                    Batch Number
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., B2401"
                    value={purchaseBatchNumber}
                    onChange={(e) => setPurchaseBatchNumber(e.target.value)}
                    className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                    Expiry Date
                  </label>
                  <input
                    type="date"
                    value={purchaseExpiryDate}
                    onChange={(e) => setPurchaseExpiryDate(e.target.value)}
                    className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                    Quantity *
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={purchaseQuantity}
                    onChange={(e) => setPurchaseQuantity(Number(e.target.value))}
                    required
                    className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                    Cost Price
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={purchaseCostPrice}
                    onChange={(e) => setPurchaseCostPrice(Number(e.target.value))}
                    className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                    Selling Price
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={purchaseSellingPrice}
                    onChange={(e) => setPurchaseSellingPrice(Number(e.target.value))}
                    className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Supplier / Vendor Name
                </label>
                <input
                  type="text"
                  placeholder="e.g., MedSupply Pharma Ltd."
                  value={supplierName}
                  onChange={(e) => setSupplierName(e.target.value)}
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm transition-all cursor-pointer shadow-sm shadow-blue-500/20"
              >
                Add Stock to Inventory
              </button>
            </form>
          </div>

          <div className="md:col-span-6 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
            <h3 className="font-bold text-slate-900 text-base mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-500" />
              Current Medicine Batches & Expiry
            </h3>

            <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {batches.map((b) => (
                <div
                  key={b.id}
                  className="p-3 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between text-xs"
                >
                  <div>
                    <span className="font-semibold text-slate-900">
                      {medicines.find((m) => m.id === b.medicineId)?.name || 'Medicine'}
                    </span>
                    <p className="text-[11px] text-slate-500">
                      Batch #{b.batchNumber} • Exp: {formatDate(b.expiryDate)}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="font-bold text-slate-900">{b.quantity} in stock</span>
                    <p className="text-[10px] text-emerald-600">
                      Sell: {formatCurrency(b.sellingPrice)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Print Thermal Receipt Modal */}
      {isPrintOpen && printingSale && (
        <PrintPreviewModal
          isOpen={isPrintOpen}
          onClose={() => {
            setIsPrintOpen(false);
            setPrintingSale(null);
          }}
          title={`Pharmacy Receipt ${printingSale.receiptNumber}`}
          paperSize="thermal"
          onGeneratePdf={() => generateReceiptPDF(printingSale, settings)}
        >
          <ReceiptPrint sale={printingSale} settings={settings} />
        </PrintPreviewModal>
      )}
    </div>
  );
};
