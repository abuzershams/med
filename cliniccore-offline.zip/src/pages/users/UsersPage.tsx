import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Plus,
  Edit,
  Trash2,
  KeyRound,
  UserCheck,
  UserX,
  Lock,
  Search,
} from 'lucide-react';
import bcrypt from 'bcryptjs';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { logActivity } from '../../services/auditService';
import type { User, UserRole } from '../../types';

export const UsersPage: React.FC = () => {
  const { user: currentUser } = useAuth();
  const { success, error, warning } = useToast();

  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  // New / Edit User Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('receptionist');
  const [phone, setPhone] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  // Reset Password Modal
  const [isResetOpen, setIsResetOpen] = useState(false);
  const [userToReset, setUserToReset] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState('');

  // Delete User
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const all = await db.users.toArray();
      setUsers(all);
    } catch (err) {
      console.error(err);
      error('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleOpenAdd = () => {
    setEditingUser(null);
    setName('');
    setUsername('');
    setPassword('');
    setRole('receptionist');
    setPhone('');
    setStatus('active');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (u: User) => {
    setEditingUser(u);
    setName(u.name);
    setUsername(u.username);
    setPassword('');
    setRole(u.role);
    setPhone(u.phone || '');
    setStatus(u.status);
    setIsModalOpen(true);
  };

  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !username.trim()) {
      error('Please enter name and username');
      return;
    }

    try {
      const cleanUsername = username.trim().toLowerCase();

      // Check username uniqueness
      const existing = await db.users.where('username').equals(cleanUsername).first();
      if (existing && existing.id !== editingUser?.id) {
        error('Username already taken. Please choose another.');
        return;
      }

      if (editingUser?.id) {
        // Update user
        const updateData: Partial<User> = {
          name: name.trim(),
          username: cleanUsername,
          role,
          phone: phone.trim(),
          status,
        };

        if (password.trim()) {
          if (password.length < 6) {
            error('Password must be at least 6 characters');
            return;
          }
          updateData.passwordHash = await bcrypt.hash(password, 10);
        }

        await db.users.update(editingUser.id, updateData);
        await logActivity(
          currentUser?.name || 'Admin',
          currentUser?.role || 'admin',
          'UPDATE_USER',
          'users',
          `Updated user account for ${name.trim()} (${role})`
        );
        success('User account updated');
      } else {
        // Create new user
        if (!password.trim() || password.length < 6) {
          error('Password must be at least 6 characters');
          return;
        }

        const passwordHash = await bcrypt.hash(password, 10);
        await db.users.add({
          name: name.trim(),
          username: cleanUsername,
          passwordHash,
          role,
          phone: phone.trim(),
          status,
          createdAt: new Date().toISOString(),
        });

        await logActivity(
          currentUser?.name || 'Admin',
          currentUser?.role || 'admin',
          'CREATE_USER',
          'users',
          `Created new ${role} account: ${cleanUsername}`
        );
        success('User created successfully');
      }

      setIsModalOpen(false);
      loadUsers();
    } catch (err) {
      console.error(err);
      error('Failed to save user');
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userToReset || !userToReset.id || newPassword.length < 6) {
      error('New password must be at least 6 characters');
      return;
    }

    try {
      const passwordHash = await bcrypt.hash(newPassword, 10);
      await db.users.update(userToReset.id, { passwordHash });
      await logActivity(
        currentUser?.name || 'Admin',
        currentUser?.role || 'admin',
        'RESET_PASSWORD',
        'users',
        `Reset password for user: ${userToReset.username}`
      );

      success(`Password reset for ${userToReset.name}`);
      setIsResetOpen(false);
      setUserToReset(null);
      setNewPassword('');
    } catch (err) {
      console.error(err);
      error('Failed to reset password');
    }
  };

  const handleDeleteUser = async () => {
    if (!userToDelete || !userToDelete.id) return;
    if (userToDelete.id === currentUser?.id) {
      error('You cannot delete your own account while logged in');
      return;
    }

    try {
      await db.users.delete(userToDelete.id);
      await logActivity(
        currentUser?.name || 'Admin',
        currentUser?.role || 'admin',
        'DELETE_USER',
        'users',
        `Deleted user account: ${userToDelete.username}`
      );
      success('User account deleted');
      setUserToDelete(null);
      loadUsers();
    } catch (err) {
      console.error(err);
      error('Failed to delete user');
    }
  };

  const permissionsMatrix = [
    { module: 'Dashboard', admin: true, doctor: true, receptionist: true, pharmacist: true, staff: true },
    { module: 'Patients', admin: true, doctor: true, receptionist: true, pharmacist: false, staff: true },
    { module: 'Appointments', admin: true, doctor: true, receptionist: true, pharmacist: false, staff: true },
    { module: 'Doctors', admin: true, doctor: true, receptionist: true, pharmacist: false, staff: false },
    { module: 'Prescriptions', admin: true, doctor: true, receptionist: false, pharmacist: true, staff: false },
    { module: 'Medicine Master', admin: true, doctor: true, receptionist: false, pharmacist: true, staff: false },
    { module: 'Pharmacy & POS', admin: true, doctor: false, receptionist: false, pharmacist: true, staff: false },
    { module: 'Billing & Invoices', admin: true, doctor: false, receptionist: true, pharmacist: false, staff: false },
    { module: 'Finance & Payroll', admin: true, doctor: false, receptionist: false, pharmacist: false, staff: false },
    { module: 'Follow-ups', admin: true, doctor: true, receptionist: true, pharmacist: false, staff: false },
    { module: 'Staff Attendance', admin: true, doctor: false, receptionist: true, pharmacist: false, staff: true },
    { module: 'Reports', admin: true, doctor: true, receptionist: false, pharmacist: false, staff: false },
    { module: 'User Management', admin: true, doctor: false, receptionist: false, pharmacist: false, staff: false },
    { module: 'Settings & Backup', admin: true, doctor: false, receptionist: false, pharmacist: false, staff: false },
  ];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">User Management</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Manage staff accounts, assign roles, and audit access permissions
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm shadow-sm shadow-blue-500/20 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add User
        </button>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-base">Active Clinic Accounts</h3>
          <span className="text-xs text-slate-500">{users.length} registered accounts</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-semibold text-slate-500">
              <tr>
                <th className="px-5 py-3.5">Full Name</th>
                <th className="px-4 py-3.5">Username</th>
                <th className="px-4 py-3.5">Assigned Role</th>
                <th className="px-4 py-3.5">Phone</th>
                <th className="px-4 py-3.5 text-center">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/80">
                  <td className="px-5 py-3.5 font-semibold text-slate-900">
                    {u.name}
                    {u.id === currentUser?.id && (
                      <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded-md bg-blue-50 text-blue-600 font-bold">
                        You
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3.5 font-mono text-xs text-slate-600">
                    @{u.username}
                  </td>
                  <td className="px-4 py-3.5">
                    <span className="px-2.5 py-1 rounded-full text-xs font-semibold capitalize bg-slate-100 text-slate-700">
                      {u.role}
                    </span>
                  </td>
                  <td className="px-4 py-3.5 text-slate-500 text-xs">
                    {u.phone || '—'}
                  </td>
                  <td className="px-4 py-3.5 text-center">
                    <span
                      className={`inline-flex items-center gap-1 text-xs px-2.5 py-0.5 rounded-full font-semibold capitalize ${
                        u.status === 'active'
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-rose-50 text-rose-700'
                      }`}
                    >
                      {u.status}
                    </span>
                  </td>
                  <td className="px-5 py-3.5 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => {
                          setUserToReset(u);
                          setNewPassword('');
                          setIsResetOpen(true);
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                        title="Reset Password"
                      >
                        <KeyRound className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleOpenEdit(u)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                        title="Edit Account"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      {u.id !== currentUser?.id && (
                        <button
                          onClick={() => setUserToDelete(u)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Delete Account"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Roles & Permissions Matrix Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200">
          <h3 className="font-bold text-slate-900 text-base">Roles & Permissions Matrix</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Overview of access privileges configured for each system role
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200 font-semibold uppercase text-slate-500">
              <tr>
                <th className="px-5 py-3">Module</th>
                <th className="px-4 py-3 text-center">Admin</th>
                <th className="px-4 py-3 text-center">Doctor</th>
                <th className="px-4 py-3 text-center">Receptionist</th>
                <th className="px-4 py-3 text-center">Pharmacist</th>
                <th className="px-4 py-3 text-center">Staff</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {permissionsMatrix.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50">
                  <td className="px-5 py-2.5 font-semibold text-slate-900">{row.module}</td>
                  {(['admin', 'doctor', 'receptionist', 'pharmacist', 'staff'] as const).map(
                    (r) => (
                      <td key={r} className="px-4 py-2.5 text-center">
                        {row[r] ? (
                          <span className="inline-block w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 font-bold leading-4">
                            ✓
                          </span>
                        ) : (
                          <span className="text-slate-300">—</span>
                        )}
                      </td>
                    )
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit User Modal */}
      {isModalOpen && (
        <Modal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          title={editingUser ? 'Edit User Account' : 'Create Clinic User'}
          subtitle="Define user credentials, staff role, and system access"
          maxWidth="md"
        >
          <form onSubmit={handleSaveUser} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Full Name *
              </label>
              <input
                type="text"
                placeholder="e.g., Rajesh Kumar"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Username *
                </label>
                <input
                  type="text"
                  placeholder="e.g., rajesh"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  placeholder="e.g., 9876543210"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Role *
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white capitalize"
                >
                  <option value="admin">Admin (Full Access)</option>
                  <option value="doctor">Doctor</option>
                  <option value="receptionist">Receptionist</option>
                  <option value="pharmacist">Pharmacist</option>
                  <option value="staff">Staff / Assistant</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Account Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive / Suspended</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                {editingUser ? 'New Password (Leave blank to keep unchanged)' : 'Password *'}
              </label>
              <input
                type="password"
                placeholder={editingUser ? '••••••••' : 'Min. 6 characters'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required={!editingUser}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium shadow-sm shadow-blue-500/20 cursor-pointer"
              >
                {editingUser ? 'Update Account' : 'Create Account'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Reset Password Modal */}
      {isResetOpen && (
        <Modal
          isOpen={isResetOpen}
          onClose={() => setIsResetOpen(false)}
          title={`Reset Password: ${userToReset?.name}`}
          subtitle="Set a new offline password for this user"
          maxWidth="sm"
        >
          <form onSubmit={handleResetPassword} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                New Password *
              </label>
              <input
                type="password"
                placeholder="Min 6 characters"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsResetOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium shadow-sm shadow-blue-500/20 cursor-pointer"
              >
                Reset Password
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Delete User Confirm */}
      <ConfirmDialog
        isOpen={!!userToDelete}
        title="Delete User Account"
        message={`Are you sure you want to delete the user account for "${userToDelete?.name}" (@${userToDelete?.username})?`}
        confirmLabel="Delete User"
        variant="danger"
        onConfirm={handleDeleteUser}
        onCancel={() => setUserToDelete(null)}
      />
    </div>
  );
};
