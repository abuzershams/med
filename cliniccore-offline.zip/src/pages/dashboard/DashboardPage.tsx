import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  Calendar,
  DollarSign,
  AlertTriangle,
  Receipt,
  FileText,
  Pill,
  HeartPulse,
  Clock,
  Plus,
  ShieldAlert,
  ArrowRight,
  TrendingUp,
  CheckCircle2,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useAuth } from '../../context/AuthContext';
import { StatCard } from '../../components/common/StatCard';
import { Badge, StatusBadge } from '../../components/common/Badge';
import { isBackupOverdue } from '../../services/backupService';
import { PatientModal } from '../patients/PatientModal';
import { AppointmentModal } from '../appointments/AppointmentModal';
import type { Appointment, FollowUp, MedicineBatch } from '../../types';

export const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { settings, formatCurrency, formatDate } = useClinic();
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [totalPatients, setTotalPatients] = useState(0);
  const [todayApptsCount, setTodayApptsCount] = useState(0);
  const [revenueCollected, setRevenueCollected] = useState(0);
  const [todayCollection, setTodayCollection] = useState(0);
  const [outstandingDues, setOutstandingDues] = useState(0);
  const [pendingInvoicesCount, setPendingInvoicesCount] = useState(0);
  const [prescriptionsCount, setPrescriptionsCount] = useState(0);
  const [lowStockCount, setLowStockCount] = useState(0);
  const [upcomingFollowupsCount, setUpcomingFollowupsCount] = useState(0);

  const [todaySchedule, setTodaySchedule] = useState<Appointment[]>([]);
  const [pendingFollowups, setPendingFollowups] = useState<FollowUp[]>([]);
  const [stockAlerts, setStockAlerts] = useState<(MedicineBatch & { statusType: 'LOW' | 'EXPIRED' })[]>([]);

  const [apptChartData, setApptChartData] = useState<{ day: string; count: number }[]>([]);
  const [invoicePieData, setInvoicePieData] = useState<{ name: string; value: number; color: string }[]>([]);

  // Modals for instant dashboard actions
  const [isPatientModalOpen, setIsPatientModalOpen] = useState(false);
  const [isApptModalOpen, setIsApptModalOpen] = useState(false);

  const fetchDashboardMetrics = async () => {
      setLoading(true);
      try {
        const todayStr = new Date().toISOString().split('T')[0];

        // 1. Patients
        const patientCount = await db.patients.count();
        setTotalPatients(patientCount);

        // 2. Appointments
        const todayAppts = await db.appointments.where('date').equals(todayStr).toArray();
        setTodayApptsCount(todayAppts.length);
        setTodaySchedule(todayAppts.sort((a, b) => a.time.localeCompare(b.time)));

        // 3. Billing & Revenue
        const allInvoices = await db.invoices.toArray();
        let totalRev = 0;
        let totalDues = 0;
        let pendingCount = 0;
        let paidCount = 0;
        let partialCount = 0;

        allInvoices.forEach((inv) => {
          totalRev += inv.amountPaid || 0;
          totalDues += inv.balanceDue || 0;
          if (inv.status === 'Pending') pendingCount++;
          else if (inv.status === 'Partial') partialCount++;
          else if (inv.status === 'Paid') paidCount++;
        });

        setRevenueCollected(totalRev);
        setOutstandingDues(totalDues);
        setPendingInvoicesCount(pendingCount + partialCount);

        // Today's Payments Collection
        const allPayments = await db.payments.toArray();
        const todayPayments = allPayments.filter((p) => p.date === todayStr);
        const todayCol = todayPayments.reduce((sum, p) => sum + p.amount, 0);
        setTodayCollection(todayCol);

        // 4. Prescriptions
        const rxCount = await db.prescriptions.count();
        setPrescriptionsCount(rxCount);

        // 5. Stock & Expiry Alerts
        const lowThreshold = settings?.lowStockThreshold || 15;
        const allBatches = await db.medicine_batches.toArray();
        const alerts: (MedicineBatch & { statusType: 'LOW' | 'EXPIRED' })[] = [];

        allBatches.forEach((b) => {
          const isExpired = b.expiryDate <= todayStr;
          const isLow = b.currentStock <= lowThreshold;
          if (isExpired) {
            alerts.push({ ...b, statusType: 'EXPIRED' });
          } else if (isLow) {
            alerts.push({ ...b, statusType: 'LOW' });
          }
        });

        setLowStockCount(alerts.length);
        setStockAlerts(alerts.slice(0, 5));

        // 6. Follow-ups Due
        const allFollowups = await db.follow_ups.where('isDone').equals(0 as any).toArray();
        const activeFollowups = allFollowups.filter((f) => !f.isDone);
        setUpcomingFollowupsCount(activeFollowups.length);
        setPendingFollowups(activeFollowups.slice(0, 5));

        // 7. Last 7 Days Appointments Trend Chart
        const past7Days: { day: string; count: number }[] = [];
        const allAppointments = await db.appointments.toArray();
        for (let i = 6; i >= 0; i--) {
          const d = new Date();
          d.setDate(d.getDate() - i);
          const dStr = d.toISOString().split('T')[0];
          const label = d.toLocaleDateString('en-US', { weekday: 'short', month: 'numeric', day: 'numeric' });
          const count = allAppointments.filter((a) => a.date === dStr).length;
          past7Days.push({ day: label, count });
        }
        setApptChartData(past7Days);

        // 8. Invoice Status Donut Data
        setInvoicePieData([
          { name: 'Paid', value: paidCount, color: '#10b981' }, // Emerald
          { name: 'Partial', value: partialCount, color: '#f59e0b' }, // Amber
          { name: 'Pending', value: pendingCount, color: '#ef4444' }, // Red
        ]);
      } catch (err) {
        console.error('Dashboard load error:', err);
      } finally {
        setLoading(false);
      }
  };

  useEffect(() => {
    fetchDashboardMetrics();
  }, [settings]);

  const backupOverdue = isBackupOverdue(settings?.lastBackupDate);

  return (
    <div className="space-y-6">
      {/* Top Banner & Greetings */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Clinical Overview</h1>
          <p className="text-xs text-slate-500 mt-1">
            Welcome back, <span className="font-semibold text-slate-700">{user?.name}</span> • Practice summary as of{' '}
            {new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
          </p>
        </div>

        {/* Quick Actions Bar */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsPatientModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-2xs hover:shadow-xs transition-all active:scale-[0.98] min-h-[38px]"
          >
            <Plus className="w-3.5 h-3.5 text-blue-600" />
            New Patient
          </button>
          <button
            onClick={() => setIsApptModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-2xs hover:shadow-xs transition-all active:scale-[0.98] min-h-[38px]"
          >
            <Calendar className="w-3.5 h-3.5 text-emerald-600" />
            Book Appt
          </button>
          <button
            onClick={() => navigate('/prescriptions/new')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-2xs hover:shadow-xs transition-all active:scale-[0.98] min-h-[38px]"
          >
            <FileText className="w-3.5 h-3.5 text-purple-600" />
            Prescribe
          </button>
          <button
            onClick={() => navigate('/invoices')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-2xs hover:shadow-xs transition-all active:scale-[0.98] min-h-[38px]"
          >
            <Receipt className="w-3.5 h-3.5 text-amber-600" />
            Invoice
          </button>
          <button
            onClick={() => navigate('/pharmacy')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 active:bg-blue-800 shadow-xs transition-all min-h-[38px]"
          >
            <Pill className="w-3.5 h-3.5" />
            Pharmacy POS
          </button>
        </div>
      </div>

      {/* Backup Overdue Warning Banner */}
      {backupOverdue && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 flex items-start justify-between gap-4 shadow-xs">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-sm text-rose-950">Database Backup Recommended</p>
              <p className="text-xs text-rose-700 mt-0.5">
                {settings?.lastBackupDate
                  ? `Your last backup was on ${formatDate(settings.lastBackupDate)}. Because this app runs 100% offline, please download a weekly backup to protect your clinical records.`
                  : 'You have not exported an offline backup yet. Regular backups ensure safe medical and billing data.'}
              </p>
            </div>
          </div>
          <button
            onClick={() => navigate('/settings')}
            className="shrink-0 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
          >
            Export Backup Now
          </button>
        </div>
      )}

      {/* Main 8 Key Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Registered Patients"
          value={totalPatients}
          subtitle="Lifetime patient directory"
          icon={Users}
          colorScheme="blue"
          onClick={() => navigate('/patients')}
        />
        <StatCard
          title="Today's Appointments"
          value={todayApptsCount}
          subtitle="Scheduled visits today"
          icon={Calendar}
          colorScheme="emerald"
          onClick={() => navigate('/appointments')}
        />
        <StatCard
          title="Today's Collection"
          value={formatCurrency(todayCollection)}
          subtitle="Payments received today"
          icon={TrendingUp}
          colorScheme="teal"
          onClick={() => navigate('/invoices')}
        />
        <StatCard
          title="Total Revenue Collected"
          value={formatCurrency(revenueCollected)}
          subtitle="Across all settled bills"
          icon={DollarSign}
          colorScheme="purple"
          onClick={() => navigate('/invoices')}
        />
        <StatCard
          title="Outstanding Patient Dues"
          value={formatCurrency(outstandingDues)}
          subtitle={`${pendingInvoicesCount} invoices pending/partial`}
          icon={Receipt}
          colorScheme={outstandingDues > 0 ? 'rose' : 'emerald'}
          onClick={() => navigate('/invoices')}
        />
        <StatCard
          title="Prescriptions Issued"
          value={prescriptionsCount}
          subtitle="Digital prescriptions created"
          icon={FileText}
          colorScheme="blue"
          onClick={() => navigate('/prescriptions')}
        />
        <StatCard
          title="Inventory Alerts"
          value={lowStockCount}
          subtitle="Low stock or expired batches"
          icon={AlertTriangle}
          colorScheme={lowStockCount > 0 ? 'amber' : 'emerald'}
          onClick={() => navigate('/pharmacy')}
        />
        <StatCard
          title="Upcoming Follow-ups"
          value={upcomingFollowupsCount}
          subtitle="Patient follow-up visits"
          icon={HeartPulse}
          colorScheme="teal"
          onClick={() => navigate('/followups')}
        />
      </div>

      {/* Charts Section: 7-Day Appointments Trend & Invoice Status Donut */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 7-Day Appointments Line Chart */}
        <div className="lg:col-span-2 p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">7-Day Appointments Volume</h2>
              <p className="text-xs text-slate-500">Patient consultations and bookings trend</p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 bg-blue-50 text-blue-700 rounded-full border border-blue-200">
              Last 7 Days
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={apptChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '12px',
                    color: '#f8fafc',
                    fontSize: '12px',
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="count"
                  name="Appointments"
                  stroke="#2563eb"
                  strokeWidth={3}
                  dot={{ r: 4, fill: '#2563eb' }}
                  activeDot={{ r: 6, fill: '#1d4ed8' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Invoice Status Donut Chart */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col">
          <div className="mb-2">
            <h2 className="text-base font-bold text-slate-900">Invoice Status Distribution</h2>
            <p className="text-xs text-slate-500">Breakdown of billing settlement</p>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            {invoicePieData.every((d) => d.value === 0) ? (
              <div className="text-center text-xs text-slate-400">
                No invoices issued yet.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={invoicePieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {invoicePieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#1e293b',
                      borderRadius: '12px',
                      color: '#f8fafc',
                      fontSize: '12px',
                    }}
                  />
                  <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: '11px' }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* Lower Grid: Today's Schedule + Follow-ups + Low Stock Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Schedule */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-600" />
                Today's Schedule ({todaySchedule.length})
              </h3>
              <p className="text-[11px] text-slate-400">Ordered by token time</p>
            </div>
            <button
              onClick={() => navigate('/appointments')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 transition-colors"
            >
              View all
            </button>
          </div>

          <div className="space-y-3 flex-1 overflow-y-auto max-h-80">
            {todaySchedule.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-8">No appointments scheduled for today.</p>
            ) : (
              todaySchedule.map((appt) => (
                <div
                  key={appt.id}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs shrink-0">
                      #{appt.tokenNumber}
                    </span>
                    <div>
                      <p className="font-bold text-slate-900">{appt.patientName}</p>
                      <p className="text-[11px] text-slate-500">
                        {appt.time} • {appt.doctorName}
                      </p>
                    </div>
                  </div>
                  <StatusBadge status={appt.status} />
                </div>
              ))
            )}
          </div>
        </div>

        {/* Pending Follow-ups */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <HeartPulse className="w-4 h-4 text-pink-600" />
                Follow-ups Due ({pendingFollowups.length})
              </h3>
              <p className="text-[11px] text-slate-400">Patients due for clinical review</p>
            </div>
            <button
              onClick={() => navigate('/followups')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 transition-colors"
            >
              View all
            </button>
          </div>

          <div className="space-y-3 flex-1 overflow-y-auto max-h-80">
            {pendingFollowups.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-8">No pending follow-ups due.</p>
            ) : (
              pendingFollowups.map((f) => (
                <div
                  key={f.id}
                  className="p-3 rounded-xl bg-pink-50/50 border border-pink-200/80 flex items-center justify-between gap-2 text-xs"
                >
                  <div>
                    <p className="font-bold text-slate-900">{f.patientName}</p>
                    <p className="text-[11px] text-slate-600 italic truncate max-w-[180px]">{f.reason}</p>
                    <p className="text-[10px] text-pink-700 font-semibold mt-0.5">Due: {formatDate(f.followUpDate)}</p>
                  </div>
                  <button
                    onClick={() => navigate('/followups')}
                    className="px-2.5 py-1 text-[11px] font-semibold text-pink-700 bg-pink-100 hover:bg-pink-200 rounded-lg transition-colors"
                  >
                    Action
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Low Stock & Expiry Alerts */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                Pharmacy Alerts ({stockAlerts.length})
              </h3>
              <p className="text-[11px] text-slate-400">Low stock & expiring medicines</p>
            </div>
            <button
              onClick={() => navigate('/pharmacy')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 transition-colors"
            >
              Inventory
            </button>
          </div>

          <div className="space-y-3 flex-1 overflow-y-auto max-h-80">
            {stockAlerts.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-8">All medicines are adequately stocked!</p>
            ) : (
              stockAlerts.map((b) => (
                <div
                  key={b.id}
                  className="p-3 rounded-xl bg-amber-50/60 border border-amber-200/80 flex items-center justify-between gap-2 text-xs"
                >
                  <div>
                    <p className="font-bold text-slate-900">{b.medicineName}</p>
                    <p className="text-[11px] text-slate-600">Batch: {b.batchNumber} • Stock: <span className="font-bold text-slate-900">{b.currentStock} {b.unit}</span></p>
                  </div>
                  <Badge variant={b.statusType === 'EXPIRED' ? 'danger' : 'warning'}>
                    {b.statusType === 'EXPIRED' ? 'Expired' : 'Low Stock'}
                  </Badge>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Patient Register Modal */}
      <PatientModal
        isOpen={isPatientModalOpen}
        onClose={() => setIsPatientModalOpen(false)}
        onSaved={fetchDashboardMetrics}
      />

      {/* Appointment Booking Modal */}
      <AppointmentModal
        isOpen={isApptModalOpen}
        onClose={() => setIsApptModalOpen(false)}
        onSaved={fetchDashboardMetrics}
      />
    </div>
  );
};
