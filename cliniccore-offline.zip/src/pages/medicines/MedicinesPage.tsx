import React, { useState, useEffect, useMemo } from 'react';
import {
  Pill,
  Plus,
  Search,
  Star,
  StarOff,
  Edit,
  Trash2,
  Filter,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { logActivity } from '../../services/auditService';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { Pagination } from '../../components/common/Pagination';
import { Badge } from '../../components/common/Badge';
import { EmptyState, LoadingSpinner } from '../../components/common/EmptyState';
import type { Medicine } from '../../types';

const MEDICINE_FORMS = [
  'Tablet',
  'Capsule',
  'Syrup',
  'Injection',
  'Drops',
  'Cream',
  'Ointment',
  'Inhaler',
  'Suspension',
  'Other',
];

export const MedicinesPage: React.FC = () => {
  const { user, checkPermission } = useAuth();
  const { success, error } = useToast();

  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [formFilter, setFormFilter] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [medicineToEdit, setMedicineToEdit] = useState<Medicine | null>(null);

  // Form Fields
  const [name, setName] = useState('');
  const [genericName, setGenericName] = useState('');
  const [strength, setStrength] = useState('');
  const [form, setForm] = useState('Tablet');
  const [category, setCategory] = useState('General');
  const [defaultDose, setDefaultDose] = useState('1 Tab');
  const [defaultFrequency, setDefaultFrequency] = useState('BD (Twice a day)');
  const [defaultDuration, setDefaultDuration] = useState('5 Days');
  const [defaultTiming, setDefaultTiming] = useState('After Food');
  const [isFavorite, setIsFavorite] = useState(false);
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  // Delete Confirm Dialog
  const [medicineToDelete, setMedicineToDelete] = useState<Medicine | null>(null);

  const fetchMedicines = async () => {
    setLoading(true);
    try {
      const all = await db.medicines.toArray();
      // Sort favorite first, then alphabetically
      all.sort((a, b) => {
        if (a.isFavorite && !b.isFavorite) return -1;
        if (!a.isFavorite && b.isFavorite) return 1;
        return a.name.localeCompare(b.name);
      });
      setMedicines(all);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMedicines();
  }, []);

  const openAddModal = () => {
    setMedicineToEdit(null);
    setName('');
    setGenericName('');
    setStrength('');
    setForm('Tablet');
    setCategory('General');
    setDefaultDose('1 Tab');
    setDefaultFrequency('BD (Twice daily)');
    setDefaultDuration('5 Days');
    setDefaultTiming('After Food');
    setIsFavorite(false);
    setStatus('active');
    setIsModalOpen(true);
  };

  const openEditModal = (m: Medicine) => {
    setMedicineToEdit(m);
    setName(m.name);
    setGenericName(m.genericName);
    setStrength(m.strength);
    setForm(m.form);
    setCategory(m.category);
    setDefaultDose(m.defaultDose || '');
    setDefaultFrequency(m.defaultFrequency || '');
    setDefaultDuration(m.defaultDuration || '');
    setDefaultTiming(m.defaultTiming || 'After Food');
    setIsFavorite(m.isFavorite);
    setStatus(m.status);
    setIsModalOpen(true);
  };

  const handleToggleFavorite = async (m: Medicine) => {
    try {
      await db.medicines.update(m.id!, { isFavorite: !m.isFavorite });
      await fetchMedicines();
      success(`${m.name} ${!m.isFavorite ? 'added to' : 'removed from'} favorites.`);
    } catch (err: any) {
      error(err.message);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      error('Please enter the medicine brand name.');
      return;
    }

    try {
      const now = new Date().toISOString().split('T')[0];

      if (medicineToEdit && medicineToEdit.id) {
        await db.medicines.update(medicineToEdit.id, {
          name: name.trim(),
          genericName: genericName.trim(),
          strength: strength.trim(),
          form,
          category: category.trim(),
          defaultDose: defaultDose.trim() || undefined,
          defaultFrequency: defaultFrequency.trim() || undefined,
          defaultDuration: defaultDuration.trim() || undefined,
          defaultTiming,
          isFavorite,
          status,
        });

        await logActivity(
          user?.username || 'Staff',
          user?.role || 'staff',
          'Edit Medicine',
          'Medicines',
          `Updated medicine ${name}`
        );

        success(`Medicine ${name} updated successfully!`);
      } else {
        await db.medicines.add({
          name: name.trim(),
          genericName: genericName.trim(),
          strength: strength.trim(),
          form,
          category: category.trim(),
          defaultDose: defaultDose.trim() || undefined,
          defaultFrequency: defaultFrequency.trim() || undefined,
          defaultDuration: defaultDuration.trim() || undefined,
          defaultTiming,
          isFavorite,
          status,
          createdAt: now,
        });

        await logActivity(
          user?.username || 'Staff',
          user?.role || 'staff',
          'Add Medicine',
          'Medicines',
          `Added new medicine ${name}`
        );

        success(`Medicine ${name} registered in master!`);
      }

      setIsModalOpen(false);
      await fetchMedicines();
    } catch (err: any) {
      error(err.message || 'Failed to save medicine');
    }
  };

  const handleDelete = async () => {
    if (!medicineToDelete || !medicineToDelete.id) return;
    try {
      await db.medicines.delete(medicineToDelete.id);
      await logActivity(
        user?.username || 'Staff',
        user?.role || 'staff',
        'Delete Medicine',
        'Medicines',
        `Deleted medicine ${medicineToDelete.name}`
      );
      success(`Medicine ${medicineToDelete.name} deleted.`);
      setMedicineToDelete(null);
      await fetchMedicines();
    } catch (err: any) {
      error(err.message || 'Failed to delete medicine');
    }
  };

  const filteredMedicines = useMemo(() => {
    return medicines.filter((m) => {
      const matchSearch =
        m.name.toLowerCase().includes(search.toLowerCase()) ||
        m.genericName.toLowerCase().includes(search.toLowerCase()) ||
        m.category.toLowerCase().includes(search.toLowerCase());
      const matchForm = formFilter === 'All' || m.form === formFilter;
      return matchSearch && matchForm;
    });
  }, [medicines, search, formFilter]);

  const paginatedMedicines = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredMedicines.slice(start, start + pageSize);
  }, [filteredMedicines, currentPage, pageSize]);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Pill className="w-6 h-6 text-blue-600" />
            Medicine Master Directory
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Formulary of brand names, generics, dosage defaults & prescription autocompletion
          </p>
        </div>

        {checkPermission('medicines') && (
          <button
            onClick={openAddModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Medicine
          </button>
        )}
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
        <div className="relative flex-1 w-full sm:max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by brand name, generic composition, category..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs text-slate-500">Dosage Form:</span>
          <select
            value={formFilter}
            onChange={(e) => {
              setFormFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-700"
          >
            <option value="All">All Forms</option>
            {MEDICINE_FORMS.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Medicines Table Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <LoadingSpinner message="Loading medicines database..." />
        ) : filteredMedicines.length === 0 ? (
          <div className="p-8">
            <EmptyState
              icon={Pill}
              title="No medicines found"
              description="Click Add Medicine to register formulations in your clinic pharmacy master."
              actionLabel={checkPermission('medicines') ? 'Add Medicine' : undefined}
              onAction={openAddModal}
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs sm:text-sm">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 text-[11px] font-semibold uppercase tracking-wider">
                  <th className="py-3 px-3 text-center w-10">Fav</th>
                  <th className="py-3 px-4">Brand & Strength</th>
                  <th className="py-3 px-4">Generic Composition</th>
                  <th className="py-3 px-4">Form</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Default Dosing</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {paginatedMedicines.map((med) => (
                  <tr key={med.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3 px-3 text-center">
                      <button
                        onClick={() => handleToggleFavorite(med)}
                        className={`p-1 rounded transition-colors ${
                          med.isFavorite ? 'text-amber-500 hover:text-amber-600' : 'text-slate-300 hover:text-slate-400'
                        }`}
                        title={med.isFavorite ? 'Starred Favorite' : 'Mark as Favorite'}
                      >
                        <Star className={`w-4 h-4 ${med.isFavorite ? 'fill-amber-500' : ''}`} />
                      </button>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{med.name}</div>
                      {med.strength && <div className="text-[11px] text-slate-500">{med.strength}</div>}
                    </td>
                    <td className="py-3 px-4 italic text-slate-600">{med.genericName || '-'}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                        {med.form}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600">{med.category || 'General'}</td>
                    <td className="py-3 px-4 text-[11px] text-slate-600">
                      {med.defaultDose || '1'} • {med.defaultFrequency || 'BD'} • {med.defaultTiming || 'After Food'}
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant={med.status === 'active' ? 'success' : 'neutral'}>
                        {med.status === 'active' ? 'Active' : 'Disabled'}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-right space-x-1">
                      {checkPermission('medicines') && (
                        <>
                          <button
                            onClick={() => openEditModal(med)}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors"
                            title="Edit Formulation"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setMedicineToDelete(med)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <Pagination
              currentPage={currentPage}
              totalItems={filteredMedicines.length}
              pageSize={pageSize}
              onPageChange={setCurrentPage}
              onPageSizeChange={(newSize) => {
                setPageSize(newSize);
                setCurrentPage(1);
              }}
            />
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={medicineToEdit ? `Edit Formulation: ${medicineToEdit.name}` : 'Add New Medicine Formulation'}
        subtitle="Saved to Medicine Master for autocompletion during prescribing"
        maxWidth="2xl"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Brand Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Augmentin / Paracetamol"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Strength</label>
              <input
                type="text"
                placeholder="e.g. 625mg / 500mg / 10ml"
                value={strength}
                onChange={(e) => setStrength(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Generic / Chemical Composition</label>
            <input
              type="text"
              placeholder="e.g. Amoxicillin and Clavulanate Potassium"
              value={genericName}
              onChange={(e) => setGenericName(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Form</label>
              <select
                value={form}
                onChange={(e) => setForm(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              >
                {MEDICINE_FORMS.map((f) => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Therapeutic Category</label>
              <input
                type="text"
                placeholder="e.g. Antibiotics / Pain Relief"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Dosing Defaults for fast prescribing */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <p className="text-xs font-bold text-slate-800">Prescription Dosing Defaults</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="text-[11px] text-slate-600 block mb-0.5">Default Dose</label>
                <input
                  type="text"
                  placeholder="1 Tab / 5ml"
                  value={defaultDose}
                  onChange={(e) => setDefaultDose(e.target.value)}
                  className="w-full px-2 py-1.5 bg-white border border-slate-300 rounded text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-600 block mb-0.5">Frequency</label>
                <input
                  type="text"
                  placeholder="1-0-1 / BD"
                  value={defaultFrequency}
                  onChange={(e) => setDefaultFrequency(e.target.value)}
                  className="w-full px-2 py-1.5 bg-white border border-slate-300 rounded text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-600 block mb-0.5">Duration</label>
                <input
                  type="text"
                  placeholder="5 Days"
                  value={defaultDuration}
                  onChange={(e) => setDefaultDuration(e.target.value)}
                  className="w-full px-2 py-1.5 bg-white border border-slate-300 rounded text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-600 block mb-0.5">Food Timing</label>
                <select
                  value={defaultTiming}
                  onChange={(e) => setDefaultTiming(e.target.value)}
                  className="w-full px-2 py-1.5 bg-white border border-slate-300 rounded text-xs"
                >
                  <option value="After Food">After Food</option>
                  <option value="Before Food">Before Food</option>
                  <option value="With Food">With Food</option>
                  <option value="Empty Stomach">Empty Stomach</option>
                </select>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
              <input
                type="checkbox"
                checked={isFavorite}
                onChange={(e) => setIsFavorite(e.target.checked)}
                className="w-4 h-4 text-amber-500 rounded border-slate-300 focus:ring-amber-400"
              />
              Mark as Favorite formulation (Pin to top)
            </label>

            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as any)}
              className="text-xs px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg"
            >
              <option value="active">Active</option>
              <option value="inactive">Disabled</option>
            </select>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 text-sm font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs"
            >
              Save Medicine
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirm */}
      <ConfirmDialog
        isOpen={Boolean(medicineToDelete)}
        title="Delete Medicine Formulation"
        message={`Are you sure you want to permanently delete "${medicineToDelete?.name}" from your formulary?`}
        confirmLabel="Yes, Delete"
        cancelLabel="Cancel"
        variant="danger"
        iconType="trash"
        onConfirm={handleDelete}
        onCancel={() => setMedicineToDelete(null)}
      />
    </div>
  );
};
