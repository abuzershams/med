import React, { useState, useEffect } from 'react';
import {
  Clock,
  Calendar,
  CheckCircle2,
  XCircle,
  AlertCircle,
  UserCheck,
  Search,
  Save,
} from 'lucide-react';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { StatCard } from '../../components/common/StatCard';
import { StatusBadge } from '../../components/common/Badge';
import { logActivity } from '../../services/auditService';
import type { Attendance, User, Doctor } from '../../types';

export const AttendancePage: React.FC = () => {
  const { formatDate } = useClinic();
  const { user } = useAuth();
  const { success, error } = useToast();

  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [employees, setEmployees] = useState<{ id: string; name: string; role: string }[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<Record<string, Attendance>>({});
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      // 1. Gather all active users & doctors
      const allUsers = await db.users.where('status').equals('active').toArray();
      const allDoctors = await db.doctors.where('status').equals('active').toArray();

      const combined: { id: string; name: string; role: string }[] = [];

      allDoctors.forEach((d) => {
        combined.push({
          id: `doc-${d.id}`,
          name: `Dr. ${d.name}`,
          role: d.specialization || 'Doctor',
        });
      });

      allUsers.forEach((u) => {
        combined.push({
          id: `usr-${u.id}`,
          name: u.name,
          role: u.role,
        });
      });

      setEmployees(combined);

      // 2. Load attendance for selectedDate
      const dayRecords = await db.attendance.where('date').equals(selectedDate).toArray();
      const map: Record<string, Attendance> = {};
      dayRecords.forEach((rec) => {
        const key = `${rec.employeeType}-${rec.employeeId}`;
        map[key] = rec;
      });
      setAttendanceRecords(map);
    } catch (err) {
      console.error(err);
      error('Failed to load attendance');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedDate]);

  const handleStatusChange = (
    empKey: string,
    status: 'present' | 'absent' | 'half_day' | 'leave'
  ) => {
    const existing = attendanceRecords[empKey];
    const [empType, empIdStr] = empKey.split('-');
    const emp = employees.find((e) => e.id === empKey);

    const updated: Attendance = {
      ...(existing || {
        employeeId: Number(empIdStr),
        employeeName: emp?.name || '',
        employeeType: empType as 'doctor' | 'staff',
        date: selectedDate,
        inTime: '09:00',
        outTime: '17:00',
      }),
      status,
    };

    setAttendanceRecords((prev) => ({ ...prev, [empKey]: updated }));
  };

  const handleTimeChange = (empKey: string, field: 'inTime' | 'outTime', value: string) => {
    const existing = attendanceRecords[empKey];
    if (!existing) return;
    setAttendanceRecords((prev) => ({
      ...prev,
      [empKey]: { ...existing, [field]: value },
    }));
  };

  const handleSaveAll = async () => {
    try {
      for (const [key, record] of Object.entries(attendanceRecords)) {
        if (record.id) {
          await db.attendance.update(record.id, record);
        } else {
          const id = await db.attendance.add(record);
          record.id = Number(id);
        }
      }

      await logActivity(
        user?.name || 'User',
        user?.role || 'admin',
        'SAVE_ATTENDANCE',
        'attendance',
        `Saved staff attendance for ${selectedDate}`
      );

      success('Attendance records saved successfully');
      loadData();
    } catch (err) {
      console.error(err);
      error('Failed to save attendance');
    }
  };

  // Metrics for selected day
  const totalEmployees = employees.length;
  const presentCount = Object.values(attendanceRecords).filter(
    (r) => r.status === 'present'
  ).length;
  const absentCount = Object.values(attendanceRecords).filter(
    (r) => r.status === 'absent'
  ).length;
  const halfDayCount = Object.values(attendanceRecords).filter(
    (r) => r.status === 'half_day'
  ).length;
  const leaveCount = Object.values(attendanceRecords).filter(
    (r) => r.status === 'leave'
  ).length;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Staff Attendance</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Daily check-in, check-out times, and staff leave tracking
          </p>
        </div>

        <div className="flex items-center gap-3">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 text-sm bg-white font-medium focus:outline-none focus:border-blue-500 shadow-xs"
          />

          <button
            onClick={handleSaveAll}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm shadow-sm shadow-blue-500/20 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            Save Attendance
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Present"
          value={presentCount}
          subtitle={`Out of ${totalEmployees} total staff`}
          icon={CheckCircle2}
          colorScheme="emerald"
        />
        <StatCard
          title="Absent"
          value={absentCount}
          subtitle="Unexcused absence"
          icon={XCircle}
          colorScheme="rose"
        />
        <StatCard
          title="Half Day"
          value={halfDayCount}
          subtitle="Partial shifts"
          icon={Clock}
          colorScheme="amber"
        />
        <StatCard
          title="Approved Leave"
          value={leaveCount}
          subtitle="Medical / Paid leave"
          icon={AlertCircle}
          colorScheme="blue"
        />
      </div>

      {/* Attendance Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-base">
            Attendance Log for: {formatDate(selectedDate)}
          </h3>
          <span className="text-xs text-slate-500">
            Click status pills below to toggle state for each employee
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-semibold text-slate-500">
              <tr>
                <th className="px-5 py-3.5">Employee Name</th>
                <th className="px-4 py-3.5">Designation</th>
                <th className="px-4 py-3.5 text-center">Status</th>
                <th className="px-4 py-3.5 w-32">In Time</th>
                <th className="px-4 py-3.5 w-32">Out Time</th>
                <th className="px-5 py-3.5">Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {employees.map((emp) => {
                const rec = attendanceRecords[emp.id];
                const currentStatus = rec?.status || 'present';

                return (
                  <tr key={emp.id} className="hover:bg-slate-50/80">
                    <td className="px-5 py-3.5 font-semibold text-slate-900">
                      {emp.name}
                    </td>
                    <td className="px-4 py-3.5 text-xs text-slate-500 capitalize">
                      {emp.role}
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <div className="inline-flex rounded-lg border border-slate-200 bg-slate-50 p-0.5 text-xs">
                        {(['present', 'half_day', 'absent', 'leave'] as const).map((st) => (
                          <button
                            key={st}
                            type="button"
                            onClick={() => handleStatusChange(emp.id, st)}
                            className={`px-2.5 py-1 rounded-md font-semibold capitalize transition-all cursor-pointer ${
                              currentStatus === st
                                ? st === 'present'
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : st === 'absent'
                                  ? 'bg-rose-600 text-white shadow-xs'
                                  : st === 'half_day'
                                  ? 'bg-amber-600 text-white shadow-xs'
                                  : 'bg-blue-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            {st === 'half_day' ? 'Half Day' : st}
                          </button>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <input
                        type="time"
                        value={rec?.inTime || '09:00'}
                        disabled={currentStatus === 'absent' || currentStatus === 'leave'}
                        onChange={(e) => handleTimeChange(emp.id, 'inTime', e.target.value)}
                        className="px-2 py-1 text-xs border border-slate-200 rounded-lg bg-white disabled:opacity-40"
                      />
                    </td>
                    <td className="px-4 py-3.5">
                      <input
                        type="time"
                        value={rec?.outTime || '17:00'}
                        disabled={currentStatus === 'absent' || currentStatus === 'leave'}
                        onChange={(e) => handleTimeChange(emp.id, 'outTime', e.target.value)}
                        className="px-2 py-1 text-xs border border-slate-200 rounded-lg bg-white disabled:opacity-40"
                      />
                    </td>
                    <td className="px-5 py-3.5">
                      <input
                        type="text"
                        placeholder="Optional remarks..."
                        value={rec?.notes || ''}
                        onChange={(e) => {
                          const existing = attendanceRecords[emp.id];
                          if (existing) {
                            setAttendanceRecords((prev) => ({
                              ...prev,
                              [emp.id]: { ...existing, notes: e.target.value },
                            }));
                          }
                        }}
                        className="w-full text-xs px-2.5 py-1 border border-slate-200 rounded-lg bg-white focus:outline-none"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
