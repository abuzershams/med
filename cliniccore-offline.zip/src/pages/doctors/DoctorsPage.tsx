import React, { useState, useEffect } from 'react';
import { Stethoscope, Plus, Edit, Phone, Mail, DollarSign, CheckCircle2, XCircle } from 'lucide-react';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useClinic } from '../../context/ClinicContext';
import { logActivity } from '../../services/auditService';
import { Modal } from '../../components/common/Modal';
import { Badge } from '../../components/common/Badge';
import { EmptyState, LoadingSpinner } from '../../components/common/EmptyState';
import type { Doctor } from '../../types';

export const DoctorsPage: React.FC = () => {
  const { user, checkPermission } = useAuth();
  const { formatCurrency } = useClinic();
  const { success, error } = useToast();

  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [doctorToEdit, setDoctorToEdit] = useState<Doctor | null>(null);

  const [name, setName] = useState('');
  const [degree, setDegree] = useState('MBBS, MD');
  const [specialization, setSpecialization] = useState('');
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [room, setRoom] = useState('Consultation Room 1');
  const [consultationFee, setConsultationFee] = useState<number>(500);
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  const fetchDoctors = async () => {
    setLoading(true);
    try {
      const all = await db.doctors.toArray();
      setDoctors(all);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDoctors();
  }, []);

  const openAddModal = () => {
    setDoctorToEdit(null);
    setName('');
    setDegree('MBBS, MD');
    setSpecialization('General Physician');
    setRegistrationNumber('');
    setPhone('');
    setEmail('');
    setRoom('Room 1');
    setConsultationFee(500);
    setStatus('active');
    setIsModalOpen(true);
  };

  const openEditModal = (d: Doctor) => {
    setDoctorToEdit(d);
    setName(d.name);
    setDegree(d.degree);
    setSpecialization(d.specialization);
    setRegistrationNumber(d.registrationNumber);
    setPhone(d.phone);
    setEmail(d.email || '');
    setRoom(d.room || '');
    setConsultationFee(d.consultationFee);
    setStatus(d.status);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !registrationNumber.trim()) {
      error('Please fill in doctor name, phone number, and medical registration number.');
      return;
    }

    try {
      if (doctorToEdit && doctorToEdit.id) {
        await db.doctors.update(doctorToEdit.id, {
          name: name.trim(),
          degree: degree.trim(),
          specialization: specialization.trim(),
          registrationNumber: registrationNumber.trim(),
          phone: phone.trim(),
          email: email.trim() || undefined,
          room: room.trim() || undefined,
          consultationFee: consultationFee || 0,
          status,
        });

        await logActivity(
          user?.username || 'Admin',
          user?.role || 'admin',
          'Edit Doctor',
          'Doctors',
          `Updated details for Dr. ${name}`
        );

        success(`Doctor ${name} updated successfully!`);
      } else {
        await db.doctors.add({
          name: name.trim(),
          degree: degree.trim(),
          specialization: specialization.trim(),
          registrationNumber: registrationNumber.trim(),
          phone: phone.trim(),
          email: email.trim() || undefined,
          room: room.trim() || undefined,
          consultationFee: consultationFee || 0,
          status,
          createdAt: new Date().toISOString().split('T')[0],
        });

        await logActivity(
          user?.username || 'Admin',
          user?.role || 'admin',
          'Add Doctor',
          'Doctors',
          `Added new doctor Dr. ${name}`
        );

        success(`Doctor ${name} registered successfully!`);
      }

      setIsModalOpen(false);
      await fetchDoctors();
    } catch (err: any) {
      error(err.message || 'Failed to save doctor');
    }
  };

  const filteredDoctors = doctors.filter((d) => {
    if (statusFilter === 'all') return true;
    return d.status === statusFilter;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Stethoscope className="w-6 h-6 text-blue-600" />
            Doctors & Physicians Directory
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage practicing consultants, rooms, and consultation tariffs
          </p>
        </div>

        {checkPermission('doctors') && (
          <button
            onClick={openAddModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Doctor
          </button>
        )}
      </div>

      {/* Tabs Filter */}
      <div className="flex items-center gap-2">
        {(['all', 'active', 'inactive'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setStatusFilter(tab)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all ${
              statusFilter === tab
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {tab} Doctors ({tab === 'all' ? doctors.length : doctors.filter((d) => d.status === tab).length})
          </button>
        ))}
      </div>

      {/* Doctors Cards Grid */}
      {loading ? (
        <LoadingSpinner message="Loading doctors..." />
      ) : filteredDoctors.length === 0 ? (
        <EmptyState
          icon={Stethoscope}
          title="No doctors found"
          description="Click Add Doctor to add practicing doctors to your clinic."
          actionLabel={checkPermission('doctors') ? 'Add Doctor' : undefined}
          onAction={openAddModal}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDoctors.map((doc) => (
            <div
              key={doc.id}
              className="p-5 bg-white rounded-2xl border border-slate-200 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 font-bold flex items-center justify-center text-base border border-blue-200">
                    {doc.name.replace(/^Dr\.\s*/i, '').charAt(0)}
                  </div>
                  <Badge variant={doc.status === 'active' ? 'success' : 'neutral'}>
                    {doc.status === 'active' ? 'Active' : 'Inactive'}
                  </Badge>
                </div>

                <h3 className="text-base font-bold text-slate-900">{doc.name}</h3>
                <p className="text-xs font-semibold text-blue-600 mt-0.5">{doc.specialization}</p>
                <p className="text-[11px] text-slate-500">{doc.degree} • Reg: {doc.registrationNumber}</p>

                <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{doc.phone}</span>
                  </div>
                  {doc.email && (
                    <div className="flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5 text-slate-400" />
                      <span>{doc.email}</span>
                    </div>
                  )}
                  {doc.room && (
                    <div className="text-slate-500 font-medium">
                      Room: <span className="text-slate-800">{doc.room}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Consultation Fee</span>
                  <span className="text-sm font-bold text-slate-900">{formatCurrency(doc.consultationFee)}</span>
                </div>

                {checkPermission('doctors') && (
                  <button
                    onClick={() => openEditModal(doc)}
                    className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors"
                    title="Edit Doctor"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={doctorToEdit ? `Edit Doctor: ${doctorToEdit.name}` : 'Add New Doctor'}
        subtitle="Physician credentials, room number, and consultation tariffs"
        maxWidth="xl"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Doctor Full Name *</label>
            <input
              type="text"
              required
              placeholder="e.g. Dr. Jane Smith"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Degrees & Qualifications *</label>
              <input
                type="text"
                required
                placeholder="e.g. MBBS, MD (Medicine)"
                value={degree}
                onChange={(e) => setDegree(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Clinical Specialization *</label>
              <input
                type="text"
                required
                placeholder="e.g. Paediatrics / Cardiology"
                value={specialization}
                onChange={(e) => setSpecialization(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Medical Reg. Number *</label>
              <input
                type="text"
                required
                placeholder="e.g. REG-98421"
                value={registrationNumber}
                onChange={(e) => setRegistrationNumber(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Consultation Room</label>
              <input
                type="text"
                placeholder="e.g. Room 2"
                value={room}
                onChange={(e) => setRoom(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number *</label>
              <input
                type="tel"
                required
                placeholder="Phone number"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                placeholder="doctor@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Consultation Fee (₹)</label>
              <input
                type="number"
                min="0"
                value={consultationFee}
                onChange={(e) => setConsultationFee(Number(e.target.value))}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              >
                <option value="active">Active Practitioner</option>
                <option value="inactive">Inactive / On Leave</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 text-sm font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs"
            >
              Save Doctor
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
