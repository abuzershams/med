import React, { useState } from 'react';
import { User, Lock, Save, KeyRound, ShieldCheck, Phone } from 'lucide-react';
import bcrypt from 'bcryptjs';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { logActivity } from '../../services/auditService';

export const MyAccountPage: React.FC = () => {
  const { user } = useAuth();
  const { success, error } = useToast();

  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');

  // Password fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.id) return;
    setSavingProfile(true);
    try {
      await db.users.update(user.id, {
        name: name.trim(),
        phone: phone.trim(),
      });
      await logActivity(
        user.name,
        user.role,
        'UPDATE_PROFILE',
        'auth',
        'Updated personal profile details'
      );
      success('Profile updated successfully');
    } catch (err) {
      console.error(err);
      error('Failed to update profile');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.id) return;

    if (newPassword !== confirmPassword) {
      error('New password and confirmation do not match');
      return;
    }

    if (newPassword.length < 6) {
      error('New password must be at least 6 characters');
      return;
    }

    setSavingPassword(true);
    try {
      const dbUser = await db.users.get(user.id);
      if (!dbUser) {
        error('User account not found');
        return;
      }

      // Verify current password
      const match = await bcrypt.compare(currentPassword, dbUser.passwordHash);
      if (!match) {
        error('Incorrect current password');
        return;
      }

      // Hash and update
      const newHash = await bcrypt.hash(newPassword, 10);
      await db.users.update(user.id, { passwordHash: newHash });

      await logActivity(
        user.name,
        user.role,
        'CHANGE_PASSWORD',
        'auth',
        'Changed personal account password'
      );

      success('Password changed successfully');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      console.error(err);
      error('Failed to change password');
    } finally {
      setSavingPassword(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">My Account</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Manage your personal staff profile and change login security credentials
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Profile Card */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <User className="w-5 h-5 text-blue-600" />
            Personal Profile
          </h3>

          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Full Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Username
              </label>
              <input
                type="text"
                disabled
                value={user?.username || ''}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-500 font-mono"
              />
              <p className="text-[11px] text-slate-400 mt-1">Username cannot be changed</p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                System Role
              </label>
              <div className="px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-sm font-semibold capitalize text-slate-700 flex items-center justify-between">
                <span>{user?.role}</span>
                <span className="text-xs px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 font-bold">
                  Active
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Phone Number
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <button
              type="submit"
              disabled={savingProfile}
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm transition-all cursor-pointer shadow-sm shadow-blue-500/20"
            >
              {savingProfile ? 'Saving...' : 'Update Profile'}
            </button>
          </form>
        </div>

        {/* Change Password Card */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
            <Lock className="w-5 h-5 text-amber-500" />
            Change Password
          </h3>

          <form onSubmit={handleChangePassword} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Current Password *
              </label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required
                placeholder="••••••••"
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                New Password *
              </label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                placeholder="Min 6 characters"
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Confirm New Password *
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                placeholder="Repeat new password"
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <button
              type="submit"
              disabled={savingPassword}
              className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-medium text-sm transition-all cursor-pointer shadow-sm"
            >
              {savingPassword ? 'Updating...' : 'Change Password'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
