import React, { useState, useEffect } from 'react';
import {
  ScrollText,
  Search,
  Filter,
  Trash2,
  Clock,
  User,
  ShieldCheck,
} from 'lucide-react';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { Pagination } from '../../components/common/Pagination';
import { EmptyState, LoadingSpinner } from '../../components/common/EmptyState';
import type { ActivityLog } from '../../types';

export const ActivityLogsPage: React.FC = () => {
  const { user } = useAuth();
  const { success, error } = useToast();

  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [moduleFilter, setModuleFilter] = useState('all');

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const [isClearOpen, setIsClearOpen] = useState(false);

  const loadLogs = async () => {
    setLoading(true);
    try {
      const allLogs = await db.activity_logs.reverse().sortBy('timestamp');
      setLogs(allLogs);
    } catch (err) {
      console.error(err);
      error('Failed to load activity logs');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, []);

  const filteredLogs = logs.filter((log) => {
    const q = search.toLowerCase();
    const matchesSearch =
      log.userName.toLowerCase().includes(q) ||
      log.action.toLowerCase().includes(q) ||
      log.details.toLowerCase().includes(q);

    const matchesModule = moduleFilter === 'all' || log.module === moduleFilter;
    return matchesSearch && matchesModule;
  });

  const totalItems = filteredLogs.length;
  const startIndex = (currentPage - 1) * pageSize;
  const paginated = filteredLogs.slice(startIndex, startIndex + pageSize);

  const handleClearLogs = async () => {
    try {
      await db.activity_logs.clear();
      success('Activity audit log cleared');
      setLogs([]);
      setIsClearOpen(false);
    } catch (err) {
      console.error(err);
      error('Failed to clear logs');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Activity Audit Logs</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Tamper-evident chronological audit trail of all staff actions and clinic database events
          </p>
        </div>

        {user?.role === 'admin' && logs.length > 0 && (
          <button
            onClick={() => setIsClearOpen(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs font-semibold transition-all cursor-pointer self-start sm:self-auto"
          >
            <Trash2 className="w-4 h-4" />
            Clear Log History
          </button>
        )}
      </div>

      {/* Filters Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative flex-1 w-full sm:max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by user, action, details..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-9 pr-4 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-blue-500"
          />
        </div>

        <select
          value={moduleFilter}
          onChange={(e) => {
            setModuleFilter(e.target.value);
            setCurrentPage(1);
          }}
          className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-none self-stretch sm:self-auto"
        >
          <option value="all">All Modules</option>
          <option value="auth">Authentication</option>
          <option value="patients">Patients</option>
          <option value="appointments">Appointments</option>
          <option value="prescriptions">Prescriptions</option>
          <option value="billing">Billing & Invoices</option>
          <option value="pharmacy">Pharmacy & POS</option>
          <option value="finance">Finance & Payroll</option>
          <option value="system">System & Backup</option>
        </select>
      </div>

      {/* Logs Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {loading ? (
          <div className="p-12 flex justify-center">
            <LoadingSpinner size="lg" message="Loading audit trail..." />
          </div>
        ) : filteredLogs.length === 0 ? (
          <EmptyState
            icon={ScrollText}
            title="No activity logs found"
            description="All user interactions, record creations, deletions, and system events will appear here."
          />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-semibold text-slate-500">
                  <tr>
                    <th className="px-5 py-3.5 w-44">Timestamp</th>
                    <th className="px-4 py-3.5">User</th>
                    <th className="px-4 py-3.5">Action</th>
                    <th className="px-4 py-3.5">Module</th>
                    <th className="px-5 py-3.5">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {paginated.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/80">
                      <td className="px-5 py-3 text-slate-400 font-mono">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-900">
                        {log.userName}
                        <span className="text-[10px] text-slate-400 block capitalize">
                          {log.userRole}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-semibold text-blue-600">
                        {log.action}
                      </td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-medium capitalize">
                          {log.module}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-slate-700 max-w-md">
                        {log.details}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-4 border-t border-slate-200">
              <Pagination
                currentPage={currentPage}
                totalItems={totalItems}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1);
                }}
              />
            </div>
          </>
        )}
      </div>

      {/* Clear Logs Confirm */}
      <ConfirmDialog
        isOpen={isClearOpen}
        title="Clear Activity Logs"
        message="Are you sure you want to permanently clear the audit log history? This action cannot be undone."
        confirmLabel="Clear All Logs"
        variant="danger"
        onConfirm={handleClearLogs}
        onCancel={() => setIsClearOpen(false)}
      />
    </div>
  );
};
