import React, { useState, useEffect } from 'react';
import {
  Upload,
  User,
  Phone,
  Mail,
  MapPin,
  AlertTriangle,
  FileText,
  Shield,
  Heart,
  Droplet,
  Trash2,
  Calendar,
  Plus,
  Minus,
} from 'lucide-react';
import { Modal } from '../../components/common/Modal';
import { DatePicker } from '../../components/common/DatePicker';
import { getNextPatientCode } from '../../services/counterService';
import { db } from '../../db/database';
import { logActivity } from '../../services/auditService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import type { Patient } from '../../types';

interface PatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientToEdit?: Patient | null;
  onSaved: (patient: Patient) => void;
}

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export const PatientModal: React.FC<PatientModalProps> = ({
  isOpen,
  onClose,
  patientToEdit,
  onSaved,
}) => {
  const { user } = useAuth();
  const { success, error } = useToast();

  // Form State
  const [name, setName] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [dob, setDob] = useState('');
  const [age, setAge] = useState<number | ''>('');
  const [phone, setPhone] = useState('');
  const [altPhone, setAltPhone] = useState('');
  const [email, setEmail] = useState('');
  const [bloodGroup, setBloodGroup] = useState('');
  const [allergies, setAllergies] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [emergencyContactName, setEmergencyContactName] = useState('');
  const [emergencyContactPhone, setEmergencyContactPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [photoBase64, setPhotoBase64] = useState<string>('');
  const [loading, setLoading] = useState(false);

  // Field-level Validation Errors
  const [errors, setErrors] = useState<{
    name?: string;
    phone?: string;
    age?: string;
    dob?: string;
    email?: string;
  }>({});

  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (patientToEdit) {
      setName(patientToEdit.name || '');
      setGender(patientToEdit.gender || 'Male');
      setDob(patientToEdit.dob || '');
      setAge(patientToEdit.age ?? '');
      setPhone(patientToEdit.phone || '');
      setAltPhone(patientToEdit.altPhone || '');
      setEmail(patientToEdit.email || '');
      setBloodGroup(patientToEdit.bloodGroup || '');
      setAllergies(patientToEdit.allergies || '');
      setAddress(patientToEdit.address || '');
      setCity(patientToEdit.city || '');
      setEmergencyContactName(patientToEdit.emergencyContactName || '');
      setEmergencyContactPhone(patientToEdit.emergencyContactPhone || '');
      setNotes(patientToEdit.notes || '');
      setPhotoBase64(patientToEdit.photoBase64 || '');
    } else {
      setName('');
      setGender('Male');
      setDob('');
      setAge('');
      setPhone('');
      setAltPhone('');
      setEmail('');
      setBloodGroup('');
      setAllergies('');
      setAddress('');
      setCity('');
      setEmergencyContactName('');
      setEmergencyContactPhone('');
      setNotes('');
      setPhotoBase64('');
    }
    setErrors({});
  }, [patientToEdit, isOpen]);

  // Handle Photo Upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        error('Patient photo must be less than 2 MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoBase64(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // DOB change: calculate age automatically as a convenience, but user can edit age freely
  const handleDobChange = (val: string) => {
    setDob(val);
    if (errors.dob) {
      setErrors((prev) => ({ ...prev, dob: undefined }));
    }

    if (val) {
      const birthDate = new Date(val);
      const today = new Date();
      if (!isNaN(birthDate.getTime())) {
        if (val > todayStr) {
          setErrors((prev) => ({ ...prev, dob: 'Date of birth cannot be in the future' }));
          return;
        }

        let calculatedAge = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
          calculatedAge--;
        }
        if (calculatedAge >= 0 && calculatedAge <= 130) {
          setAge(calculatedAge);
          if (errors.age) {
            setErrors((prev) => ({ ...prev, age: undefined }));
          }
        }
      }
    }
  };

  // Age input change: allow direct numeric entry without requiring DOB
  const handleAgeChange = (valStr: string) => {
    // Only allow numeric characters or empty
    const cleanStr = valStr.replace(/\D/g, '');

    if (cleanStr === '') {
      setAge('');
      setErrors((prev) => ({ ...prev, age: undefined }));
      return;
    }

    const num = Number(cleanStr);
    if (num > 130) {
      setErrors((prev) => ({ ...prev, age: 'Please enter a realistic age (0–130)' }));
      setAge(130);
    } else {
      setAge(num);
      setErrors((prev) => ({ ...prev, age: undefined }));
    }
  };

  const adjustAge = (delta: number) => {
    const current = typeof age === 'number' ? age : 0;
    const next = Math.max(0, Math.min(130, current + delta));
    setAge(next);
    setErrors((prev) => ({ ...prev, age: undefined }));
  };

  const validateForm = () => {
    const newErrors: typeof errors = {};

    if (!name.trim()) {
      newErrors.name = 'Patient name is required';
    }

    if (!phone.trim()) {
      newErrors.phone = 'Primary phone number is required';
    } else if (phone.trim().replace(/\D/g, '').length < 6) {
      newErrors.phone = 'Please enter a valid phone number';
    }

    if (dob && dob > todayStr) {
      newErrors.dob = 'Date of birth cannot be in the future';
    }

    if (typeof age === 'number' && (age < 0 || age > 130)) {
      newErrors.age = 'Age must be between 0 and 130';
    }

    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      newErrors.email = 'Please enter a valid email address';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      error('Please correct the highlighted fields before saving.');
      return;
    }

    setLoading(true);
    try {
      const now = new Date().toISOString();

      if (patientToEdit && patientToEdit.id) {
        // Edit existing patient
        const updatedData: Partial<Patient> = {
          name: name.trim(),
          gender,
          dob: dob || undefined,
          age: typeof age === 'number' ? age : undefined,
          phone: phone.trim(),
          altPhone: altPhone.trim() || undefined,
          email: email.trim() || undefined,
          bloodGroup: bloodGroup || undefined,
          allergies: allergies.trim() || undefined,
          address: address.trim() || undefined,
          city: city.trim() || undefined,
          emergencyContactName: emergencyContactName.trim() || undefined,
          emergencyContactPhone: emergencyContactPhone.trim() || undefined,
          notes: notes.trim() || undefined,
          photoBase64: photoBase64 || undefined,
          updatedAt: now,
        };

        await db.patients.update(patientToEdit.id, updatedData);
        await logActivity(
          user?.username || 'Staff',
          user?.role || 'staff',
          'Edit Patient',
          'Patients',
          `Updated patient ${patientToEdit.patientCode} (${name.trim()})`
        );

        const saved = (await db.patients.get(patientToEdit.id))!;
        success(`Patient ${saved.patientCode} updated successfully.`);
        onSaved(saved);
      } else {
        // Create new patient with auto-generated atomic code
        const patientCode = await getNextPatientCode();
        const newPatient: Omit<Patient, 'id'> = {
          patientCode,
          name: name.trim(),
          gender,
          dob: dob || undefined,
          age: typeof age === 'number' ? age : undefined,
          phone: phone.trim(),
          altPhone: altPhone.trim() || undefined,
          email: email.trim() || undefined,
          bloodGroup: bloodGroup || undefined,
          allergies: allergies.trim() || undefined,
          address: address.trim() || undefined,
          city: city.trim() || undefined,
          emergencyContactName: emergencyContactName.trim() || undefined,
          emergencyContactPhone: emergencyContactPhone.trim() || undefined,
          notes: notes.trim() || undefined,
          photoBase64: photoBase64 || undefined,
          createdAt: now,
          updatedAt: now,
        };

        const id = await db.patients.add(newPatient as Patient);
        await logActivity(
          user?.username || 'Staff',
          user?.role || 'staff',
          'Create Patient',
          'Patients',
          `Created patient ${patientCode} (${name.trim()})`
        );

        const saved = (await db.patients.get(id))!;
        success(`Patient ${patientCode} registered successfully.`);
        onSaved(saved);
      }
      onClose();
    } catch (err: any) {
      error(err.message || 'Failed to save patient');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={patientToEdit ? `Edit Patient: ${patientToEdit.patientCode}` : 'Register New Patient'}
      subtitle={
        patientToEdit
          ? 'Update medical demographic records and contact details'
          : 'Create a permanent medical record file stored securely offline in IndexedDB'
      }
      maxWidth="3xl"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* SECTION 1: Personal Details & Demographics */}
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <User className="w-4 h-4 text-blue-600" />
              Patient Identification & Demographics
            </h4>
            <span className="text-[11px] text-slate-400 font-medium">* Required fields</span>
          </div>

          <div className="flex flex-col sm:flex-row items-start gap-4 p-4 rounded-2xl bg-slate-50/70 border border-slate-200/80">
            {/* Photo Avatar */}
            <div className="flex flex-col items-center gap-2 shrink-0 self-center sm:self-start">
              <div className="w-20 h-20 sm:w-22 sm:h-22 rounded-2xl bg-white border border-slate-200 shadow-2xs overflow-hidden flex items-center justify-center text-slate-400 relative group">
                {photoBase64 ? (
                  <img src={photoBase64} alt="Patient avatar" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-9 h-9 text-slate-300" />
                )}
              </div>
              <div className="flex flex-col items-center gap-1">
                <label className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-600 hover:text-blue-800 cursor-pointer px-2 py-0.5 rounded-md hover:bg-blue-50 transition-colors">
                  <Upload className="w-3 h-3" />
                  {photoBase64 ? 'Change' : 'Photo'}
                  <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                </label>
                {photoBase64 && (
                  <button
                    type="button"
                    onClick={() => setPhotoBase64('')}
                    className="text-[10px] text-rose-500 hover:text-rose-700 flex items-center gap-0.5 transition-colors"
                  >
                    <Trash2 className="w-2.5 h-2.5" />
                    Remove
                  </button>
                )}
              </div>
            </div>

            {/* Name & Gender */}
            <div className="flex-1 w-full space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    autoFocus={!patientToEdit}
                    placeholder="e.g. Ramesh Kumar Sharma"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                    }}
                    className={`w-full min-h-[44px] px-3.5 py-2.5 bg-white border rounded-xl text-sm text-slate-900 placeholder:text-slate-400 transition-all ${
                      errors.name
                        ? 'border-rose-400 ring-2 ring-rose-500/10 focus:border-rose-500'
                        : 'border-slate-300 hover:border-slate-400 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15'
                    } focus:outline-hidden`}
                  />
                </div>
                {errors.name && <p className="text-[11px] text-rose-600 mt-1 font-medium">{errors.name}</p>}
              </div>

              {/* Gender Segmented Control */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Gender <span className="text-rose-500">*</span>
                </label>
                <div
                  role="radiogroup"
                  aria-label="Patient Gender"
                  className="grid grid-cols-3 gap-1.5 p-1 bg-slate-200/70 rounded-xl"
                >
                  {(['Male', 'Female', 'Other'] as const).map((g) => (
                    <button
                      key={g}
                      type="button"
                      role="radio"
                      aria-checked={gender === g}
                      onClick={() => setGender(g)}
                      className={`min-h-[38px] py-2 px-3 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                        gender === g
                          ? 'bg-white text-blue-700 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Date of Birth, Age & Blood Group Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Date of Birth via Premium DatePicker */}
            <div>
              <DatePicker
                label="Date of Birth"
                placeholder="Select date"
                value={dob}
                onChange={handleDobChange}
                max={todayStr}
                error={errors.dob}
                helperText="Auto-computes age; or enter age directly"
              />
            </div>

            {/* Age (Years) - Solved Usability Problem */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="patient-age" className="block text-xs font-semibold text-slate-700">
                  Age (Years)
                </label>
                {typeof age === 'number' && (
                  <span className="text-[11px] font-medium text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded">
                    {age} yrs
                  </span>
                )}
              </div>
              <div className="relative flex items-center">
                <input
                  id="patient-age"
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  placeholder="Enter age (e.g. 35)"
                  value={age === '' ? '' : age}
                  onChange={(e) => handleAgeChange(e.target.value)}
                  onWheel={(e) => (e.target as HTMLElement).blur()}
                  className={`w-full min-h-[44px] pl-3.5 pr-18 py-2.5 bg-white border rounded-xl text-sm text-slate-900 placeholder:text-slate-400 font-medium transition-all ${
                    errors.age
                      ? 'border-rose-400 ring-2 ring-rose-500/10 focus:border-rose-500'
                      : 'border-slate-300 hover:border-slate-400 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15'
                  } focus:outline-hidden`}
                />

                {/* Touch Stepper +/- buttons */}
                <div className="absolute right-1.5 flex items-center gap-0.5">
                  <button
                    type="button"
                    onClick={() => adjustAge(-1)}
                    disabled={typeof age === 'number' && age <= 0}
                    className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors disabled:opacity-40"
                    title="Decrease Age"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => adjustAge(1)}
                    disabled={typeof age === 'number' && age >= 130}
                    className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors disabled:opacity-40"
                    title="Increase Age"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              {errors.age ? (
                <p className="text-[11px] text-rose-600 mt-1 font-medium">{errors.age}</p>
              ) : (
                <p className="text-[11px] text-slate-500 mt-1">Numeric keypad on mobile, no date picker needed</p>
              )}
            </div>

            {/* Blood Group */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                <Droplet className="w-3.5 h-3.5 text-rose-500" />
                Blood Group
              </label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15 focus:outline-hidden transition-all cursor-pointer"
              >
                <option value="">Unknown / Not Tested</option>
                {BLOOD_GROUPS.map((bg) => (
                  <option key={bg} value={bg}>
                    {bg}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-slate-500 mt-1">ABO / Rh clinical typing</p>
            </div>
          </div>
        </div>

        {/* SECTION 2: Contact Information & Address */}
        <div className="space-y-4 pt-2">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-600" />
              Contact Details & Location
            </h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Primary Phone <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="tel"
                  inputMode="tel"
                  required
                  placeholder="e.g. 9876543210"
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value);
                    if (errors.phone) setErrors((prev) => ({ ...prev, phone: undefined }));
                  }}
                  className={`w-full min-h-[44px] pl-10 pr-3.5 py-2.5 bg-white border rounded-xl text-sm text-slate-900 placeholder:text-slate-400 transition-all ${
                    errors.phone
                      ? 'border-rose-400 ring-2 ring-rose-500/10 focus:border-rose-500'
                      : 'border-slate-300 hover:border-slate-400 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15'
                  } focus:outline-hidden`}
                />
              </div>
              {errors.phone && <p className="text-[11px] text-rose-600 mt-1 font-medium">{errors.phone}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Alternate Phone</label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="tel"
                  inputMode="tel"
                  placeholder="e.g. 9876543211"
                  value={altPhone}
                  onChange={(e) => setAltPhone(e.target.value)}
                  className="w-full min-h-[44px] pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15 focus:outline-hidden transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  placeholder="e.g. patient@gmail.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (errors.email) setErrors((prev) => ({ ...prev, email: undefined }));
                  }}
                  className={`w-full min-h-[44px] pl-10 pr-3.5 py-2.5 bg-white border rounded-xl text-sm text-slate-900 placeholder:text-slate-400 transition-all ${
                    errors.email
                      ? 'border-rose-400 ring-2 ring-rose-500/10 focus:border-rose-500'
                      : 'border-slate-300 hover:border-slate-400 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15'
                  } focus:outline-hidden`}
                />
              </div>
              {errors.email && <p className="text-[11px] text-rose-600 mt-1 font-medium">{errors.email}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Residential Address</label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="House/Flat No., Street, Locality"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full min-h-[44px] pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15 focus:outline-hidden transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">City / Town</label>
              <input
                type="text"
                placeholder="e.g. Mumbai, Delhi"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15 focus:outline-hidden transition-all"
              />
            </div>
          </div>
        </div>

        {/* SECTION 3: Clinical Safety & Medical History */}
        <div className="space-y-4 pt-2">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Shield className="w-4 h-4 text-rose-600" />
              Clinical Alerts & Background
            </h4>
          </div>

          {/* Allergies - Critical Safety Highlight */}
          <div className="p-4 rounded-2xl bg-rose-50/60 border border-rose-200/80">
            <label className="block text-xs font-bold text-rose-800 mb-1 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              Known Drug / Substance Allergies (Safety Alert)
            </label>
            <input
              type="text"
              placeholder="e.g. Penicillin, NSAIDs, Sulfa, Dust, Peanuts (or leave empty if None Known)"
              value={allergies}
              onChange={(e) => setAllergies(e.target.value)}
              className="w-full min-h-[44px] px-3.5 py-2.5 bg-white border border-rose-300 hover:border-rose-400 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:border-rose-600 focus:ring-3 focus:ring-rose-500/20 focus:outline-hidden transition-all"
            />
            <p className="text-[11px] text-rose-700/90 mt-1.5">
              Warning badges will be flagged during prescription writing and dispensing.
            </p>
          </div>

          {/* General Medical Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-slate-500" />
              General Medical Notes & Medical Background
            </label>
            <textarea
              rows={2}
              placeholder="Hypertension, Diabetes Type 2, previous surgeries, family history..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full p-3.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:ring-3 focus:ring-blue-500/15 focus:outline-hidden transition-all resize-none"
            />
          </div>
        </div>

        {/* SECTION 4: Emergency Contact Details */}
        <div className="space-y-4 pt-2">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Heart className="w-4 h-4 text-amber-600" />
              Emergency Contact (Next of Kin)
            </h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-amber-50/40 border border-amber-200/70">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Name & Relation</label>
              <input
                type="text"
                placeholder="e.g. Priya Sharma (Spouse / Mother)"
                value={emergencyContactName}
                onChange={(e) => setEmergencyContactName(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:border-amber-500 focus:ring-3 focus:ring-amber-500/15 focus:outline-hidden transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Emergency Contact Phone</label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="tel"
                  inputMode="tel"
                  placeholder="e.g. 9876543219"
                  value={emergencyContactPhone}
                  onChange={(e) => setEmergencyContactPhone(e.target.value)}
                  className="w-full min-h-[44px] pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 hover:border-slate-400 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:border-amber-500 focus:ring-3 focus:ring-amber-500/15 focus:outline-hidden transition-all"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Modal Sticky Footer Actions */}
        <div className="sticky bottom-0 -mx-6 -mb-6 p-4 sm:px-6 bg-slate-50/95 backdrop-blur-xs border-t border-slate-200 flex items-center justify-between gap-3 rounded-b-2xl">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 text-xs sm:text-sm font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-100 hover:text-slate-900 transition-colors shadow-2xs"
          >
            Cancel
          </button>

          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center gap-2 px-6 py-2.5 text-xs sm:text-sm font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 active:bg-blue-800 transition-all shadow-xs disabled:opacity-50"
          >
            {loading && <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />}
            {patientToEdit ? 'Save Changes' : 'Create Patient Record'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
