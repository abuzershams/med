import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  Search,
  Plus,
  Download,
  Upload,
  Trash2,
  Edit,
  Eye,
  Filter,
  X,
  Phone,
  AlertTriangle,
  User,
  ChevronRight,
} from 'lucide-react';
import Papa from 'papaparse';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { logActivity } from '../../services/auditService';
import { getNextPatientCode } from '../../services/counterService';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { Pagination } from '../../components/common/Pagination';
import { EmptyState, LoadingSpinner } from '../../components/common/EmptyState';
import { PatientModal } from './PatientModal';
import type { Patient } from '../../types';

export const PatientsPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, checkPermission } = useAuth();
  const { success, error, warning } = useToast();

  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [genderFilter, setGenderFilter] = useState<string>('All');

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [patientToEdit, setPatientToEdit] = useState<Patient | null>(null);

  // Delete Confirm Dialog
  const [patientToDelete, setPatientToDelete] = useState<Patient | null>(null);
  const [deleteWarningMsg, setDeleteWarningMsg] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchPatients = async () => {
    setLoading(true);
    try {
      const all = await db.patients.toArray();
      // Sort newest first
      all.sort((a, b) => (b.id || 0) - (a.id || 0));
      setPatients(all);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPatients();
  }, []);

  // Filter & Search
  const filteredPatients = useMemo(() => {
    return patients.filter((p) => {
      const matchSearch =
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.patientCode.toLowerCase().includes(search.toLowerCase()) ||
        p.phone.includes(search);

      const matchGender = genderFilter === 'All' || p.gender === genderFilter;
      return matchSearch && matchGender;
    });
  }, [patients, search, genderFilter]);

  // Paginated items
  const paginatedPatients = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredPatients.slice(start, start + pageSize);
  }, [filteredPatients, currentPage, pageSize]);

  // Handle Export CSV
  const handleExportCSV = () => {
    if (patients.length === 0) {
      warning('No patients available to export.');
      return;
    }

    const exportRows = patients.map((p) => ({
      'Patient ID': p.patientCode,
      'Full Name': p.name,
      Gender: p.gender,
      Age: p.age || '',
      Phone: p.phone,
      'Alt Phone': p.altPhone || '',
      Email: p.email || '',
      'Blood Group': p.bloodGroup || '',
      Allergies: p.allergies || '',
      City: p.city || '',
      Address: p.address || '',
      'Emergency Contact': p.emergencyContactName || '',
      'Emergency Phone': p.emergencyContactPhone || '',
      Notes: p.notes || '',
      'Registration Date': p.createdAt,
    }));

    const csv = Papa.unparse(exportRows);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `patients_export_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    success('Patients exported to CSV successfully!');
  };

  // Handle Import CSV
  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        const rows = results.data as any[];
        if (!rows || rows.length === 0) {
          error('CSV file is empty or formatted incorrectly.');
          return;
        }

        let importedCount = 0;
        let skippedCount = 0;
        const now = new Date().toISOString();

        for (const row of rows) {
          const name = row['Full Name'] || row['Name'] || row['name'];
          const phone = row['Phone'] || row['phone'];

          if (!name || !phone) {
            skippedCount++;
            continue;
          }

          const patientCode = await getNextPatientCode();
          await db.patients.add({
            patientCode,
            name: String(name).trim(),
            gender: row['Gender'] === 'Female' ? 'Female' : row['Gender'] === 'Other' ? 'Other' : 'Male',
            age: Number(row['Age']) || undefined,
            phone: String(phone).trim(),
            altPhone: row['Alt Phone'] ? String(row['Alt Phone']).trim() : undefined,
            email: row['Email'] ? String(row['Email']).trim() : undefined,
            bloodGroup: row['Blood Group'] || undefined,
            allergies: row['Allergies'] || undefined,
            city: row['City'] || undefined,
            address: row['Address'] || undefined,
            notes: row['Notes'] || undefined,
            createdAt: now,
            updatedAt: now,
          });
          importedCount++;
        }

        await fetchPatients();
        await logActivity(
          user?.username || 'Staff',
          user?.role || 'staff',
          'Import Patients',
          'Patients',
          `Imported ${importedCount} patients from CSV (${skippedCount} skipped)`
        );

        success(`Successfully imported ${importedCount} patients (${skippedCount} rows skipped).`);
        if (fileInputRef.current) fileInputRef.current.value = '';
      },
      error: (err) => {
        error(`Failed to parse CSV: ${err.message}`);
      },
    });
  };

  // Check before initiating delete
  const confirmDeletePatient = async (p: Patient) => {
    const invoiceCount = await db.invoices.where('patientId').equals(p.id!).count();
    let msg = `Are you sure you want to permanently delete patient ${p.patientCode} (${p.name})?`;
    if (invoiceCount > 0) {
      msg = `WARNING: This patient has ${invoiceCount} linked invoice(s) in billing!\nDeleting this patient may orphan their financial invoices.\n\nAre you sure you want to proceed?`;
    }
    setDeleteWarningMsg(msg);
    setPatientToDelete(p);
  };

  const executeDelete = async () => {
    if (!patientToDelete || !patientToDelete.id) return;
    try {
      await db.patients.delete(patientToDelete.id);
      await logActivity(
        user?.username || 'Staff',
        user?.role || 'staff',
        'Delete Patient',
        'Patients',
        `Deleted patient record ${patientToDelete.patientCode} (${patientToDelete.name})`
      );
      success(`Patient ${patientToDelete.patientCode} deleted.`);
      setPatientToDelete(null);
      await fetchPatients();
    } catch (err: any) {
      error(err.message || 'Failed to delete patient');
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Users className="w-6 h-6 text-blue-600" />
              Patient Directory
            </h1>
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
              {patients.length} Total
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage comprehensive clinical patient histories and profiles
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* CSV Import */}
          <input
            type="file"
            ref={fileInputRef}
            accept=".csv"
            onChange={handleImportCSV}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-2xs transition-colors min-h-[40px]"
            title="Import patients from CSV"
          >
            <Upload className="w-3.5 h-3.5 text-slate-500" />
            Import CSV
          </button>

          {/* CSV Export */}
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-2xs transition-colors min-h-[40px]"
            title="Export all patients to CSV"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            Export CSV
          </button>

          {/* New Patient Button */}
          {checkPermission('patients') && (
            <button
              onClick={() => {
                setPatientToEdit(null);
                setIsModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 active:bg-blue-800 shadow-xs transition-colors min-h-[40px]"
            >
              <Plus className="w-4 h-4" />
              New Patient
            </button>
          )}
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
        <div className="relative flex-1 w-full sm:max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by name, ID (PT-0001) or phone..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full min-h-[42px] pl-10 pr-9 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all placeholder:text-slate-400"
          />
          {search && (
            <button
              type="button"
              onClick={() => {
                setSearch('');
                setCurrentPage(1);
              }}
              className="p-1 rounded-md text-slate-400 hover:text-slate-600 absolute right-2.5 top-1/2 -translate-y-1/2 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Gender Filter Segmented Controls */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl w-full sm:w-auto overflow-x-auto">
          {(['All', 'Male', 'Female', 'Other'] as const).map((g) => (
            <button
              key={g}
              type="button"
              onClick={() => {
                setGenderFilter(g);
                setCurrentPage(1);
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all shrink-0 min-h-[34px] ${
                genderFilter === g
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              {g === 'All' ? 'All Genders' : g}
            </button>
          ))}
        </div>
      </div>

      {/* Patients Table & Mobile Cards */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {loading ? (
          <LoadingSpinner message="Loading patients from local database..." />
        ) : filteredPatients.length === 0 ? (
          <div className="p-8">
            <EmptyState
              icon={Users}
              title={search ? 'No matching patients found' : 'No patients registered yet'}
              description={
                search
                  ? `No patient records matched "${search}". Try adjusting your keywords.`
                  : 'Start by clicking New Patient to register your first patient.'
              }
              actionLabel={!search && checkPermission('patients') ? 'Add First Patient' : undefined}
              onAction={() => {
                setPatientToEdit(null);
                setIsModalOpen(true);
              }}
            />
          </div>
        ) : (
          <div>
            {/* Desktop Table View (hidden on small mobile screens < 640px) */}
            <div className="hidden sm:block overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 text-[11px] font-semibold uppercase tracking-wider">
                    <th className="py-3.5 px-4">Patient ID</th>
                    <th className="py-3.5 px-4">Patient Name</th>
                    <th className="py-3.5 px-4">Gender & Age</th>
                    <th className="py-3.5 px-4">Phone Number</th>
                    <th className="py-3.5 px-4">Blood Group</th>
                    <th className="py-3.5 px-4">Allergies</th>
                    <th className="py-3.5 px-4">City</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {paginatedPatients.map((patient) => (
                    <tr
                      key={patient.id}
                      onClick={() => navigate(`/patients/${patient.id}`)}
                      className="hover:bg-blue-50/40 cursor-pointer transition-colors group"
                    >
                      <td className="py-3.5 px-4 font-mono font-bold text-blue-600">
                        {patient.patientCode}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900 group-hover:text-blue-700 transition-colors">
                          {patient.name}
                        </div>
                        {patient.email && <div className="text-[11px] text-slate-400">{patient.email}</div>}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">
                        {patient.gender} {patient.age ? `· ${patient.age}y` : ''}
                      </td>
                      <td className="py-3.5 px-4 font-medium text-slate-800">{patient.phone}</td>
                      <td className="py-3.5 px-4">
                        {patient.bloodGroup ? (
                          <span className="font-semibold text-xs text-rose-700">
                            {patient.bloodGroup}
                          </span>
                        ) : (
                          <span className="text-slate-300">-</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 max-w-xs truncate">
                        {patient.allergies ? (
                          <span className="text-rose-600 font-medium flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 shrink-0" />
                            {patient.allergies}
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">None</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">{patient.city || '-'}</td>
                      <td
                        className="py-3.5 px-4 text-right space-x-1"
                        onClick={(e) => e.stopPropagation()} // Stop row click
                      >
                        <button
                          type="button"
                          onClick={() => navigate(`/patients/${patient.id}`)}
                          className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors inline-flex items-center justify-center min-w-[36px] min-h-[36px]"
                          title="View Full Profile"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {checkPermission('patients') && (
                          <button
                            type="button"
                            onClick={() => {
                              setPatientToEdit(patient);
                              setIsModalOpen(true);
                            }}
                            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors inline-flex items-center justify-center min-w-[36px] min-h-[36px]"
                            title="Edit Patient"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        )}
                        {(user?.role === 'admin' || user?.role === 'doctor') && (
                          <button
                            type="button"
                            onClick={() => confirmDeletePatient(patient)}
                            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors inline-flex items-center justify-center min-w-[36px] min-h-[36px]"
                            title="Delete Patient Record"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Card List View (optimized for screens < 640px, 360px+) */}
            <div className="block sm:hidden divide-y divide-slate-100">
              {paginatedPatients.map((patient) => (
                <div
                  key={patient.id}
                  onClick={() => navigate(`/patients/${patient.id}`)}
                  className="p-4 hover:bg-slate-50 active:bg-blue-50/50 transition-colors flex items-center justify-between gap-3"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-blue-600">
                        {patient.patientCode}
                      </span>
                      {patient.bloodGroup && (
                        <span className="text-[11px] font-bold text-rose-600">
                          {patient.bloodGroup}
                        </span>
                      )}
                    </div>
                    <h3 className="font-semibold text-slate-900 text-sm truncate mt-0.5">
                      {patient.name}
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                      <span>{patient.gender}</span>
                      {patient.age && (
                        <>
                          <span>·</span>
                          <span>{patient.age} yrs</span>
                        </>
                      )}
                      <span>·</span>
                      <span className="font-medium text-slate-700">{patient.phone}</span>
                    </div>
                    {patient.allergies && (
                      <div className="flex items-center gap-1 text-[11px] text-rose-600 mt-1 truncate">
                        <AlertTriangle className="w-3 h-3 shrink-0" />
                        <span>Allergy: {patient.allergies}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                    {checkPermission('patients') && (
                      <button
                        type="button"
                        onClick={() => {
                          setPatientToEdit(patient);
                          setIsModalOpen(true);
                        }}
                        className="p-2.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl"
                        title="Edit Patient"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => navigate(`/patients/${patient.id}`)}
                      className="p-2.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl"
                      title="View Profile"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Pagination Controls */}
            <Pagination
              currentPage={currentPage}
              totalItems={filteredPatients.length}
              pageSize={pageSize}
              onPageChange={setCurrentPage}
              onPageSizeChange={(newSize) => {
                setPageSize(newSize);
                setCurrentPage(1);
              }}
            />
          </div>
        )}
      </div>

      {/* Patient Register/Edit Modal */}
      <PatientModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        patientToEdit={patientToEdit}
        onSaved={fetchPatients}
      />

      {/* Delete Confirmation Modal */}
      <ConfirmDialog
        isOpen={Boolean(patientToDelete)}
        title="Delete Patient Record"
        message={deleteWarningMsg}
        confirmLabel="Yes, Delete Patient"
        cancelLabel="Cancel"
        variant="danger"
        iconType="trash"
        onConfirm={executeDelete}
        onCancel={() => setPatientToDelete(null)}
      />
    </div>
  );
};
