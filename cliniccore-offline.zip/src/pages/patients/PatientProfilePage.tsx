import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Users,
  Calendar,
  Activity,
  Stethoscope,
  FileText,
  Receipt,
  FolderOpen,
  HeartPulse,
  History,
  CreditCard,
  Printer,
  Edit,
  Plus,
  Phone,
  Mail,
  MapPin,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Share2,
  DollarSign,
  MessageCircle,
} from 'lucide-react';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { Badge, StatusBadge } from '../../components/common/Badge';
import { PrintPreviewModal } from '../../print/PrintPreviewModal';
import { PatientCardPrint } from '../../print/PatientCardPrint';
import { PrescriptionPrint } from '../../print/PrescriptionPrint';
import { generatePrescriptionPDF } from '../../print/pdfGenerator';
import { PatientModal } from './PatientModal';
import { AppointmentModal } from '../appointments/AppointmentModal';
import { VitalsModal } from '../vitals/VitalsModal';
import { ConsultationModal } from '../consultations/ConsultationModal';
import { InvoiceEditorModal } from '../billing/InvoiceEditorModal';
import { PaymentModal } from '../billing/PaymentModal';
import { DocumentsTab } from '../documents/DocumentsTab';
import type {
  Patient,
  Appointment,
  Vitals,
  Consultation,
  Prescription,
  Invoice,
  Payment,
  FollowUp,
} from '../../types';

export const PatientProfilePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { settings, formatCurrency, formatDate, formatDateTime } = useClinic();
  const { checkPermission } = useAuth();
  const { success, error } = useToast();

  const [patient, setPatient] = useState<Patient | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<
    'overview' | 'appointments' | 'vitals' | 'consultations' | 'prescriptions' | 'billing' | 'documents' | 'followups' | 'timeline'
  >('overview');

  // Related Patient Data
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [vitalsList, setVitalsList] = useState<Vitals[]>([]);
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [followups, setFollowups] = useState<FollowUp[]>([]);

  // Modals
  const [isEditPatientOpen, setIsEditPatientOpen] = useState(false);
  const [isApptModalOpen, setIsApptModalOpen] = useState(false);
  const [isVitalsModalOpen, setIsVitalsModalOpen] = useState(false);
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  const [selectedInvoiceForPayment, setSelectedInvoiceForPayment] = useState<Invoice | null>(null);

  // Print Patient Card Modal
  const [isCardPrintOpen, setIsCardPrintOpen] = useState(false);

  // Print Prescription Modal
  const [previewRx, setPreviewRx] = useState<Prescription | null>(null);

  const fetchAllPatientData = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const pId = Number(id);
      const p = await db.patients.get(pId);
      if (!p) {
        error('Patient not found.');
        navigate('/patients');
        return;
      }
      setPatient(p);

      const [appts, vts, cons, rxs, invs, pmts, flws] = await Promise.all([
        db.appointments.where('patientId').equals(pId).toArray(),
        db.vitals.where('patientId').equals(pId).toArray(),
        db.consultations.where('patientId').equals(pId).toArray(),
        db.prescriptions.where('patientId').equals(pId).toArray(),
        db.invoices.where('patientId').equals(pId).toArray(),
        db.payments.where('patientId').equals(pId).toArray(),
        db.follow_ups.where('patientId').equals(pId).toArray(),
      ]);

      setAppointments(appts.sort((a, b) => b.date.localeCompare(a.date)));
      setVitalsList(vts.sort((a, b) => b.date.localeCompare(a.date)));
      setConsultations(cons.sort((a, b) => b.date.localeCompare(a.date)));
      setPrescriptions(rxs.sort((a, b) => b.date.localeCompare(a.date)));
      setInvoices(invs.sort((a, b) => b.date.localeCompare(a.date)));
      setPayments(pmts.sort((a, b) => b.date.localeCompare(a.date)));
      setFollowups(flws.sort((a, b) => b.followUpDate.localeCompare(a.followUpDate)));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllPatientData();
  }, [id]);

  if (loading || !patient) {
    return <div className="p-12 text-center text-slate-500 font-medium">Loading patient file...</div>;
  }

  // Financial Summary
  const totalBilled = invoices.reduce((sum, i) => sum + (i.grandTotal || 0), 0);
  const totalPaid = invoices.reduce((sum, i) => sum + (i.amountPaid || 0), 0);
  const totalBalanceDue = Math.max(0, totalBilled - totalPaid);

  // Latest Vitals
  const latestVitals = vitalsList[0];

  // Combined Chronological Timeline
  const timelineEvents: { type: string; date: string; title: string; subtitle: string; icon: any; color: string }[] = [];

  appointments.forEach((a) => {
    timelineEvents.push({
      type: 'Appointment',
      date: a.date,
      title: `Appointment with ${a.doctorName}`,
      subtitle: `${a.time} • Status: ${a.status} (Token #${a.tokenNumber})`,
      icon: Calendar,
      color: 'bg-emerald-500 text-white',
    });
  });

  vitalsList.forEach((v) => {
    timelineEvents.push({
      type: 'Vitals',
      date: v.date,
      title: 'Physiological Vitals Recorded',
      subtitle: `BP: ${v.bloodPressureSystolic || '-'}/${v.bloodPressureDiastolic || '-'} mmHg • Pulse: ${v.pulseBpm || '-'} bpm • Wt: ${v.weightKg || '-'} kg (BMI: ${v.bmi || '-'})`,
      icon: Activity,
      color: 'bg-blue-500 text-white',
    });
  });

  consultations.forEach((c) => {
    timelineEvents.push({
      type: 'Consultation',
      date: c.date,
      title: `Diagnosis: ${c.diagnosis}`,
      subtitle: `Dr. ${c.doctorName} • Complaint: ${c.chiefComplaint}`,
      icon: Stethoscope,
      color: 'bg-purple-500 text-white',
    });
  });

  prescriptions.forEach((rx) => {
    timelineEvents.push({
      type: 'Prescription',
      date: rx.date,
      title: `Prescription for ${rx.diagnosis}`,
      subtitle: `${rx.medicines.length} medicine(s) prescribed by ${rx.doctorName}`,
      icon: FileText,
      color: 'bg-pink-500 text-white',
    });
  });

  payments.forEach((p) => {
    timelineEvents.push({
      type: 'Payment',
      date: p.date,
      title: `Payment Received: ${formatCurrency(p.amount)}`,
      subtitle: `Method: ${p.method} • Invoice: ${p.invoiceNumber || 'General'}`,
      icon: CreditCard,
      color: 'bg-teal-500 text-white',
    });
  });

  followups.forEach((f) => {
    timelineEvents.push({
      type: 'Follow-up',
      date: f.followUpDate,
      title: `Follow-up Scheduled: ${f.reason}`,
      subtitle: `Status: ${f.isDone ? 'Completed' : 'Pending'}`,
      icon: HeartPulse,
      color: 'bg-amber-500 text-white',
    });
  });

  timelineEvents.sort((a, b) => b.date.localeCompare(a.date));

  // WhatsApp Reminder Link Helper
  const getWhatsAppLink = (appt: Appointment) => {
    const text = encodeURIComponent(
      `Hello ${patient.name}, this is a gentle appointment confirmation from ${settings?.clinicName || 'our clinic'} for your visit with ${appt.doctorName} on ${appt.date} at ${appt.time} (Token #${appt.tokenNumber}). Thank you!`
    );
    const cleanPhone = patient.phone.replace(/[^0-9]/g, '');
    return `https://wa.me/${cleanPhone.length === 10 ? '91' + cleanPhone : cleanPhone}?text=${text}`;
  };

  return (
    <div className="space-y-6">
      {/* Patient Header Card */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xs p-6">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-20 h-20 rounded-2xl bg-slate-100 border border-slate-300 overflow-hidden flex items-center justify-center shrink-0 text-slate-400 font-bold text-2xl shadow-inner">
              {patient.photoBase64 ? (
                <img src={patient.photoBase64} alt={patient.name} className="w-full h-full object-cover" />
              ) : (
                patient.name.charAt(0)
              )}
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{patient.name}</h1>
                <span className="px-2.5 py-0.5 rounded-md font-mono text-xs font-bold bg-blue-100 text-blue-700">
                  {patient.patientCode}
                </span>
                {patient.bloodGroup && (
                  <span className="px-2 py-0.5 rounded-md text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                    {patient.bloodGroup}
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-4 mt-2 text-xs text-slate-600">
                <span>
                  {patient.gender} {patient.age ? `• ${patient.age} yrs` : ''}
                </span>
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  {patient.phone}
                </span>
                {patient.email && (
                  <span className="flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    {patient.email}
                  </span>
                )}
                {patient.city && (
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {patient.city}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Quick Balance & Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto justify-end">
            <button
              onClick={() => setIsCardPrintOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-2xs transition-colors"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              Print Card
            </button>

            <button
              onClick={() => setIsApptModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-2xs transition-colors"
            >
              <Calendar className="w-3.5 h-3.5 text-emerald-600" />
              New Appt
            </button>

            <button
              onClick={() => navigate(`/prescriptions/new?patientId=${patient.id}`)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-2xs transition-colors"
            >
              <FileText className="w-3.5 h-3.5 text-purple-600" />
              Prescribe
            </button>

            <button
              onClick={() => setIsInvoiceModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 shadow-2xs transition-colors"
            >
              <Receipt className="w-3.5 h-3.5 text-amber-600" />
              New Invoice
            </button>

            <button
              onClick={() => setIsEditPatientOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-xl transition-colors"
            >
              <Edit className="w-3.5 h-3.5" />
              Edit Profile
            </button>
          </div>
        </div>

        {/* High-Visibility Allergy Alert Banner */}
        {patient.allergies && (
          <div className="mt-5 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-2.5 text-xs">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <p>
              <strong className="font-bold">CRITICAL ALLERGIES: </strong> {patient.allergies}
            </p>
          </div>
        )}

        {/* Mini Financial Summary Strip */}
        <div className="grid grid-cols-3 gap-3 mt-5 pt-4 border-t border-slate-100 text-center">
          <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Billed</span>
            <p className="text-sm font-bold text-slate-900 mt-0.5">{formatCurrency(totalBilled)}</p>
          </div>
          <div className="p-2.5 bg-emerald-50/60 rounded-xl border border-emerald-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">Total Paid</span>
            <p className="text-sm font-bold text-emerald-700 mt-0.5">{formatCurrency(totalPaid)}</p>
          </div>
          <div className={`p-2.5 rounded-xl border ${totalBalanceDue > 0 ? 'bg-rose-50 border-rose-200' : 'bg-slate-50 border-slate-100'}`}>
            <span className={`text-[10px] font-bold uppercase tracking-wider ${totalBalanceDue > 0 ? 'text-rose-600' : 'text-slate-400'}`}>
              Balance Due
            </span>
            <p className={`text-sm font-bold mt-0.5 ${totalBalanceDue > 0 ? 'text-rose-600' : 'text-slate-800'}`}>
              {formatCurrency(totalBalanceDue)}
            </p>
          </div>
        </div>
      </div>

      {/* 9 Tab Navigation Strip */}
      <div className="flex items-center gap-1 overflow-x-auto pb-2 border-b border-slate-200">
        {[
          { id: 'overview', label: 'Overview', icon: Users },
          { id: 'appointments', label: `Appointments (${appointments.length})`, icon: Calendar },
          { id: 'vitals', label: `Vitals (${vitalsList.length})`, icon: Activity },
          { id: 'consultations', label: `Consultations (${consultations.length})`, icon: Stethoscope },
          { id: 'prescriptions', label: `Prescriptions (${prescriptions.length})`, icon: FileText },
          { id: 'billing', label: `Billing & Ledger (${invoices.length})`, icon: Receipt },
          { id: 'documents', label: 'Documents & Scans', icon: FolderOpen },
          { id: 'followups', label: `Follow-ups (${followups.length})`, icon: HeartPulse },
          { id: 'timeline', label: `Timeline (${timelineEvents.length})`, icon: History },
        ].map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Latest Vitals Card */}
            <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-4 pb-2 border-b">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Activity className="w-4 h-4 text-blue-600" />
                    Latest Recorded Vitals
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {latestVitals ? `Recorded on ${latestVitals.date} at ${latestVitals.time} by ${latestVitals.recordedBy}` : 'No vitals recorded yet'}
                  </p>
                </div>
                <button
                  onClick={() => setIsVitalsModalOpen(true)}
                  className="px-3 py-1.5 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                >
                  Record Vitals
                </button>
              </div>

              {latestVitals ? (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Blood Pressure</span>
                    <span className="text-base font-bold text-slate-900 mt-1 block">
                      {latestVitals.bloodPressureSystolic || '-'}/{latestVitals.bloodPressureDiastolic || '-'} <span className="text-xs font-normal text-slate-500">mmHg</span>
                    </span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Heart Pulse</span>
                    <span className="text-base font-bold text-slate-900 mt-1 block">
                      {latestVitals.pulseBpm || '-'} <span className="text-xs font-normal text-slate-500">bpm</span>
                    </span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Body Mass Index</span>
                    <span className="text-base font-bold text-blue-700 mt-1 block">
                      {latestVitals.bmi || '-'} <span className="text-xs font-normal text-slate-500">kg/m²</span>
                    </span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Oxygen SpO2</span>
                    <span className="text-base font-bold text-slate-900 mt-1 block">
                      {latestVitals.spo2Percent ? `${latestVitals.spo2Percent}%` : '-'}
                    </span>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-slate-400 text-center py-6">No vitals metrics logged yet.</p>
              )}
            </div>

            {/* Latest Consultation Note */}
            <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-3 pb-2 border-b">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Stethoscope className="w-4 h-4 text-purple-600" />
                  Latest Consultation Note
                </h3>
                <button
                  onClick={() => setIsConsultationModalOpen(true)}
                  className="px-3 py-1.5 text-xs font-semibold text-purple-600 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors"
                >
                  New Consultation
                </button>
              </div>

              {consultations.length > 0 ? (
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-500">
                    <span>Date: {consultations[0].date}</span>
                    <span>Doctor: {consultations[0].doctorName}</span>
                  </div>
                  <p className="text-sm font-bold text-blue-900">Diagnosis: {consultations[0].diagnosis}</p>
                  <p className="text-slate-700 leading-relaxed">
                    <strong className="font-semibold">Chief Complaint:</strong> {consultations[0].chiefComplaint}
                  </p>
                  {consultations[0].advice && (
                    <p className="text-slate-600 italic">Advice: {consultations[0].advice}</p>
                  )}
                </div>
              ) : (
                <p className="text-xs text-slate-400 text-center py-6">No clinical consultation notes written yet.</p>
              )}
            </div>
          </div>

          {/* Sidebar Patient Bio & Contacts */}
          <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-4 text-xs">
            <h3 className="text-sm font-bold text-slate-900 border-b pb-2">Patient Bio & Records</h3>

            <div>
              <span className="text-slate-400 uppercase text-[10px] block font-bold">Registered On</span>
              <span className="text-slate-800 font-medium">{formatDate(patient.createdAt)}</span>
            </div>

            <div>
              <span className="text-slate-400 uppercase text-[10px] block font-bold">Emergency Contact</span>
              <span className="text-slate-800 font-medium">
                {patient.emergencyContactName ? `${patient.emergencyContactName} (${patient.emergencyContactPhone || 'N/A'})` : 'None specified'}
              </span>
            </div>

            <div>
              <span className="text-slate-400 uppercase text-[10px] block font-bold">Residential Address</span>
              <span className="text-slate-800 font-medium">
                {patient.address ? `${patient.address}, ${patient.city || ''}` : 'Not recorded'}
              </span>
            </div>

            <div>
              <span className="text-slate-400 uppercase text-[10px] block font-bold">General Clinical Notes</span>
              <p className="text-slate-600 italic mt-0.5 whitespace-pre-line">
                {patient.notes || 'No general clinical notes added.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: APPOINTMENTS */}
      {activeTab === 'appointments' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center pb-2 border-b">
            <h3 className="text-sm font-bold text-slate-900">Appointment History ({appointments.length})</h3>
            <button
              onClick={() => setIsApptModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              Book Appointment
            </button>
          </div>

          {appointments.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-10">No appointments recorded for this patient.</p>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b text-[11px] uppercase font-semibold text-slate-500">
                  <tr>
                    <th className="py-2.5 px-4">Token</th>
                    <th className="py-2.5 px-4">Date & Time</th>
                    <th className="py-2.5 px-4">Doctor</th>
                    <th className="py-2.5 px-4">Reason</th>
                    <th className="py-2.5 px-4">Status</th>
                    <th className="py-2.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {appointments.map((appt) => (
                    <tr key={appt.id} className="hover:bg-slate-50/50">
                      <td className="py-2.5 px-4 font-bold text-blue-600">#{appt.tokenNumber}</td>
                      <td className="py-2.5 px-4 font-medium text-slate-800">
                        {appt.date} at {appt.time}
                      </td>
                      <td className="py-2.5 px-4 text-slate-700">{appt.doctorName}</td>
                      <td className="py-2.5 px-4 text-slate-600">{appt.reason || '-'}</td>
                      <td className="py-2.5 px-4">
                        <StatusBadge status={appt.status} />
                      </td>
                      <td className="py-2.5 px-4 text-right">
                        {patient.phone && (
                          <a
                            href={getWhatsAppLink(appt)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors border border-emerald-200"
                            title="Send WhatsApp confirmation message"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            WhatsApp
                          </a>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: VITALS */}
      {activeTab === 'vitals' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center pb-2 border-b">
            <h3 className="text-sm font-bold text-slate-900">Vitals History Log ({vitalsList.length})</h3>
            <button
              onClick={() => setIsVitalsModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              Record Vitals
            </button>
          </div>

          {vitalsList.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-10">No vitals logged for this patient yet.</p>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b text-[11px] uppercase font-semibold text-slate-500">
                  <tr>
                    <th className="py-2.5 px-4">Date / Time</th>
                    <th className="py-2.5 px-4">BP (mmHg)</th>
                    <th className="py-2.5 px-4">Pulse</th>
                    <th className="py-2.5 px-4">Weight & Height</th>
                    <th className="py-2.5 px-4">BMI</th>
                    <th className="py-2.5 px-4">Temp (°F)</th>
                    <th className="py-2.5 px-4">SpO2</th>
                    <th className="py-2.5 px-4">Sugar</th>
                    <th className="py-2.5 px-4">Logged By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {vitalsList.map((v) => (
                    <tr key={v.id} className="hover:bg-slate-50/50">
                      <td className="py-2.5 px-4 font-medium text-slate-900">
                        {v.date} {v.time}
                      </td>
                      <td className="py-2.5 px-4 font-bold text-slate-800">
                        {v.bloodPressureSystolic && v.bloodPressureDiastolic
                          ? `${v.bloodPressureSystolic}/${v.bloodPressureDiastolic}`
                          : '-'}
                      </td>
                      <td className="py-2.5 px-4">{v.pulseBpm ? `${v.pulseBpm} bpm` : '-'}</td>
                      <td className="py-2.5 px-4">
                        {v.weightKg ? `${v.weightKg} kg` : '-'} / {v.heightCm ? `${v.heightCm} cm` : '-'}
                      </td>
                      <td className="py-2.5 px-4 font-bold text-blue-700">{v.bmi || '-'}</td>
                      <td className="py-2.5 px-4">{v.temperatureF ? `${v.temperatureF}°F` : '-'}</td>
                      <td className="py-2.5 px-4">{v.spo2Percent ? `${v.spo2Percent}%` : '-'}</td>
                      <td className="py-2.5 px-4">{v.bloodSugarMgDl ? `${v.bloodSugarMgDl} mg/dL` : '-'}</td>
                      <td className="py-2.5 px-4 text-slate-500">{v.recordedBy}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: CONSULTATIONS */}
      {activeTab === 'consultations' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center pb-2 border-b">
            <h3 className="text-sm font-bold text-slate-900">Clinical Consultations ({consultations.length})</h3>
            <button
              onClick={() => setIsConsultationModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              New Consultation Note
            </button>
          </div>

          {consultations.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-10">No consultations logged for this patient yet.</p>
          ) : (
            <div className="space-y-3">
              {consultations.map((c) => (
                <div key={c.id} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs text-xs space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b">
                    <div>
                      <span className="text-[11px] text-slate-400 font-medium">Date: {c.date}</span>
                      <h4 className="text-sm font-bold text-blue-900">Diagnosis: {c.diagnosis}</h4>
                    </div>
                    <span className="text-slate-600 font-semibold">{c.doctorName}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-700">
                    <div>
                      <strong className="text-slate-900 block mb-0.5">Chief Complaint:</strong>
                      <p>{c.chiefComplaint}</p>
                    </div>
                    {c.symptoms && (
                      <div>
                        <strong className="text-slate-900 block mb-0.5">Symptoms:</strong>
                        <p>{c.symptoms}</p>
                      </div>
                    )}
                    {c.examination && (
                      <div>
                        <strong className="text-slate-900 block mb-0.5">Physical Examination:</strong>
                        <p>{c.examination}</p>
                      </div>
                    )}
                    {c.treatmentPlan && (
                      <div>
                        <strong className="text-slate-900 block mb-0.5">Treatment Plan:</strong>
                        <p>{c.treatmentPlan}</p>
                      </div>
                    )}
                  </div>

                  {c.advice && (
                    <div className="p-2.5 bg-slate-50 rounded-lg text-slate-600 italic">
                      Advice: {c.advice}
                    </div>
                  )}

                  {c.followUpDate && (
                    <p className="text-pink-700 font-bold text-[11px]">Next Follow-up Due: {c.followUpDate}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: PRESCRIPTIONS */}
      {activeTab === 'prescriptions' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center pb-2 border-b">
            <h3 className="text-sm font-bold text-slate-900">Prescription Records ({prescriptions.length})</h3>
            <button
              onClick={() => navigate(`/prescriptions/new?patientId=${patient.id}`)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              Write Prescription
            </button>
          </div>

          {prescriptions.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-10">No prescriptions written for this patient yet.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {prescriptions.map((rx) => (
                <div key={rx.id} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs text-xs space-y-3 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between pb-2 border-b">
                      <div>
                        <span className="text-[11px] text-slate-400">{rx.date}</span>
                        <h4 className="text-sm font-bold text-slate-900">{rx.diagnosis}</h4>
                      </div>
                      <span className="font-semibold text-blue-700 text-xs">{rx.doctorName}</span>
                    </div>

                    <div className="mt-3 space-y-1.5">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        Prescribed Medicines ({rx.medicines.length})
                      </p>
                      <ul className="divide-y divide-slate-100">
                        {rx.medicines.map((m, idx) => (
                          <li key={idx} className="py-1.5 flex justify-between items-start">
                            <div>
                              <span className="font-bold text-slate-800">{m.name}</span>
                              <span className="text-[11px] text-slate-500 block">
                                {m.dose} • {m.frequency} • {m.duration} ({m.timing})
                              </span>
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="pt-3 border-t flex justify-end gap-2">
                    <button
                      onClick={() => setPreviewRx(rx)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      View & Print Rx
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 6: BILLING & LEDGER */}
      {activeTab === 'billing' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center pb-2 border-b">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Invoices & Financial Ledger</h3>
              <p className="text-xs text-slate-500">
                Outstanding Dues: <span className="font-bold text-rose-600">{formatCurrency(totalBalanceDue)}</span>
              </p>
            </div>
            <button
              onClick={() => setIsInvoiceModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              Create Invoice
            </button>
          </div>

          {/* Invoices Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden text-xs">
            <div className="p-3 bg-slate-50 font-bold text-slate-700 border-b">Invoices ({invoices.length})</div>
            {invoices.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-6">No invoices created for this patient.</p>
            ) : (
              <table className="w-full text-left">
                <thead className="bg-slate-50/50 border-b text-[11px] uppercase font-semibold text-slate-500">
                  <tr>
                    <th className="py-2.5 px-4">Invoice #</th>
                    <th className="py-2.5 px-4">Date</th>
                    <th className="py-2.5 px-4 text-right">Total</th>
                    <th className="py-2.5 px-4 text-right">Paid</th>
                    <th className="py-2.5 px-4 text-right">Balance</th>
                    <th className="py-2.5 px-4 text-center">Status</th>
                    <th className="py-2.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {invoices.map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-50/50">
                      <td className="py-2.5 px-4 font-mono font-bold text-blue-600">{inv.invoiceNumber}</td>
                      <td className="py-2.5 px-4 text-slate-600">{inv.date}</td>
                      <td className="py-2.5 px-4 text-right font-semibold text-slate-900">
                        {formatCurrency(inv.grandTotal)}
                      </td>
                      <td className="py-2.5 px-4 text-right text-emerald-700 font-semibold">
                        {formatCurrency(inv.amountPaid)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-bold text-rose-600">
                        {formatCurrency(inv.balanceDue)}
                      </td>
                      <td className="py-2.5 px-4 text-center">
                        <StatusBadge status={inv.status} />
                      </td>
                      <td className="py-2.5 px-4 text-right space-x-1">
                        {inv.balanceDue > 0 && (
                          <button
                            onClick={() => setSelectedInvoiceForPayment(inv)}
                            className="px-2.5 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors"
                          >
                            Collect Payment
                          </button>
                        )}
                        <button
                          onClick={() => navigate('/invoices')}
                          className="px-2.5 py-1 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Payments Receipt History */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden text-xs">
            <div className="p-3 bg-slate-50 font-bold text-slate-700 border-b">Payment Receipts ({payments.length})</div>
            {payments.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-6">No payments collected yet.</p>
            ) : (
              <table className="w-full text-left">
                <thead className="bg-slate-50/50 border-b text-[11px] uppercase font-semibold text-slate-500">
                  <tr>
                    <th className="py-2.5 px-4">Date & Time</th>
                    <th className="py-2.5 px-4">Invoice #</th>
                    <th className="py-2.5 px-4">Method</th>
                    <th className="py-2.5 px-4 text-right">Amount</th>
                    <th className="py-2.5 px-4">Received By</th>
                    <th className="py-2.5 px-4">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {payments.map((p) => (
                    <tr key={p.id}>
                      <td className="py-2.5 px-4 text-slate-700">{p.date} {p.time}</td>
                      <td className="py-2.5 px-4 font-mono font-medium text-slate-800">{p.invoiceNumber || 'Direct'}</td>
                      <td className="py-2.5 px-4 font-semibold text-slate-700">{p.method}</td>
                      <td className="py-2.5 px-4 text-right font-bold text-emerald-700">{formatCurrency(p.amount)}</td>
                      <td className="py-2.5 px-4 text-slate-600">{p.receivedBy}</td>
                      <td className="py-2.5 px-4 text-slate-500 italic">{p.note || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {/* TAB 7: DOCUMENTS */}
      {activeTab === 'documents' && (
        <DocumentsTab patientId={patient.id!} patientName={patient.name} />
      )}

      {/* TAB 8: FOLLOW-UPS */}
      {activeTab === 'followups' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center pb-2 border-b">
            <h3 className="text-sm font-bold text-slate-900">Follow-up Consultations ({followups.length})</h3>
          </div>

          {followups.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-10">No follow-ups recorded for this patient.</p>
          ) : (
            <div className="space-y-2">
              {followups.map((f) => (
                <div
                  key={f.id}
                  className="p-4 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-4 text-xs"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{f.reason}</span>
                      <Badge variant={f.isDone ? 'success' : 'warning'}>
                        {f.isDone ? 'Completed' : 'Pending'}
                      </Badge>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Due Date: <strong className="text-slate-800">{f.followUpDate}</strong> • Doctor: {f.doctorName || 'Doctor'}
                    </p>
                  </div>

                  {!f.isDone && (
                    <button
                      onClick={async () => {
                        await db.follow_ups.update(f.id!, { isDone: true, doneDate: new Date().toISOString() });
                        success('Follow-up marked as completed.');
                        fetchAllPatientData();
                      }}
                      className="px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors border border-emerald-200"
                    >
                      Mark Done
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 9: CHRONOLOGICAL TIMELINE */}
      {activeTab === 'timeline' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900 pb-2 border-b">
            Complete Medical Timeline ({timelineEvents.length} events)
          </h3>

          {timelineEvents.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-10">No events in this patient's medical timeline.</p>
          ) : (
            <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
              {timelineEvents.map((event, index) => {
                const Icon = event.icon;
                return (
                  <div key={index} className="relative flex items-start gap-3 text-xs">
                    <div className={`absolute -left-6 p-1.5 rounded-full ${event.color} ring-4 ring-white`}>
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-slate-900 text-sm">{event.title}</span>
                        <span className="text-[11px] text-slate-400">{event.date}</span>
                      </div>
                      <p className="text-slate-600">{event.subtitle}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Patient Card Preview Modal */}
      {isCardPrintOpen && (
        <PrintPreviewModal
          isOpen={isCardPrintOpen}
          onClose={() => setIsCardPrintOpen(false)}
          title={`Patient Card: ${patient.patientCode}`}
          documentType="PatientCard"
          onDownloadPdf={async () => {
            // Generates card PDF
            const doc = await generatePrescriptionPDF(
              {
                patientId: patient.id!,
                patientName: patient.name,
                patientCode: patient.patientCode,
                doctorId: 1,
                doctorName: settings?.doctorName || 'Doctor',
                date: new Date().toISOString().split('T')[0],
                diagnosis: `Health Card - ${patient.patientCode}`,
                medicines: [],
                advice: `Blood: ${patient.bloodGroup || 'N/A'}, Phone: ${patient.phone}`,
                createdAt: new Date().toISOString(),
              },
              settings
            );
            doc.save(`patient_card_${patient.patientCode}.pdf`);
          }}
        >
          <PatientCardPrint patient={patient} settings={settings} />
        </PrintPreviewModal>
      )}

      {/* Prescription Preview Modal */}
      {previewRx && (
        <PrintPreviewModal
          isOpen={Boolean(previewRx)}
          onClose={() => setPreviewRx(null)}
          title={`Prescription: ${previewRx.patientName}`}
          documentType="Prescription"
          onDownloadPdf={async () => {
            const doc = await generatePrescriptionPDF(previewRx, settings);
            doc.save(`rx_${previewRx.patientCode}_${previewRx.date}.pdf`);
          }}
        >
          <PrescriptionPrint prescription={previewRx} settings={settings} />
        </PrintPreviewModal>
      )}

      {/* Modals for actions */}
      <PatientModal
        isOpen={isEditPatientOpen}
        onClose={() => setIsEditPatientOpen(false)}
        patientToEdit={patient}
        onSaved={fetchAllPatientData}
      />

      <AppointmentModal
        isOpen={isApptModalOpen}
        onClose={() => setIsApptModalOpen(false)}
        preselectedPatient={patient}
        onSaved={fetchAllPatientData}
      />

      <VitalsModal
        isOpen={isVitalsModalOpen}
        onClose={() => setIsVitalsModalOpen(false)}
        patientId={patient.id!}
        patientName={patient.name}
        onSaved={fetchAllPatientData}
      />

      <ConsultationModal
        isOpen={isConsultationModalOpen}
        onClose={() => setIsConsultationModalOpen(false)}
        patientId={patient.id!}
        patientName={patient.name}
        patientCode={patient.patientCode}
        onSaved={fetchAllPatientData}
      />

      <InvoiceEditorModal
        isOpen={isInvoiceModalOpen}
        onClose={() => setIsInvoiceModalOpen(false)}
        preselectedPatient={patient}
        onSaved={fetchAllPatientData}
      />

      {selectedInvoiceForPayment && (
        <PaymentModal
          isOpen={Boolean(selectedInvoiceForPayment)}
          onClose={() => setSelectedInvoiceForPayment(null)}
          invoice={selectedInvoiceForPayment}
          onSaved={fetchAllPatientData}
        />
      )}
    </div>
  );
};
