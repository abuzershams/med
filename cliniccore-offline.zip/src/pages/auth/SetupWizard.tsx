import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Activity,
  CheckCircle2,
  Stethoscope,
  Building2,
  Lock,
  KeyRound,
  Eye,
  EyeOff,
  Copy,
  Download,
  Upload,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
} from 'lucide-react';
import { setupFirstClinic, generateRecoveryKey } from '../../services/authService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useClinic } from '../../context/ClinicContext';

const DEGREES = ['MBBS', 'MD', 'MS', 'BDS', 'MDS', 'BAMS', 'BHMS', 'BUMS', 'DNB', 'BPT', 'Other'];
const SECURITY_QUESTIONS = [
  'What was the name of your first elementary school?',
  'What was your childhood nickname?',
  'In what city or town did your parents meet?',
  'What is the name of your favorite medical college professor?',
  'What was the model of your first car or bike?',
];

export const SetupWizard: React.FC = () => {
  const navigate = useNavigate();
  const { checkAdminStatus, setSessionUser } = useAuth();
  const { reloadSettings } = useClinic();
  const { success, error } = useToast();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1); // Step 4 is Recovery Key screen
  const [loading, setLoading] = useState(false);

  // Form Fields
  // Step 1: Doctor Profile
  const [doctorName, setDoctorName] = useState('');
  const [degreeOption, setDegreeOption] = useState('MBBS');
  const [customDegree, setCustomDegree] = useState('');
  const [specialization, setSpecialization] = useState('General Medicine');
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [doctorPhone, setDoctorPhone] = useState('');
  const [doctorEmail, setDoctorEmail] = useState('');

  // Step 2: Clinic Profile
  const [clinicName, setClinicName] = useState('');
  const [clinicAddress, setClinicAddress] = useState('');
  const [clinicCity, setClinicCity] = useState('');
  const [clinicPhone, setClinicPhone] = useState('');
  const [workingHours, setWorkingHours] = useState('09:00 AM - 08:00 PM');
  const [consultationFee, setConsultationFee] = useState<number>(500);
  const [logoBase64, setLogoBase64] = useState<string>('');

  // Step 3: Login Details
  const [username, setUsername] = useState('doctor');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [securityQuestion, setSecurityQuestion] = useState(SECURITY_QUESTIONS[0]);
  const [securityAnswer, setSecurityAnswer] = useState('');

  // Step 4: Generated Recovery Key
  const [recoveryKey, setRecoveryKey] = useState('');
  const [confirmedSaved, setConfirmedSaved] = useState(false);

  // Logo upload
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        error('Logo image size must be less than 2 MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoBase64(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Password strength meter
  const getPasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, text: 'Empty', color: 'bg-slate-200' };
    let score = 0;
    if (pass.length >= 8) score++;
    if (/[A-Z]/.test(pass)) score++;
    if (/[0-9]/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass)) score++;

    if (score <= 1) return { score: 1, text: 'Weak', color: 'bg-rose-500' };
    if (score === 2) return { score: 2, text: 'Fair', color: 'bg-amber-500' };
    if (score === 3) return { score: 3, text: 'Good', color: 'bg-blue-500' };
    return { score: 4, text: 'Strong', color: 'bg-emerald-500' };
  };

  const strength = getPasswordStrength(password);

  const handleNextStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    if (!doctorName.trim() || !registrationNumber.trim() || !doctorPhone.trim()) {
      error('Please fill in doctor name, registration number, and phone.');
      return;
    }
    setStep(2);
  };

  const handleNextStep2 = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clinicName.trim() || !clinicAddress.trim() || !clinicCity.trim()) {
      error('Please fill in clinic name, address, and city.');
      return;
    }
    setStep(3);
  };

  const handleFinishStep3 = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      error('Please enter a username.');
      return;
    }
    if (password.length < 8) {
      error('Password must be at least 8 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      error('Passwords do not match.');
      return;
    }
    if (!securityAnswer.trim()) {
      error('Please provide an answer to your security question.');
      return;
    }

    // Generate recovery key and transition to step 4
    const key = generateRecoveryKey();
    setRecoveryKey(key);
    setStep(4);
  };

  const handleCompleteSetup = async () => {
    if (!confirmedSaved) {
      error('Please confirm that you have saved your Recovery Key.');
      return;
    }

    setLoading(true);
    try {
      const finalDegree = degreeOption === 'Other' ? customDegree.trim() || 'MBBS' : degreeOption;
      const createdAdmin = await setupFirstClinic({
        doctorName: doctorName.trim(),
        degree: finalDegree,
        specialization: specialization.trim(),
        registrationNumber: registrationNumber.trim(),
        doctorPhone: doctorPhone.trim(),
        doctorEmail: doctorEmail.trim() || undefined,
        clinicName: clinicName.trim(),
        clinicAddress: clinicAddress.trim(),
        clinicCity: clinicCity.trim(),
        clinicPhone: clinicPhone.trim() || doctorPhone.trim(),
        workingHours: workingHours.trim(),
        consultationFee: consultationFee || 500,
        logoBase64: logoBase64 || undefined,
        username: username.trim(),
        password,
        securityQuestion,
        securityAnswer,
        recoveryKey,
      });

      setSessionUser(createdAdmin);
      await checkAdminStatus();
      await reloadSettings();
      success('Clinic setup completed! You are now logged in as Primary Administrator.');
      navigate('/', { replace: true });
    } catch (err: any) {
      error(err.message || 'Failed to complete setup');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyKey = () => {
    navigator.clipboard.writeText(recoveryKey);
    success('Recovery Key copied to clipboard!');
  };

  const handleDownloadKey = () => {
    const text = `CLINIC MANAGEMENT SYSTEM - EMERGENCY RECOVERY KEY\n\nClinic: ${clinicName}\nDoctor: ${doctorName}\nAdmin Username: ${username}\nRecovery Key: ${recoveryKey}\nDate Generated: ${new Date().toLocaleString()}\n\nKeep this key safe! You can use it to reset your password offline if you ever forget it.`;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `clinic_recovery_key_${username}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    success('Recovery Key downloaded to your device!');
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl w-full mx-auto">
        {/* Header Branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-500/30 mb-3">
            <Activity className="w-8 h-8" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Create Your Clinic Account
          </h1>
          <p className="mt-2 text-sm text-slate-400">
            Initial setup wizard. 100% offline database initialized on this device.
          </p>
        </div>

        {/* 3-Step Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between relative">
            <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-1 bg-slate-800 z-0" />
            <div
              className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-blue-500 transition-all duration-300 z-0"
              style={{ width: step === 1 ? '0%' : step === 2 ? '50%' : '100%' }}
            />

            {[
              { num: 1, label: 'Doctor Profile', icon: Stethoscope },
              { num: 2, label: 'Clinic Details', icon: Building2 },
              { num: 3, label: 'Admin Login', icon: Lock },
            ].map((s) => {
              const isPassed = step > s.num;
              const isCurrent = step === s.num || (step === 4 && s.num === 3);

              return (
                <div key={s.num} className="relative z-10 flex flex-col items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all border-2 ${
                      isPassed
                        ? 'bg-emerald-600 border-emerald-500 text-white'
                        : isCurrent
                        ? 'bg-blue-600 border-blue-400 text-white shadow-lg shadow-blue-500/30 ring-4 ring-blue-500/20'
                        : 'bg-slate-800 border-slate-700 text-slate-500'
                    }`}
                  >
                    {isPassed ? <CheckCircle2 className="w-5 h-5" /> : s.num}
                  </div>
                  <span
                    className={`text-xs mt-2 font-medium ${
                      isCurrent ? 'text-blue-400 font-semibold' : 'text-slate-400'
                    }`}
                  >
                    {s.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Form Container */}
        <div className="bg-slate-950 rounded-3xl p-6 sm:p-10 border border-slate-800 shadow-2xl">
          {/* STEP 1: Doctor Profile */}
          {step === 1 && (
            <form onSubmit={handleNextStep1} className="space-y-5 animate-in fade-in duration-150">
              <div className="border-b border-slate-800 pb-3 mb-4">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Stethoscope className="w-5 h-5 text-blue-400" />
                  Step 1: Doctor & Practitioner Profile
                </h2>
                <p className="text-xs text-slate-400 mt-1">This will be printed on all your prescriptions and invoices.</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Full Name (with Dr. prefix) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dr. Sarah Jenkins"
                  value={doctorName}
                  onChange={(e) => setDoctorName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Primary Degree *
                  </label>
                  <select
                    value={degreeOption}
                    onChange={(e) => setDegreeOption(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-sm"
                  >
                    {DEGREES.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>

                {degreeOption === 'Other' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                      Specify Degree *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Fellow in Cardiology"
                      value={customDegree}
                      onChange={(e) => setCustomDegree(e.target.value)}
                      className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Specialization
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Internal Medicine / Paediatrics"
                    value={specialization}
                    onChange={(e) => setSpecialization(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Medical Registration Number *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. MED-REG-84729"
                    value={registrationNumber}
                    onChange={(e) => setRegistrationNumber(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Doctor Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 9876543210"
                    value={doctorPhone}
                    onChange={(e) => setDoctorPhone(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Doctor Email (Optional)
                </label>
                <input
                  type="email"
                  placeholder="e.g. doctor@clinic.org"
                  value={doctorEmail}
                  onChange={(e) => setDoctorEmail(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                />
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold transition-colors shadow-lg shadow-blue-500/20"
                >
                  Next: Clinic Details
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: Clinic Profile */}
          {step === 2 && (
            <form onSubmit={handleNextStep2} className="space-y-5 animate-in fade-in duration-150">
              <div className="border-b border-slate-800 pb-3 mb-4">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-blue-400" />
                  Step 2: Clinic Profile & Address
                </h2>
                <p className="text-xs text-slate-400 mt-1">General clinic details and consultation settings.</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Clinic Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. City Care Polyclinic & Diagnostics"
                  value={clinicName}
                  onChange={(e) => setClinicName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Clinic Address *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 104 Main Street, Sector 5"
                    value={clinicAddress}
                    onChange={(e) => setClinicAddress(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    City / Town *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mumbai"
                    value={clinicCity}
                    onChange={(e) => setClinicCity(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Reception Phone
                  </label>
                  <input
                    type="tel"
                    placeholder="e.g. 022-2849202"
                    value={clinicPhone}
                    onChange={(e) => setClinicPhone(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Working Hours
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 09:00 AM - 08:00 PM"
                    value={workingHours}
                    onChange={(e) => setWorkingHours(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Default Consultation Fee (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="500"
                    value={consultationFee}
                    onChange={(e) => setConsultationFee(Number(e.target.value))}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                  />
                </div>
              </div>

              {/* Logo Upload (Stored offline as base64) */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Clinic Logo (Optional, saved locally)
                </label>
                <div className="flex items-center gap-4">
                  {logoBase64 ? (
                    <img
                      src={logoBase64}
                      alt="Logo preview"
                      className="w-16 h-16 object-contain rounded-xl border border-slate-700 bg-white p-1"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-xl border border-dashed border-slate-700 flex items-center justify-center text-slate-500">
                      <Upload className="w-6 h-6" />
                    </div>
                  )}
                  <div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-slate-200 hover:file:bg-slate-700 cursor-pointer"
                    />
                    <p className="text-[11px] text-slate-500 mt-1">PNG, JPG or SVG up to 2 MB.</p>
                  </div>
                </div>
              </div>

              <div className="pt-4 flex justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm font-semibold transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold transition-colors shadow-lg shadow-blue-500/20"
                >
                  Next: Admin Credentials
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 3: Admin Login Credentials */}
          {step === 3 && (
            <form onSubmit={handleFinishStep3} className="space-y-5 animate-in fade-in duration-150">
              <div className="border-b border-slate-800 pb-3 mb-4">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Lock className="w-5 h-5 text-blue-400" />
                  Step 3: Admin Login & Security
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Credentials are encrypted with bcrypt and stored 100% offline.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Admin Username *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. doctor or admin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Password (Min 8 characters) *
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {/* Strength meter */}
                  {password && (
                    <div className="mt-2">
                      <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                        <span>Strength: {strength.text}</span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden flex gap-1">
                        {[1, 2, 3, 4].map((level) => (
                          <div
                            key={level}
                            className={`flex-1 transition-all ${
                              strength.score >= level ? strength.color : 'bg-slate-800'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Confirm Password *
                  </label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                  />
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800">
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Offline Security Question (For Password Recovery) *
                </label>
                <select
                  value={securityQuestion}
                  onChange={(e) => setSecurityQuestion(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm mb-3"
                >
                  {SECURITY_QUESTIONS.map((q) => (
                    <option key={q} value={q}>
                      {q}
                    </option>
                  ))}
                </select>

                <input
                  type="text"
                  required
                  placeholder="Your Secret Answer"
                  value={securityAnswer}
                  onChange={(e) => setSecurityAnswer(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                />
              </div>

              <div className="pt-4 flex justify-between">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm font-semibold transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold transition-colors shadow-lg shadow-blue-500/20"
                >
                  Generate Recovery Key & Finish
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 4: One-Time Emergency Recovery Key Screen */}
          {step === 4 && (
            <div className="space-y-6 animate-in fade-in duration-150">
              <div className="text-center">
                <div className="inline-flex p-3 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20 mb-3">
                  <KeyRound className="w-8 h-8" />
                </div>
                <h2 className="text-xl font-bold text-white">Your One-Time Recovery Key</h2>
                <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                  Because this app operates 100% offline with zero cloud servers, this key is the only emergency way to reset your account if you forget your password.
                </p>
              </div>

              {/* Big Key Display Box */}
              <div className="p-6 bg-slate-900 border-2 border-blue-500/30 rounded-2xl text-center shadow-inner">
                <p className="text-xs font-mono uppercase tracking-widest text-slate-400 mb-2">Emergency Key</p>
                <p className="text-2xl sm:text-3xl font-mono font-black text-blue-400 tracking-wider selection:bg-blue-400 selection:text-slate-950">
                  {recoveryKey}
                </p>
                <div className="flex items-center justify-center gap-3 mt-4">
                  <button
                    type="button"
                    onClick={handleCopyKey}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-colors border border-slate-700"
                  >
                    <Copy className="w-4 h-4" />
                    Copy Key
                  </button>
                  <button
                    type="button"
                    onClick={handleDownloadKey}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl transition-colors shadow-md"
                  >
                    <Download className="w-4 h-4" />
                    Download as File
                  </button>
                </div>
              </div>

              {/* Mandatory Confirmation Checkbox */}
              <label className="flex items-start gap-3 p-4 bg-slate-900/60 border border-slate-800 rounded-xl cursor-pointer hover:bg-slate-900 transition-colors">
                <input
                  type="checkbox"
                  checked={confirmedSaved}
                  onChange={(e) => setConfirmedSaved(e.target.checked)}
                  className="mt-0.5 w-4 h-4 text-blue-600 rounded border-slate-700 bg-slate-800 focus:ring-blue-500"
                />
                <span className="text-xs text-slate-300 leading-relaxed">
                  <strong className="text-white">I have copied and safely stored my recovery key.</strong> I understand that this key will never be shown again and cannot be retrieved from any cloud server.
                </span>
              </label>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  disabled={!confirmedSaved || loading}
                  onClick={handleCompleteSetup}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold rounded-xl transition-colors shadow-lg shadow-emerald-600/30 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {loading && <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />}
                  Open Clinic Management System
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
