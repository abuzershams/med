import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { KeyRound, HelpCircle, Lock, ArrowLeft, ArrowRight, CheckCircle2 } from 'lucide-react';
import {
  getUserSecurityQuestion,
  resetPasswordWithRecoveryKey,
  resetPasswordWithSecurityQuestion,
} from '../../services/authService';
import { useToast } from '../../context/ToastContext';

export const ForgotPassword: React.FC = () => {
  const navigate = useNavigate();
  const { success, error } = useToast();

  const [username, setUsername] = useState('');
  const [method, setMethod] = useState<'recovery_key' | 'security_question'>('recovery_key');
  const [recoveryKey, setRecoveryKey] = useState('');
  const [securityQuestion, setSecurityQuestion] = useState<string>('');
  const [securityAnswer, setSecurityAnswer] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [questionLoaded, setQuestionLoaded] = useState(false);

  const handleFetchQuestion = async () => {
    if (!username.trim()) {
      error('Please enter your username first.');
      return;
    }
    setLoading(true);
    try {
      const q = await getUserSecurityQuestion(username.trim());
      setSecurityQuestion(q);
      setQuestionLoaded(true);
    } catch (err: any) {
      error(err.message || 'User not found or no question configured.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      error('Please enter your username.');
      return;
    }
    if (newPassword.length < 8) {
      error('New password must be at least 8 characters long.');
      return;
    }
    if (newPassword !== confirmPassword) {
      error('Passwords do not match.');
      return;
    }

    setLoading(true);
    try {
      if (method === 'recovery_key') {
        if (!recoveryKey.trim()) {
          error('Please enter your 12-character Recovery Key.');
          return;
        }
        await resetPasswordWithRecoveryKey(username.trim(), recoveryKey.trim(), newPassword);
      } else {
        if (!securityAnswer.trim()) {
          error('Please answer the security question.');
          return;
        }
        await resetPasswordWithSecurityQuestion(username.trim(), securityAnswer.trim(), newPassword);
      }

      success('Password reset successfully! Please sign in with your new password.');
      navigate('/login');
    } catch (err: any) {
      error(err.message || 'Password reset failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 mb-3">
            <KeyRound className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Offline Password Reset</h1>
          <p className="mt-1.5 text-xs text-slate-400">
            Reset access using your Recovery Key or Secret Question
          </p>
        </div>

        <div className="bg-slate-950 rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-2xl">
          <form onSubmit={handleReset} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Username
              </label>
              <input
                type="text"
                required
                placeholder="Enter username to reset"
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                  setQuestionLoaded(false);
                }}
                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-sm"
              />
            </div>

            {/* Recovery Method Tabs */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Reset Method
              </label>
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs font-medium">
                <button
                  type="button"
                  onClick={() => setMethod('recovery_key')}
                  className={`py-2 px-3 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                    method === 'recovery_key'
                      ? 'bg-blue-600 text-white font-semibold shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  Recovery Key
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMethod('security_question');
                    if (username.trim() && !questionLoaded) {
                      handleFetchQuestion();
                    }
                  }}
                  className={`py-2 px-3 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                    method === 'security_question'
                      ? 'bg-blue-600 text-white font-semibold shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  Security Q&A
                </button>
              </div>
            </div>

            {/* Recovery Key input */}
            {method === 'recovery_key' && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  12-Character Recovery Key
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. REC-XXXX-XXXX"
                  value={recoveryKey}
                  onChange={(e) => setRecoveryKey(e.target.value.toUpperCase())}
                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-sm tracking-wide"
                />
              </div>
            )}

            {/* Security Question inputs */}
            {method === 'security_question' && (
              <div className="space-y-3">
                {!questionLoaded ? (
                  <button
                    type="button"
                    onClick={handleFetchQuestion}
                    className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors"
                  >
                    Load Security Question for Username
                  </button>
                ) : (
                  <>
                    <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300">
                      <p className="font-semibold text-slate-400 uppercase text-[10px] mb-1">Security Question</p>
                      <p className="font-medium text-white">{securityQuestion}</p>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                        Your Secret Answer
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Enter the secret answer"
                        value={securityAnswer}
                        onChange={(e) => setSecurityAnswer(e.target.value)}
                        className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-sm"
                      />
                    </div>
                  </>
                )}
              </div>
            )}

            {/* New Password & Confirm */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  New Password (8+ chars)
                </label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-3 inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold transition-colors shadow-lg shadow-emerald-500/20 disabled:opacity-50"
            >
              {loading && <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />}
              Save New Password & Reset
              <CheckCircle2 className="w-4 h-4" />
            </button>

            <div className="pt-2 text-center">
              <Link
                to="/login"
                className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Return to Login
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
