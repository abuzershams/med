import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Activity, Lock, User, Eye, EyeOff, ShieldAlert, ArrowRight } from 'lucide-react';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { getLockoutStatus } from '../../services/authService';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const { success, error } = useToast();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberUser, setRememberUser] = useState(true);
  const [loading, setLoading] = useState(false);
  const [lockoutSecs, setLockoutSecs] = useState<number>(0);

  const [errorMessage, setErrorMessage] = useState('');
  const [existingAccounts, setExistingAccounts] = useState<{ username: string; role: string; name: string }[]>([]);

  // Load existing accounts for quick convenience
  useEffect(() => {
    async function fetchAccounts() {
      try {
        const users = await db.users.toArray();
        if (users && users.length > 0) {
          setExistingAccounts(users.map((u) => ({ username: u.username, role: u.role, name: u.name })));
        }
      } catch {
        // Ignore
      }
    }
    fetchAccounts();
  }, []);

  // Load last remembered username
  useEffect(() => {
    const saved = localStorage.getItem('clinic_remembered_username');
    if (saved) {
      setUsername(saved);
    }
  }, []);

  // Monitor lockout timer
  useEffect(() => {
    const check = () => {
      const status = getLockoutStatus();
      if (status.isLocked) {
        setLockoutSecs(status.remainingSeconds);
      } else {
        setLockoutSecs(0);
      }
    };
    check();
    const interval = setInterval(check, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (lockoutSecs > 0) return;

    const trimmedUsername = username.trim();
    if (!trimmedUsername || !password) {
      const msg = 'Please enter both username and password.';
      setErrorMessage(msg);
      error(msg);
      return;
    }

    setLoading(true);
    try {
      await login(trimmedUsername, password);
      if (rememberUser) {
        localStorage.setItem('clinic_remembered_username', trimmedUsername);
      } else {
        localStorage.removeItem('clinic_remembered_username');
      }
      success('Logged in successfully! Opening dashboard...');
      navigate('/', { replace: true });
    } catch (err: any) {
      const msg = err.message || 'Login failed. Please check your credentials.';
      setErrorMessage(msg);
      error(msg);
    } finally {
      setLoading(false);
    }
  };

  const formatCountdown = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full mx-auto">
        {/* Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-500/30 mb-3">
            <Activity className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Clinic Management System</h1>
          <p className="mt-1.5 text-xs text-slate-400">Secure 100% Offline Medical Suite</p>
        </div>

        {/* Card */}
        <div className="bg-slate-950 rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-2xl">
          {/* Lockout Warning Banner */}
          {lockoutSecs > 0 && (
            <div className="mb-6 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="font-semibold text-rose-300">Account Temporarily Locked</p>
                <p className="mt-0.5 text-slate-300">
                  Multiple incorrect passwords detected. Please wait{' '}
                  <span className="font-mono font-bold text-rose-300">{formatCountdown(lockoutSecs)}</span> before
                  trying again.
                </p>
              </div>
            </div>
          )}

          {/* Inline Error Message */}
          {errorMessage && lockoutSecs === 0 && (
            <div className="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 flex items-start gap-2.5 text-xs animate-in fade-in">
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-rose-200">{errorMessage}</p>
                <p className="mt-1 text-slate-400">
                  कृपया सही यूजरनेम और पासवर्ड जांचें। यदि आप पासवर्ड भूल गए हैं, तो नीचे दिए गए &apos;Forgot password?&apos; लिंक का उपयोग करें।
                </p>
              </div>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Username
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  disabled={lockoutSecs > 0}
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-sm disabled:opacity-50"
                />
              </div>

              {/* Quick Select for Existing Clinic Accounts */}
              {existingAccounts.length > 0 && (
                <div className="mt-2 flex items-center flex-wrap gap-1.5">
                  <span className="text-[11px] text-slate-400">Click to fill:</span>
                  {existingAccounts.map((acc) => (
                    <button
                      key={acc.username}
                      type="button"
                      onClick={() => setUsername(acc.username)}
                      className="text-[11px] px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-blue-400 border border-slate-700 transition-colors"
                      title={`Role: ${acc.role} (${acc.name})`}
                    >
                      {acc.username}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Password
                </label>
                <Link
                  to="/forgot-password"
                  className="text-xs text-blue-400 hover:text-blue-300 font-medium transition-colors"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  disabled={lockoutSecs > 0}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-sm disabled:opacity-50"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 p-1"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-400">
                <input
                  type="checkbox"
                  checked={rememberUser}
                  onChange={(e) => setRememberUser(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded border-slate-700 bg-slate-800 focus:ring-blue-500"
                />
                Remember username
              </label>
            </div>

            <button
              type="submit"
              disabled={loading || lockoutSecs > 0}
              className="w-full mt-2 inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold transition-colors shadow-lg shadow-blue-500/20 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            >
              {loading && <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />}
              {loading ? 'Opening Dashboard...' : 'Sign In to Practice / Dashboard'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>

        <div className="mt-8 text-center text-xs text-slate-500">
          Running in offline standalone mode. No external servers or telemetry.
        </div>
      </div>
    </div>
  );
};
