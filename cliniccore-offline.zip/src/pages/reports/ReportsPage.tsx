import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Calendar,
  Download,
  Printer,
  DollarSign,
  Users,
  Stethoscope,
  Pill,
  TrendingUp,
  FileSpreadsheet,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import Papa from 'papaparse';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useToast } from '../../context/ToastContext';
import { StatCard } from '../../components/common/StatCard';
import { generateReportPDF } from '../../print/pdfGenerator';
import { PrintPreviewModal } from '../../print/PrintPreviewModal';
import type { Patient, Invoice, PharmacySale, Expense, Doctor, Appointment } from '../../types';

export const ReportsPage: React.FC = () => {
  const { settings, formatCurrency, formatDate } = useClinic();
  const { success, error } = useToast();

  const [dateFilter, setDateFilter] = useState<'month' | 'today' | 'year' | 'all'>('month');
  const [reportType, setReportType] = useState<'financial' | 'patients' | 'doctors' | 'pharmacy'>('financial');
  const [loading, setLoading] = useState(true);

  // Raw data
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [pharmacySales, setPharmacySales] = useState<PharmacySale[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);

  // Print modal
  const [isPrintOpen, setIsPrintOpen] = useState(false);

  const loadAllData = async () => {
    setLoading(true);
    try {
      const invs = await db.invoices.toArray();
      setInvoices(invs);
      const sales = await db.pharmacy_sales.toArray();
      setPharmacySales(sales);
      const exps = await db.expenses.toArray();
      setExpenses(exps);
      const pats = await db.patients.toArray();
      setPatients(pats);
      const docs = await db.doctors.toArray();
      setDoctors(docs);
      const appts = await db.appointments.toArray();
      setAppointments(appts);
    } catch (err) {
      console.error(err);
      error('Failed to load report data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  const todayStr = new Date().toISOString().split('T')[0];
  const thisMonthStr = todayStr.substring(0, 7);
  const thisYearStr = todayStr.substring(0, 4);

  // Date filtering helper
  const filterByDate = (dateStr: string) => {
    if (dateFilter === 'today') return dateStr === todayStr;
    if (dateFilter === 'month') return dateStr.startsWith(thisMonthStr);
    if (dateFilter === 'year') return dateStr.startsWith(thisYearStr);
    return true;
  };

  // Filtered collections
  const filteredInvoices = invoices.filter((i) => filterByDate(i.date) && i.status !== 'cancelled');
  const filteredSales = pharmacySales.filter((s) => filterByDate(s.date));
  const filteredExpenses = expenses.filter((e) => filterByDate(e.date));
  const filteredPatients = patients.filter((p) => filterByDate(p.registrationDate || todayStr));
  const filteredAppointments = appointments.filter((a) => filterByDate(a.date));

  // Metrics
  const invoiceRevenue = filteredInvoices.reduce((sum, i) => sum + i.paidAmount, 0);
  const pharmacyRevenue = filteredSales.reduce((sum, s) => sum + s.grandTotal, 0);
  const totalRevenue = invoiceRevenue + pharmacyRevenue;
  const totalExpenseAmount = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
  const netProfit = totalRevenue - totalExpenseAmount;
  const totalOutstandingDue = filteredInvoices.reduce((sum, i) => sum + i.dueAmount, 0);

  // Financial Chart: Revenue vs Expense
  const financialBarData = [
    { name: 'Consultations', amount: invoiceRevenue, color: '#2563eb' },
    { name: 'Pharmacy POS', amount: pharmacyRevenue, color: '#0d9488' },
    { name: 'Expenses', amount: totalExpenseAmount, color: '#e11d48' },
    { name: 'Net Profit', amount: Math.max(0, netProfit), color: '#16a34a' },
  ];

  // Gender demographics
  const genderCounts: Record<string, number> = { Male: 0, Female: 0, Other: 0 };
  patients.forEach((p) => {
    if (genderCounts[p.gender] !== undefined) genderCounts[p.gender]++;
    else genderCounts['Other']++;
  });
  const genderPieData = [
    { name: 'Male', value: genderCounts.Male || 0, color: '#3b82f6' },
    { name: 'Female', value: genderCounts.Female || 0, color: '#ec4899' },
    { name: 'Other', value: genderCounts.Other || 0, color: '#8b5cf6' },
  ];

  // Doctor productivity
  const doctorStats = doctors.map((doc) => {
    const docAppts = filteredAppointments.filter((a) => a.doctorId === doc.id);
    const docInvoices = filteredInvoices.filter((i) => i.doctorId === doc.id);
    const docRev = docInvoices.reduce((sum, i) => sum + i.paidAmount, 0);
    return {
      name: `Dr. ${doc.name}`,
      appointments: docAppts.length,
      revenue: docRev,
    };
  });

  // Export to CSV
  const handleExportCSV = () => {
    let dataToExport: any[] = [];
    let filename = `Clinic_${reportType}_report_${todayStr}.csv`;

    if (reportType === 'financial') {
      dataToExport = filteredInvoices.map((inv) => ({
        Type: 'Invoice',
        Number: inv.invoiceNumber,
        Date: inv.date,
        Patient: inv.patientName,
        Doctor: inv.doctorName || '',
        Total: inv.grandTotal,
        Paid: inv.paidAmount,
        Due: inv.dueAmount,
        Status: inv.status,
      }));
    } else if (reportType === 'patients') {
      dataToExport = filteredPatients.map((p) => ({
        Code: p.patientCode,
        Name: p.name,
        Gender: p.gender,
        Age: p.age,
        Phone: p.phone,
        BloodGroup: p.bloodGroup || '',
        Allergies: p.allergies || '',
        RegisteredDate: p.registrationDate,
      }));
    } else if (reportType === 'doctors') {
      dataToExport = doctorStats;
    } else if (reportType === 'pharmacy') {
      dataToExport = filteredSales.map((s) => ({
        ReceiptNo: s.receiptNumber,
        Date: s.date,
        Customer: s.customerName,
        Subtotal: s.subtotal,
        Discount: s.discount,
        GrandTotal: s.grandTotal,
        PaymentMethod: s.paymentMethod,
      }));
    }

    const csv = Papa.unparse(dataToExport);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    success(`Exported ${filename}`);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Reports & Analytics</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Operational summaries, financial statements, and printable clinic metrics
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
          {/* Date Range Selector */}
          <select
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value as any)}
            className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-none shadow-xs"
          >
            <option value="today">Today</option>
            <option value="month">This Month</option>
            <option value="year">This Year</option>
            <option value="all">All Time</option>
          </select>

          {/* Export CSV */}
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-xs transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            Export CSV
          </button>

          {/* Print Report PDF */}
          <button
            onClick={() => setIsPrintOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-sm shadow-blue-500/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Report
          </button>
        </div>
      </div>

      {/* Report Module Tabs */}
      <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 self-start">
        {(
          [
            { id: 'financial', label: 'Financial Summary', icon: DollarSign },
            { id: 'patients', label: 'Patient Demographics', icon: Users },
            { id: 'doctors', label: 'Doctor Performance', icon: Stethoscope },
            { id: 'pharmacy', label: 'Pharmacy Sales', icon: Pill },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            onClick={() => setReportType(t.id)}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              reportType === t.id
                ? 'bg-white text-blue-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <t.icon className="w-3.5 h-3.5" />
            {t.label}
          </button>
        ))}
      </div>

      {/* FINANCIAL REPORT TAB */}
      {reportType === 'financial' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title="Total Revenue"
              value={formatCurrency(totalRevenue)}
              subtitle="Consultations + Pharmacy"
              icon={TrendingUp}
              colorScheme="emerald"
            />
            <StatCard
              title="Total Expenses"
              value={formatCurrency(totalExpenseAmount)}
              subtitle="Operations & Salaries"
              icon={DollarSign}
              colorScheme="rose"
            />
            <StatCard
              title="Net Profit"
              value={formatCurrency(netProfit)}
              subtitle="Surplus after expenses"
              icon={BarChart3}
              colorScheme="blue"
            />
            <StatCard
              title="Receivables / Dues"
              value={formatCurrency(totalOutstandingDue)}
              subtitle="Uncollected patient balances"
              icon={DollarSign}
              colorScheme="amber"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
              <h3 className="font-bold text-slate-900 text-base mb-4">Financial Breakdown Chart</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={financialBarData}>
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} tickFormatter={(val) => `₹${val}`} />
                    <Tooltip formatter={(value: any) => [formatCurrency(Number(value)), 'Amount']} />
                    <Bar dataKey="amount" radius={[6, 6, 0, 0]}>
                      {financialBarData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
              <h3 className="font-bold text-slate-900 text-base">Revenue Distribution</h3>
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-100 flex justify-between items-center">
                  <span className="font-medium text-slate-700">Doctor Invoices:</span>
                  <span className="font-bold text-blue-700">{formatCurrency(invoiceRevenue)}</span>
                </div>
                <div className="p-3 rounded-xl bg-teal-50/60 border border-teal-100 flex justify-between items-center">
                  <span className="font-medium text-slate-700">Pharmacy Counter:</span>
                  <span className="font-bold text-teal-700">{formatCurrency(pharmacyRevenue)}</span>
                </div>
                <div className="p-3 rounded-xl bg-rose-50/60 border border-rose-100 flex justify-between items-center">
                  <span className="font-medium text-slate-700">Clinic Expenses:</span>
                  <span className="font-bold text-rose-700">{formatCurrency(totalExpenseAmount)}</span>
                </div>
                <div className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-100 flex justify-between items-center">
                  <span className="font-bold text-slate-900">Net Clinic Profit:</span>
                  <span className="font-bold text-emerald-700 text-sm">
                    {formatCurrency(netProfit)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PATIENTS DEMOGRAPHICS TAB */}
      {reportType === 'patients' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <StatCard
              title="Total Registered Patients"
              value={patients.length}
              subtitle="All registered records"
              icon={Users}
              colorScheme="blue"
            />
            <StatCard
              title="Registrations in Period"
              value={filteredPatients.length}
              subtitle="New admissions"
              icon={TrendingUp}
              colorScheme="emerald"
            />
            <StatCard
              title="Male / Female Ratio"
              value={`${genderCounts.Male || 0} / ${genderCounts.Female || 0}`}
              subtitle="Gender distribution"
              icon={Users}
              colorScheme="purple"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
              <h3 className="font-bold text-slate-900 text-base mb-4">Gender Distribution</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={genderPieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={85}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {genderPieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
              <h3 className="font-bold text-slate-900 text-base mb-4">Patient Blood Group Summary</h3>
              <div className="grid grid-cols-4 gap-2 text-center text-xs">
                {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map((bg) => {
                  const count = patients.filter((p) => p.bloodGroup === bg).length;
                  return (
                    <div key={bg} className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                      <span className="font-bold text-slate-900 block text-sm">{bg}</span>
                      <span className="text-slate-500 text-[11px]">{count} patients</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DOCTORS PERFORMANCE TAB */}
      {reportType === 'doctors' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex justify-between items-center">
            <h3 className="font-bold text-slate-900 text-base">Doctor Productivity & Collections</h3>
            <span className="text-xs text-slate-500">Period: {dateFilter.toUpperCase()}</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-semibold text-slate-500">
                <tr>
                  <th className="px-5 py-3.5">Doctor Name</th>
                  <th className="px-4 py-3.5">Consultations</th>
                  <th className="px-4 py-3.5 text-right">Revenue Generated</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {doctorStats.map((doc, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/80">
                    <td className="px-5 py-3.5 font-semibold text-slate-900">
                      {doc.name}
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold">
                        {doc.appointments} visits
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-right font-bold text-emerald-600">
                      {formatCurrency(doc.revenue)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* PHARMACY SALES TAB */}
      {reportType === 'pharmacy' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex justify-between items-center">
            <h3 className="font-bold text-slate-900 text-base">Pharmacy POS Receipts</h3>
            <span className="text-xs text-slate-500">
              Total Sales: {formatCurrency(pharmacyRevenue)}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-semibold text-slate-500">
                <tr>
                  <th className="px-5 py-3.5">Receipt #</th>
                  <th className="px-4 py-3.5">Date</th>
                  <th className="px-4 py-3.5">Customer</th>
                  <th className="px-4 py-3.5 text-right">Total</th>
                  <th className="px-4 py-3.5 text-center">Payment</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredSales.slice(0, 15).map((sale) => (
                  <tr key={sale.id} className="hover:bg-slate-50/80">
                    <td className="px-5 py-3.5 font-semibold text-blue-600">
                      {sale.receiptNumber}
                    </td>
                    <td className="px-4 py-3.5 text-xs text-slate-500">
                      {formatDate(sale.date)}
                    </td>
                    <td className="px-4 py-3.5 font-medium text-slate-900">
                      {sale.customerName}
                    </td>
                    <td className="px-4 py-3.5 text-right font-bold text-slate-900">
                      {formatCurrency(sale.grandTotal)}
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium">
                        {sale.paymentMethod}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Print Report Preview Modal */}
      {isPrintOpen && (
        <PrintPreviewModal
          isOpen={isPrintOpen}
          onClose={() => setIsPrintOpen(false)}
          title={`Clinic Report (${reportType.toUpperCase()})`}
          onGeneratePdf={() =>
            generateReportPDF(
              `Clinic ${reportType.toUpperCase()} Report`,
              [
                ['Metric', 'Value'],
                ['Total Consultations Revenue', formatCurrency(invoiceRevenue)],
                ['Total Pharmacy Revenue', formatCurrency(pharmacyRevenue)],
                ['Total Operating Expenses', formatCurrency(totalExpenseAmount)],
                ['Net Clinic Profit', formatCurrency(netProfit)],
                ['Outstanding Receivables', formatCurrency(totalOutstandingDue)],
                ['Total Registered Patients', patients.length.toString()],
              ],
              settings
            )
          }
        >
          <div className="p-8 max-w-2xl mx-auto bg-white border border-slate-200 rounded-xl shadow-xs space-y-6">
            <div className="text-center pb-4 border-b border-slate-200">
              <h2 className="text-xl font-bold text-slate-900">{settings?.clinicName || 'Clinic MS'}</h2>
              <p className="text-xs text-slate-500">{settings?.address}</p>
              <h3 className="text-sm font-bold text-blue-600 mt-2 uppercase tracking-wide">
                Management Report ({reportType}) - {todayStr}
              </h3>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-xs text-slate-700">
                <thead className="bg-slate-50 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3 text-left">Metric / Indicator</th>
                    <th className="p-3 text-right">Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr>
                    <td className="p-3">Consultation Billing Revenue</td>
                    <td className="p-3 text-right font-medium">{formatCurrency(invoiceRevenue)}</td>
                  </tr>
                  <tr>
                    <td className="p-3">Pharmacy POS Collections</td>
                    <td className="p-3 text-right font-medium">{formatCurrency(pharmacyRevenue)}</td>
                  </tr>
                  <tr>
                    <td className="p-3">Total Clinic Expenses</td>
                    <td className="p-3 text-right text-rose-600 font-medium">{formatCurrency(totalExpenseAmount)}</td>
                  </tr>
                  <tr className="bg-slate-50 font-bold text-slate-900">
                    <td className="p-3">Net Profit / Surplus</td>
                    <td className="p-3 text-right text-emerald-600">{formatCurrency(netProfit)}</td>
                  </tr>
                  <tr>
                    <td className="p-3">Patient Dues Outstanding</td>
                    <td className="p-3 text-right text-amber-600 font-medium">{formatCurrency(totalOutstandingDue)}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <p className="text-xs text-slate-400 text-center italic">
              Generated offline on {new Date().toLocaleString()}
            </p>
          </div>
        </PrintPreviewModal>
      )}
    </div>
  );
};
