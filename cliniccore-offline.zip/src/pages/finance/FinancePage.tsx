import React, { useState, useEffect } from 'react';
import {
  Wallet,
  Plus,
  TrendingDown,
  TrendingUp,
  DollarSign,
  Calendar,
  Trash2,
  Printer,
  CheckCircle2,
  UserCheck,
  FileText,
} from 'lucide-react';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { StatCard } from '../../components/common/StatCard';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { PrintPreviewModal } from '../../print/PrintPreviewModal';
import { generatePayslipPDF } from '../../print/pdfGenerator';
import { numberToWords } from '../../utils/numberToWords';
import { logActivity } from '../../services/auditService';
import type { Expense, Payslip, User, Doctor } from '../../types';

export const FinancePage: React.FC = () => {
  const { settings, formatCurrency, formatDate } = useClinic();
  const { user } = useAuth();
  const { success, error } = useToast();

  const [activeTab, setActiveTab] = useState<'expenses' | 'payroll'>('expenses');
  const [loading, setLoading] = useState(true);

  // Financial metrics
  const [totalIncome, setTotalIncome] = useState(0);
  const [totalExpenses, setTotalExpenses] = useState(0);

  // Expenses state
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [expenseTitle, setExpenseTitle] = useState('');
  const [expenseCategory, setExpenseCategory] = useState('Supplies');
  const [expenseAmount, setExpenseAmount] = useState<number | ''>('');
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split('T')[0]);
  const [expensePaidTo, setExpensePaidTo] = useState('');
  const [expensePaymentMode, setExpensePaymentMode] = useState('Cash');
  const [expenseNotes, setExpenseNotes] = useState('');

  // Delete Expense
  const [expenseToDelete, setExpenseToDelete] = useState<Expense | null>(null);

  // Payroll state
  const [payslips, setPayslips] = useState<Payslip[]>([]);
  const [staffList, setStaffList] = useState<User[]>([]);
  const [doctorList, setDoctorList] = useState<Doctor[]>([]);
  const [isPayslipModalOpen, setIsPayslipModalOpen] = useState(false);

  // Payslip form state
  const [employeeType, setEmployeeType] = useState<'doctor' | 'staff'>('doctor');
  const [employeeId, setEmployeeId] = useState<number | ''>('');
  const [salaryMonth, setSalaryMonth] = useState(new Date().toISOString().substring(0, 7)); // YYYY-MM
  const [basicSalary, setBasicSalary] = useState<number>(0);
  const [allowances, setAllowances] = useState<number>(0);
  const [deductions, setDeductions] = useState<number>(0);

  // Payslip Print Preview
  const [printingPayslip, setPrintingPayslip] = useState<Payslip | null>(null);
  const [isPrintPayslipOpen, setIsPrintPayslipOpen] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      // Income from invoices + pharmacy sales
      const invoices = await db.invoices.where('status').notEqual('cancelled').toArray();
      const invoicePaid = invoices.reduce((sum, inv) => sum + inv.paidAmount, 0);

      const sales = await db.pharmacy_sales.toArray();
      const pharmacyRevenue = sales.reduce((sum, s) => sum + s.grandTotal, 0);

      setTotalIncome(invoicePaid + pharmacyRevenue);

      // Expenses
      const allExpenses = await db.expenses.reverse().sortBy('date');
      setExpenses(allExpenses);
      const expenseSum = allExpenses.reduce((sum, exp) => sum + exp.amount, 0);
      setTotalExpenses(expenseSum);

      // Payroll
      const allPayslips = await db.payslips.reverse().sortBy('createdAt');
      setPayslips(allPayslips);

      const staff = await db.users.where('status').equals('active').toArray();
      setStaffList(staff);

      const doctors = await db.doctors.where('status').equals('active').toArray();
      setDoctorList(doctors);
    } catch (err) {
      console.error(err);
      error('Failed to load financial records');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseTitle.trim() || !expenseAmount || Number(expenseAmount) <= 0) {
      error('Please enter title and valid amount');
      return;
    }

    try {
      const expData: Expense = {
        title: expenseTitle.trim(),
        category: expenseCategory,
        amount: Number(expenseAmount),
        date: expenseDate,
        paidTo: expensePaidTo.trim(),
        paymentMethod: expensePaymentMode,
        notes: expenseNotes.trim(),
        createdAt: new Date().toISOString(),
      };

      await db.expenses.add(expData);
      await logActivity(
        user?.name || 'User',
        user?.role || 'admin',
        'ADD_EXPENSE',
        'finance',
        `Added expense: ${expenseTitle} (${formatCurrency(Number(expenseAmount))})`
      );

      success('Expense recorded successfully');
      setIsExpenseModalOpen(false);
      setExpenseTitle('');
      setExpenseAmount('');
      setExpensePaidTo('');
      setExpenseNotes('');
      loadData();
    } catch (err) {
      console.error(err);
      error('Failed to save expense');
    }
  };

  const handleDeleteExpense = async () => {
    if (!expenseToDelete || !expenseToDelete.id) return;
    try {
      await db.expenses.delete(expenseToDelete.id);
      await logActivity(
        user?.name || 'User',
        user?.role || 'admin',
        'DELETE_EXPENSE',
        'finance',
        `Deleted expense: ${expenseToDelete.title}`
      );
      success('Expense deleted');
      setExpenseToDelete(null);
      loadData();
    } catch (err) {
      console.error(err);
      error('Failed to delete expense');
    }
  };

  // Generate Payslip
  const handleGeneratePayslip = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!employeeId) {
      error('Please select an employee');
      return;
    }

    let empName = '';
    let empRole = '';

    if (employeeType === 'doctor') {
      const doc = doctorList.find((d) => d.id === employeeId);
      empName = `Dr. ${doc?.name}`;
      empRole = doc?.specialization || 'Doctor';
    } else {
      const st = staffList.find((s) => s.id === employeeId);
      empName = st?.name || 'Staff';
      empRole = st?.role || 'Staff';
    }

    const netPay = Math.max(0, basicSalary + allowances - deductions);

    try {
      const payslipRecord: Payslip = {
        employeeName: empName,
        role: empRole,
        month: salaryMonth,
        basicSalary,
        allowances,
        deductions,
        netSalary: netPay,
        paymentDate: new Date().toISOString().split('T')[0],
        status: 'paid',
        createdAt: new Date().toISOString(),
      };

      const id = await db.payslips.add(payslipRecord);
      payslipRecord.id = Number(id);

      // Also record as an expense under 'Salaries'
      await db.expenses.add({
        title: `Salary: ${empName} (${salaryMonth})`,
        category: 'Salaries',
        amount: netPay,
        date: new Date().toISOString().split('T')[0],
        paidTo: empName,
        paymentMethod: 'Bank Transfer',
        notes: `Payslip #${id} auto-posted`,
        createdAt: new Date().toISOString(),
      });

      await logActivity(
        user?.name || 'User',
        user?.role || 'admin',
        'GENERATE_PAYSLIP',
        'finance',
        `Generated payslip for ${empName} (${formatCurrency(netPay)})`
      );

      success('Payslip generated and posted to expenses');
      setIsPayslipModalOpen(false);
      setPrintingPayslip(payslipRecord);
      setIsPrintPayslipOpen(true);
      loadData();
    } catch (err) {
      console.error(err);
      error('Failed to generate payslip');
    }
  };

  const netCashFlow = totalIncome - totalExpenses;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Finance & Payroll</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Clinic expense tracking, staff salaries, cash flow, and payslips
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {activeTab === 'expenses' ? (
            <button
              onClick={() => setIsExpenseModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm shadow-sm shadow-blue-500/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add Expense
            </button>
          ) : (
            <button
              onClick={() => setIsPayslipModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm shadow-sm shadow-blue-500/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Generate Payslip
            </button>
          )}

          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setActiveTab('expenses')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                activeTab === 'expenses'
                  ? 'bg-white text-blue-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Expenses
            </button>
            <button
              onClick={() => setActiveTab('payroll')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                activeTab === 'payroll'
                  ? 'bg-white text-blue-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Staff Payroll
            </button>
          </div>
        </div>
      </div>

      {/* Financial Health Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          title="Total Income"
          value={formatCurrency(totalIncome)}
          subtitle="Consultation + Pharmacy collections"
          icon={TrendingUp}
          colorScheme="emerald"
        />
        <StatCard
          title="Total Expenses"
          value={formatCurrency(totalExpenses)}
          subtitle="Operating expenses & salaries"
          icon={TrendingDown}
          colorScheme="rose"
        />
        <StatCard
          title="Net Cash Balance"
          value={formatCurrency(netCashFlow)}
          subtitle={netCashFlow >= 0 ? 'Surplus / Profit' : 'Deficit'}
          icon={Wallet}
          colorScheme={netCashFlow >= 0 ? 'blue' : 'amber'}
        />
      </div>

      {/* EXPENSES TAB */}
      {activeTab === 'expenses' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-base">Clinic Expense Records</h3>
            <span className="text-xs text-slate-500">
              Total {expenses.length} expense vouchers recorded
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-semibold text-slate-500">
                <tr>
                  <th className="px-5 py-3.5">Date</th>
                  <th className="px-4 py-3.5">Expense Description</th>
                  <th className="px-4 py-3.5">Category</th>
                  <th className="px-4 py-3.5">Paid To</th>
                  <th className="px-4 py-3.5">Payment Mode</th>
                  <th className="px-4 py-3.5 text-right">Amount</th>
                  <th className="px-5 py-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {expenses.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-5 py-8 text-center text-slate-400 text-xs">
                      No expense records found. Click &quot;Add Expense&quot; to log clinic costs.
                    </td>
                  </tr>
                ) : (
                  expenses.map((exp) => (
                    <tr key={exp.id} className="hover:bg-slate-50/80">
                      <td className="px-5 py-3.5 text-slate-500 text-xs">
                        {formatDate(exp.date)}
                      </td>
                      <td className="px-4 py-3.5 font-medium text-slate-900">
                        {exp.title}
                        {exp.notes && (
                          <p className="text-[11px] text-slate-400 font-normal">{exp.notes}</p>
                        )}
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium">
                          {exp.category}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-slate-700">
                        {exp.paidTo || '—'}
                      </td>
                      <td className="px-4 py-3.5 text-slate-500 text-xs">
                        {exp.paymentMethod || 'Cash'}
                      </td>
                      <td className="px-4 py-3.5 text-right font-bold text-rose-600">
                        {formatCurrency(exp.amount)}
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <button
                          onClick={() => setExpenseToDelete(exp)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Delete expense"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* PAYROLL TAB */}
      {activeTab === 'payroll' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-base">Generated Payslips & Salaries</h3>
            <span className="text-xs text-slate-500">
              Total {payslips.length} salary vouchers
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-semibold text-slate-500">
                <tr>
                  <th className="px-5 py-3.5">Month</th>
                  <th className="px-4 py-3.5">Employee Name</th>
                  <th className="px-4 py-3.5">Role</th>
                  <th className="px-4 py-3.5 text-right">Basic</th>
                  <th className="px-4 py-3.5 text-right">Allowances</th>
                  <th className="px-4 py-3.5 text-right">Deductions</th>
                  <th className="px-4 py-3.5 text-right">Net Salary</th>
                  <th className="px-5 py-3.5 text-right">Print Slip</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {payslips.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-5 py-8 text-center text-slate-400 text-xs">
                      No payslips issued yet. Click &quot;Generate Payslip&quot; to issue monthly compensation.
                    </td>
                  </tr>
                ) : (
                  payslips.map((ps) => (
                    <tr key={ps.id} className="hover:bg-slate-50/80">
                      <td className="px-5 py-3.5 font-semibold text-blue-600">
                        {ps.month}
                      </td>
                      <td className="px-4 py-3.5 font-medium text-slate-900">
                        {ps.employeeName}
                      </td>
                      <td className="px-4 py-3.5 text-xs text-slate-500 capitalize">
                        {ps.role}
                      </td>
                      <td className="px-4 py-3.5 text-right text-slate-700">
                        {formatCurrency(ps.basicSalary)}
                      </td>
                      <td className="px-4 py-3.5 text-right text-emerald-600 font-medium">
                        +{formatCurrency(ps.allowances)}
                      </td>
                      <td className="px-4 py-3.5 text-right text-rose-500 font-medium">
                        -{formatCurrency(ps.deductions)}
                      </td>
                      <td className="px-4 py-3.5 text-right font-bold text-slate-900">
                        {formatCurrency(ps.netSalary)}
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <button
                          onClick={() => {
                            setPrintingPayslip(ps);
                            setIsPrintPayslipOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                          title="Print Payslip Slip"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Expense Modal */}
      {isExpenseModalOpen && (
        <Modal
          isOpen={isExpenseModalOpen}
          onClose={() => setIsExpenseModalOpen(false)}
          title="Add Expense Voucher"
          subtitle="Record clinic operational expenses and vendor payouts"
          maxWidth="md"
        >
          <form onSubmit={handleAddExpense} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Expense Title *
              </label>
              <input
                type="text"
                placeholder="e.g., Clinic Electricity Bill / Needle Supplies"
                value={expenseTitle}
                onChange={(e) => setExpenseTitle(e.target.value)}
                required
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Category *
                </label>
                <select
                  value={expenseCategory}
                  onChange={(e) => setExpenseCategory(e.target.value)}
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white"
                >
                  <option value="Supplies">Medical Supplies</option>
                  <option value="Utilities">Utilities & Bills</option>
                  <option value="Rent">Rent & Facility</option>
                  <option value="Maintenance">Maintenance & Repairs</option>
                  <option value="Salaries">Staff Salaries</option>
                  <option value="Miscellaneous">Miscellaneous</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Amount *
                </label>
                <input
                  type="number"
                  min="1"
                  step="0.01"
                  placeholder="0.00"
                  value={expenseAmount}
                  onChange={(e) =>
                    setExpenseAmount(e.target.value ? Number(e.target.value) : '')
                  }
                  required
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 font-semibold"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Date *
                </label>
                <input
                  type="date"
                  value={expenseDate}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  required
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Payment Mode
                </label>
                <select
                  value={expensePaymentMode}
                  onChange={(e) => setExpensePaymentMode(e.target.value)}
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white"
                >
                  <option value="Cash">Cash</option>
                  <option value="UPI">UPI / GPay / PhonePe</option>
                  <option value="Card">Debit / Credit Card</option>
                  <option value="Bank Transfer">Bank Transfer / NEFT</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Paid To (Recipient)
              </label>
              <input
                type="text"
                placeholder="e.g., Power Distribution Corp"
                value={expensePaidTo}
                onChange={(e) => setExpensePaidTo(e.target.value)}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Notes
              </label>
              <textarea
                rows={2}
                placeholder="Optional comments or voucher reference number"
                value={expenseNotes}
                onChange={(e) => setExpenseNotes(e.target.value)}
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
              />
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsExpenseModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium shadow-sm shadow-blue-500/20 cursor-pointer"
              >
                Save Expense
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Generate Payslip Modal */}
      {isPayslipModalOpen && (
        <Modal
          isOpen={isPayslipModalOpen}
          onClose={() => setIsPayslipModalOpen(false)}
          title="Generate Staff Payslip"
          subtitle="Issue salary voucher with breakdown of basic pay, allowances, and tax/deductions"
          maxWidth="md"
        >
          <form onSubmit={handleGeneratePayslip} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Employee Type
                </label>
                <select
                  value={employeeType}
                  onChange={(e) => {
                    setEmployeeType(e.target.value as 'doctor' | 'staff');
                    setEmployeeId('');
                  }}
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white"
                >
                  <option value="doctor">Doctor</option>
                  <option value="staff">Staff / Receptionist</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Salary Month *
                </label>
                <input
                  type="month"
                  value={salaryMonth}
                  onChange={(e) => setSalaryMonth(e.target.value)}
                  required
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Select Person *
              </label>
              <select
                value={employeeId}
                onChange={(e) => {
                  const id = Number(e.target.value);
                  setEmployeeId(id);
                  if (employeeType === 'doctor') {
                    const doc = doctorList.find((d) => d.id === id);
                    if (doc) setBasicSalary(doc.consultationFee * 100 || 60000);
                  } else {
                    setBasicSalary(20000);
                  }
                }}
                required
                className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 bg-white"
              >
                <option value="">Select Employee...</option>
                {employeeType === 'doctor'
                  ? doctorList.map((d) => (
                      <option key={d.id} value={d.id}>
                        Dr. {d.name} ({d.specialization})
                      </option>
                    ))
                  : staffList.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.role})
                      </option>
                    ))}
              </select>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Basic Pay *
                </label>
                <input
                  type="number"
                  min="0"
                  value={basicSalary}
                  onChange={(e) => setBasicSalary(Number(e.target.value))}
                  required
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Allowances
                </label>
                <input
                  type="number"
                  min="0"
                  value={allowances}
                  onChange={(e) => setAllowances(Number(e.target.value))}
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 text-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                  Deductions
                </label>
                <input
                  type="number"
                  min="0"
                  value={deductions}
                  onChange={(e) => setDeductions(Number(e.target.value))}
                  className="w-full text-sm px-3 py-2 rounded-xl border border-slate-200 text-rose-500"
                />
              </div>
            </div>

            <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-xl flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-700">Calculated Net Pay:</span>
              <span className="text-base font-bold text-blue-700">
                {formatCurrency(Math.max(0, basicSalary + allowances - deductions))}
              </span>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsPayslipModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium shadow-sm shadow-blue-500/20 cursor-pointer"
              >
                Issue Payslip
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Delete Expense Confirm */}
      <ConfirmDialog
        isOpen={!!expenseToDelete}
        title="Delete Expense"
        message={`Are you sure you want to delete the expense entry "${expenseToDelete?.title}" (${formatCurrency(expenseToDelete?.amount || 0)})?`}
        confirmLabel="Delete"
        variant="danger"
        onConfirm={handleDeleteExpense}
        onCancel={() => setExpenseToDelete(null)}
      />

      {/* Payslip Print Modal */}
      {isPrintPayslipOpen && printingPayslip && (
        <PrintPreviewModal
          isOpen={isPrintPayslipOpen}
          onClose={() => {
            setIsPrintPayslipOpen(false);
            setPrintingPayslip(null);
          }}
          title={`Payslip - ${printingPayslip.employeeName}`}
          onGeneratePdf={() => generatePayslipPDF(printingPayslip, settings)}
        >
          <div className="p-8 max-w-2xl mx-auto bg-white border border-slate-200 rounded-xl shadow-xs space-y-6">
            <div className="text-center pb-4 border-b border-slate-200">
              <h2 className="text-xl font-bold text-slate-900">{settings?.clinicName || 'Clinic MS'}</h2>
              <p className="text-xs text-slate-500">{settings?.address}</p>
              <h3 className="text-sm font-bold text-blue-600 mt-2 uppercase tracking-wide">
                Salary Slip for Month: {printingPayslip.month}
              </h3>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <p className="text-slate-400">Employee Name:</p>
                <p className="font-semibold text-slate-900 text-sm">{printingPayslip.employeeName}</p>
              </div>
              <div>
                <p className="text-slate-400">Designation / Role:</p>
                <p className="font-semibold text-slate-900 text-sm">{printingPayslip.role}</p>
              </div>
              <div>
                <p className="text-slate-400">Payment Date:</p>
                <p className="font-semibold text-slate-900">{formatDate(printingPayslip.paymentDate)}</p>
              </div>
              <div>
                <p className="text-slate-400">Status:</p>
                <p className="font-semibold text-emerald-600 uppercase">Paid / Settled</p>
              </div>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-xs text-slate-700">
                <thead className="bg-slate-50 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3 text-left">Description</th>
                    <th className="p-3 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr>
                    <td className="p-3">Basic Salary</td>
                    <td className="p-3 text-right font-medium">{formatCurrency(printingPayslip.basicSalary)}</td>
                  </tr>
                  <tr>
                    <td className="p-3">Allowances & Incentives</td>
                    <td className="p-3 text-right text-emerald-600 font-medium">
                      +{formatCurrency(printingPayslip.allowances)}
                    </td>
                  </tr>
                  <tr>
                    <td className="p-3">Taxes & Deductions</td>
                    <td className="p-3 text-right text-rose-500 font-medium">
                      -{formatCurrency(printingPayslip.deductions)}
                    </td>
                  </tr>
                  <tr className="bg-slate-50 font-bold text-slate-900 text-sm">
                    <td className="p-3">Net Salary Payable</td>
                    <td className="p-3 text-right text-blue-600">
                      {formatCurrency(printingPayslip.netSalary)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="text-xs text-slate-500 pt-2 border-t border-slate-100 flex justify-between items-center">
              <span>Amount in Words: {numberToWords(printingPayslip.netSalary)}</span>
              <span className="italic">Authorized Signatory</span>
            </div>
          </div>
        </PrintPreviewModal>
      )}
    </div>
  );
};
