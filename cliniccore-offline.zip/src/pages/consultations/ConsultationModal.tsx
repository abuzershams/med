import React, { useState, useEffect } from 'react';
import { Modal } from '../../components/common/Modal';
import { DatePicker } from '../../components/common/DatePicker';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { logActivity } from '../../services/auditService';
import type { Consultation, Doctor } from '../../types';

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientId: number;
  patientName: string;
  patientCode: string;
  onSaved: () => void;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({
  isOpen,
  onClose,
  patientId,
  patientName,
  patientCode,
  onSaved,
}) => {
  const { user } = useAuth();
  const { success, error } = useToast();

  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedDoctorId, setSelectedDoctorId] = useState<number | ''>('');
  const [chiefComplaint, setChiefComplaint] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [medicalHistory, setMedicalHistory] = useState('');
  const [examination, setExamination] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [treatmentPlan, setTreatmentPlan] = useState('');
  const [advice, setAdvice] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');
  const [previousConsultations, setPreviousConsultations] = useState<Consultation[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadData() {
      const docs = await db.doctors.where('status').equals('active').toArray();
      setDoctors(docs);
      if (docs.length > 0) setSelectedDoctorId(docs[0].id!);

      // Load previous consultations for reference
      const prev = await db.consultations.where('patientId').equals(patientId).toArray();
      prev.sort((a, b) => b.date.localeCompare(a.date));
      setPreviousConsultations(prev);
    }
    if (isOpen) {
      loadData();
      setChiefComplaint('');
      setSymptoms('');
      setMedicalHistory('');
      setExamination('');
      setDiagnosis('');
      setTreatmentPlan('');
      setAdvice('');
      setFollowUpDate('');
    }
  }, [isOpen, patientId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDoctorId || !chiefComplaint.trim() || !diagnosis.trim()) {
      error('Please fill in consulting doctor, chief complaint, and diagnosis.');
      return;
    }

    setLoading(true);
    try {
      const doc = await db.doctors.get(Number(selectedDoctorId));
      if (!doc) throw new Error('Doctor not found.');

      const now = new Date();
      const dateStr = now.toISOString().split('T')[0];

      await db.consultations.add({
        patientId,
        patientName,
        patientCode,
        doctorId: doc.id!,
        doctorName: doc.name,
        date: dateStr,
        chiefComplaint: chiefComplaint.trim(),
        symptoms: symptoms.trim() || undefined,
        medicalHistory: medicalHistory.trim() || undefined,
        examination: examination.trim() || undefined,
        diagnosis: diagnosis.trim(),
        treatmentPlan: treatmentPlan.trim() || undefined,
        advice: advice.trim() || undefined,
        followUpDate: followUpDate || undefined,
        billed: false,
        createdAt: now.toISOString(),
      });

      // If follow up date set, automatically add to follow_ups table
      if (followUpDate) {
        const patient = await db.patients.get(patientId);
        await db.follow_ups.add({
          patientId,
          patientName,
          patientCode,
          patientPhone: patient?.phone || '',
          doctorId: doc.id!,
          doctorName: doc.name,
          followUpDate,
          reason: `Follow-up for ${diagnosis.trim()}`,
          isDone: false,
          createdAt: now.toISOString(),
        });
      }

      await logActivity(
        user?.username || 'Doctor',
        user?.role || 'doctor',
        'Record Consultation',
        'Consultations',
        `Recorded diagnosis "${diagnosis.trim()}" for ${patientName}`
      );

      success('Consultation record saved successfully!');
      onSaved();
      onClose();
    } catch (err: any) {
      error(err.message || 'Failed to save consultation');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Clinical Consultation: ${patientName} (${patientCode})`}
      subtitle="Complete diagnostic examination note and treatment plan"
      maxWidth="4xl"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form Inputs (2 Cols) */}
        <form onSubmit={handleSubmit} className="lg:col-span-2 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Consulting Doctor *</label>
            <select
              value={selectedDoctorId}
              onChange={(e) => setSelectedDoctorId(Number(e.target.value))}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            >
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.specialization})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Chief Complaint *</label>
            <textarea
              rows={2}
              required
              placeholder="e.g. Severe throbbing headache for 3 days, acute nausea"
              value={chiefComplaint}
              onChange={(e) => setChiefComplaint(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Symptoms & Duration</label>
              <textarea
                rows={2}
                placeholder="Onset, frequency, severity..."
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Past History / Comorbidities</label>
              <textarea
                rows={2}
                placeholder="Hypertension, DM, past surgeries..."
                value={medicalHistory}
                onChange={(e) => setMedicalHistory(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Physical & Clinical Examination</label>
            <textarea
              rows={2}
              placeholder="General exam, CVS, RS, P/A, CNS findings..."
              value={examination}
              onChange={(e) => setExamination(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-blue-900 mb-1">Final / Working Diagnosis *</label>
            <input
              type="text"
              required
              placeholder="e.g. Migraine with aura / Acute Acid Peptic Disease"
              value={diagnosis}
              onChange={(e) => setDiagnosis(e.target.value)}
              className="w-full px-3 py-2 bg-blue-50/50 border border-blue-300 rounded-lg text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Treatment Plan</label>
              <textarea
                rows={2}
                placeholder="Prescription medicines, lab investigations ordered..."
                value={treatmentPlan}
                onChange={(e) => setTreatmentPlan(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Advice & Dietary Restrictions</label>
              <textarea
                rows={2}
                placeholder="Drink fluids, bed rest, avoid oily food..."
                value={advice}
                onChange={(e) => setAdvice(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <DatePicker
              label="Next Follow-Up Date"
              value={followUpDate}
              onChange={setFollowUpDate}
              placeholder="Select follow-up date"
            />
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2 text-sm font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs disabled:opacity-50"
            >
              {loading ? 'Saving...' : 'Save Consultation Note'}
            </button>
          </div>
        </form>

        {/* Previous Consultations Reference Sidebar (1 Col) */}
        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col max-h-[550px]">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 pb-2 border-b border-slate-200">
            Past Medical Consultations ({previousConsultations.length})
          </h4>

          <div className="space-y-3 overflow-y-auto flex-1">
            {previousConsultations.length === 0 ? (
              <p className="text-xs text-slate-400 italic">No previous clinical notes for this patient.</p>
            ) : (
              previousConsultations.map((c) => (
                <div key={c.id} className="p-3 bg-white rounded-xl border border-slate-200 text-xs space-y-1">
                  <div className="flex items-center justify-between text-slate-400 text-[10px]">
                    <span>{c.date}</span>
                    <span>{c.doctorName}</span>
                  </div>
                  <p className="font-bold text-blue-900 text-[13px]">{c.diagnosis}</p>
                  <p className="text-slate-600 text-[11px] line-clamp-2">
                    <span className="font-semibold text-slate-700">Complaint: </span>
                    {c.chiefComplaint}
                  </p>
                  {c.advice && (
                    <p className="text-slate-500 text-[11px] italic line-clamp-1">
                      Advice: {c.advice}
                    </p>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
};
