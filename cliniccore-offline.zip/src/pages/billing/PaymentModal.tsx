import React, { useState } from 'react';
import { Modal } from '../../components/common/Modal';
import { DatePicker } from '../../components/common/DatePicker';
import { db } from '../../db/database';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useClinic } from '../../context/ClinicContext';
import { logActivity } from '../../services/auditService';
import type { Invoice, PaymentMethod } from '../../types';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice;
  onSaved?: () => void;
  onPaymentSuccess?: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  invoice,
  onSaved,
  onPaymentSuccess,
}) => {
  const { user } = useAuth();
  const { formatCurrency } = useClinic();
  const { success, error } = useToast();

  const [amount, setAmount] = useState<number>(invoice.balanceDue || 0);
  const [method, setMethod] = useState<PaymentMethod>('Cash');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [note, setNote] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) {
      error('Please enter a payment amount greater than zero.');
      return;
    }

    setLoading(true);
    try {
      const now = new Date();
      const timeStr = now.toTimeString().split(' ')[0].substring(0, 5);

      // Execute transaction to update invoice + add payment
      await db.transaction('rw', [db.invoices, db.payments, db.activity_logs], async () => {
        const inv = await db.invoices.get(invoice.id!);
        if (!inv) throw new Error('Invoice not found.');

        const newPaid = (inv.amountPaid || 0) + amount;
        const newBalance = Math.max(0, inv.grandTotal - newPaid);
        const newStatus = newBalance <= 0 ? 'Paid' : 'Partial';

        // 1. Update invoice
        await db.invoices.update(inv.id!, {
          amountPaid: newPaid,
          balanceDue: newBalance,
          status: newStatus,
          updatedAt: now.toISOString(),
        });

        // 2. Add payment record
        await db.payments.add({
          invoiceId: inv.id,
          invoiceNumber: inv.invoiceNumber,
          patientId: inv.patientId,
          patientName: inv.patientName,
          amount,
          method,
          date,
          time: timeStr,
          receivedBy: user?.name || 'Staff',
          note: note.trim() || undefined,
          createdAt: now.toISOString(),
        });

        // 3. Activity log
        await logActivity(
          user?.username || 'Staff',
          user?.role || 'staff',
          'Record Payment',
          'Billing',
          `Collected ${formatCurrency(amount)} for ${inv.invoiceNumber} via ${method}`
        );
      });

      success(`Payment of ${formatCurrency(amount)} recorded successfully!`);
      onSaved();
      onClose();
    } catch (err: any) {
      error(err.message || 'Failed to record payment');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Collect Payment: ${invoice.invoiceNumber}`}
      subtitle={`Patient: ${invoice.patientName} (${invoice.patientCode}) • Balance Due: ${formatCurrency(invoice.balanceDue)}`}
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-500 block">Total Invoice Amount</span>
            <span className="text-sm font-bold text-slate-900">{formatCurrency(invoice.grandTotal)}</span>
          </div>
          <div className="text-right">
            <span className="text-rose-600 block font-semibold">Remaining Due</span>
            <span className="text-sm font-bold text-rose-600">{formatCurrency(invoice.balanceDue)}</span>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Payment Amount (₹) *</label>
          <input
            type="number"
            min="1"
            step="0.01"
            required
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-base font-bold text-slate-900 focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Payment Method *</label>
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value as any)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            >
              <option value="Cash">Cash</option>
              <option value="UPI">UPI / QR Code</option>
              <option value="Card">Debit / Credit Card</option>
              <option value="Bank">Bank Transfer / NEFT</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <DatePicker
              label="Payment Date"
              required
              value={date}
              onChange={setDate}
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Payment Reference / Note</label>
          <input
            type="text"
            placeholder="e.g. Transaction ID, UPI Ref, Cheque No..."
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex justify-end gap-3 pt-3 border-t">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 text-sm font-semibold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 shadow-xs disabled:opacity-50"
          >
            {loading ? 'Recording...' : 'Confirm Payment'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
