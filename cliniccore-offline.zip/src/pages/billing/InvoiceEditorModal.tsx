import React, { useState, useEffect } from 'react';
import { Plus, Trash2, RefreshCw } from 'lucide-react';
import { Modal } from '../../components/common/Modal';
import { DatePicker } from '../../components/common/DatePicker';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { getNextInvoiceNumber } from '../../services/counterService';
import { logActivity } from '../../services/auditService';
import { numberToWords } from '../../utils/numberToWords';
import type { Invoice, InvoiceItem, Patient, Doctor, PaymentMethod, InvoiceStatus } from '../../types';

interface InvoiceEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedPatient?: Patient | null;
  invoiceToEdit?: Invoice | null;
  onSaved: (invoice: Invoice) => void;
}

export const InvoiceEditorModal: React.FC<InvoiceEditorModalProps> = ({
  isOpen,
  onClose,
  preselectedPatient,
  invoiceToEdit,
  onSaved,
}) => {
  const { settings, formatCurrency } = useClinic();
  const { user } = useAuth();
  const { success, error, info } = useToast();

  const [patients, setPatients] = useState<Patient[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);

  const [selectedPatientId, setSelectedPatientId] = useState<number | ''>('');
  const [selectedDoctorId, setSelectedDoctorId] = useState<number | ''>('');
  const [date, setDate] = useState<string>('');
  const [items, setItems] = useState<InvoiceItem[]>([]);
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [taxPercent, setTaxPercent] = useState<number>(0);
  const [initialPayment, setInitialPayment] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
  const [notes, setNotes] = useState<string>('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function init() {
      const allP = await db.patients.toArray();
      setPatients(allP);
      const allD = await db.doctors.where('status').equals('active').toArray();
      setDoctors(allD);

      if (invoiceToEdit) {
        setSelectedPatientId(invoiceToEdit.patientId);
        setSelectedDoctorId(invoiceToEdit.doctorId || '');
        setDate(invoiceToEdit.date);
        setItems(invoiceToEdit.items);
        setDiscountAmount(invoiceToEdit.discountAmount);
        setTaxPercent(invoiceToEdit.taxPercent);
        setInitialPayment(0); // editing existing
        setNotes(invoiceToEdit.notes || '');
      } else {
        const todayStr = new Date().toISOString().split('T')[0];
        setDate(todayStr);
        if (preselectedPatient?.id) {
          setSelectedPatientId(preselectedPatient.id);
        } else if (allP.length > 0) {
          setSelectedPatientId(allP[0].id!);
        }
        if (allD.length > 0) {
          setSelectedDoctorId(allD[0].id!);
        }

        // Default initial items
        setItems([
          {
            id: 'item-1',
            description: 'General Doctor Consultation',
            quantity: 1,
            unitPrice: settings?.defaultConsultationFee || 500,
            amount: settings?.defaultConsultationFee || 500,
          },
        ]);
        setDiscountAmount(0);
        setTaxPercent(settings?.taxEnabled ? settings.taxPercent : 0);
        setInitialPayment(0);
        setNotes('');
      }
    }
    if (isOpen) {
      init();
    }
  }, [isOpen, invoiceToEdit, preselectedPatient, settings]);

  // Calculations
  const subtotal = items.reduce((sum, item) => sum + (item.amount || 0), 0);
  const taxAmount = (subtotal - discountAmount) > 0 ? ((subtotal - discountAmount) * taxPercent) / 100 : 0;
  const grandTotal = Math.max(0, subtotal - discountAmount + taxAmount);
  const initialPaid = invoiceToEdit ? invoiceToEdit.amountPaid : Math.min(initialPayment, grandTotal);
  const balanceDue = Math.max(0, grandTotal - initialPaid);

  // Auto Fetch unbilled consultations
  const handleAutoFetchUnbilled = async () => {
    if (!selectedPatientId) {
      error('Please select a patient first.');
      return;
    }

    const unbilled = await db.consultations
      .where('patientId')
      .equals(Number(selectedPatientId))
      .filter((c) => !c.billed)
      .toArray();

    if (unbilled.length === 0) {
      info('No unbilled consultations found for this patient.');
      return;
    }

    const newItems: InvoiceItem[] = unbilled.map((c, i) => ({
      id: `unbilled-${c.id}-${i}`,
      description: `Consultation (${c.diagnosis}) - ${c.date}`,
      quantity: 1,
      unitPrice: settings?.defaultConsultationFee || 500,
      amount: settings?.defaultConsultationFee || 500,
      referenceType: 'consultation',
      referenceId: c.id,
    }));

    setItems((prev) => [...prev, ...newItems]);
    success(`Added ${newItems.length} unbilled consultation(s) to this invoice.`);
  };

  const handleItemChange = (index: number, field: keyof InvoiceItem, value: any) => {
    const updated = [...items];
    const item = { ...updated[index], [field]: value };
    if (field === 'quantity' || field === 'unitPrice') {
      const q = Number(item.quantity) || 0;
      const p = Number(item.unitPrice) || 0;
      item.amount = q * p;
    }
    updated[index] = item;
    setItems(updated);
  };

  const handleAddItem = () => {
    setItems((prev) => [
      ...prev,
      {
        id: `item-${Date.now()}`,
        description: '',
        quantity: 1,
        unitPrice: 0,
        amount: 0,
      },
    ]);
  };

  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) {
      error('Invoice must contain at least one item.');
      return;
    }
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatientId) {
      error('Please select a patient.');
      return;
    }
    if (items.some((i) => !i.description.trim())) {
      error('Please provide a description for all invoice items.');
      return;
    }

    setLoading(true);
    try {
      const patient = await db.patients.get(Number(selectedPatientId));
      const doctor = selectedDoctorId ? await db.doctors.get(Number(selectedDoctorId)) : undefined;

      if (!patient) throw new Error('Patient record not found.');

      const now = new Date().toISOString();
      const status: InvoiceStatus =
        balanceDue <= 0 ? 'Paid' : initialPaid > 0 ? 'Partial' : 'Pending';

      let savedInvoice: Invoice;

      if (invoiceToEdit && invoiceToEdit.id) {
        // Edit invoice
        const updatedInvoice: Invoice = {
          ...invoiceToEdit,
          patientId: patient.id!,
          patientName: patient.name,
          patientCode: patient.patientCode,
          patientPhone: patient.phone,
          doctorId: doctor?.id,
          doctorName: doctor?.name,
          date,
          items,
          subtotal,
          discountAmount,
          taxPercent,
          taxAmount,
          grandTotal,
          balanceDue: Math.max(0, grandTotal - invoiceToEdit.amountPaid),
          status:
            grandTotal - invoiceToEdit.amountPaid <= 0
              ? 'Paid'
              : invoiceToEdit.amountPaid > 0
              ? 'Partial'
              : 'Pending',
          notes: notes.trim() || undefined,
          updatedAt: now,
        };

        await db.invoices.update(invoiceToEdit.id, updatedInvoice);
        savedInvoice = (await db.invoices.get(invoiceToEdit.id))!;

        await logActivity(
          user?.username || 'Staff',
          user?.role || 'staff',
          'Update Invoice',
          'Billing',
          `Updated invoice ${invoiceToEdit.invoiceNumber} for ${patient.name}`
        );

        success(`Invoice ${invoiceToEdit.invoiceNumber} updated.`);
      } else {
        // Create new invoice with atomic sequence number
        const prefix = settings?.invoicePrefix || 'INV';
        const invoiceNumber = await getNextInvoiceNumber(prefix);

        const newInvoice: Omit<Invoice, 'id'> = {
          invoiceNumber,
          patientId: patient.id!,
          patientName: patient.name,
          patientCode: patient.patientCode,
          patientPhone: patient.phone,
          doctorId: doctor?.id,
          doctorName: doctor?.name,
          date,
          items,
          subtotal,
          discountAmount,
          taxPercent,
          taxAmount,
          grandTotal,
          amountPaid: initialPaid,
          balanceDue,
          status,
          notes: notes.trim() || undefined,
          createdAt: now,
          updatedAt: now,
        };

        // Dexie transaction for invoice + payment + mark unbilled consultations
        const id = await db.transaction(
          'rw',
          [db.invoices, db.payments, db.consultations, db.activity_logs],
          async () => {
            const invId = await db.invoices.add(newInvoice as Invoice);

            // Record initial payment if paid > 0
            if (initialPaid > 0) {
              await db.payments.add({
                invoiceId: invId,
                invoiceNumber,
                patientId: patient.id!,
                patientName: patient.name,
                amount: initialPaid,
                method: paymentMethod,
                date,
                time: new Date().toTimeString().split(' ')[0].substring(0, 5),
                receivedBy: user?.name || 'Reception',
                note: 'Initial payment recorded at invoice generation',
                createdAt: now,
              });
            }

            // Mark any linked consultations as billed
            for (const item of items) {
              if (item.referenceType === 'consultation' && item.referenceId) {
                await db.consultations.update(item.referenceId, { billed: true });
              }
            }

            return invId;
          }
        );

        savedInvoice = (await db.invoices.get(id))!;

        await logActivity(
          user?.username || 'Staff',
          user?.role || 'staff',
          'Create Invoice',
          'Billing',
          `Generated invoice ${invoiceNumber} for ${patient.name} (${formatCurrency(grandTotal)})`
        );

        success(`Invoice ${invoiceNumber} generated successfully!`);
      }

      onSaved(savedInvoice);
      onClose();
    } catch (err: any) {
      error(err.message || 'Failed to save invoice');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={invoiceToEdit ? `Edit Invoice: ${invoiceToEdit.invoiceNumber}` : 'Create New Invoice'}
      subtitle="Itemized billing with auto-fetch and receipt recording"
      maxWidth="4xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Top Info Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Select Patient *</label>
            <select
              value={selectedPatientId}
              onChange={(e) => setSelectedPatientId(Number(e.target.value))}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            >
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.patientCode} - {p.phone})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Consulting Doctor</label>
            <select
              value={selectedDoctorId}
              onChange={(e) => setSelectedDoctorId(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-blue-500"
            >
              <option value="">None / Clinic Charge</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.specialization})
                </option>
              ))}
            </select>
          </div>

          <div>
            <DatePicker
              label="Invoice Date"
              required
              value={date}
              onChange={setDate}
            />
          </div>
        </div>

        {/* Auto-fetch Button */}
        {!invoiceToEdit && (
          <div className="flex justify-end">
            <button
              type="button"
              onClick={handleAutoFetchUnbilled}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Auto-Fetch Unbilled Consultations
            </button>
          </div>
        )}

        {/* Itemized Table */}
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100 text-slate-600 font-semibold uppercase text-[11px]">
                <th className="py-2.5 px-3">Description</th>
                <th className="py-2.5 px-3 w-20 text-center">Qty</th>
                <th className="py-2.5 px-3 w-28 text-right">Price</th>
                <th className="py-2.5 px-3 w-28 text-right">Amount</th>
                <th className="py-2.5 px-3 w-10 text-center"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {items.map((item, index) => (
                <tr key={item.id || index}>
                  <td className="p-2">
                    <input
                      type="text"
                      required
                      placeholder="Service / Procedure / Consultation description"
                      value={item.description}
                      onChange={(e) => handleItemChange(index, 'description', e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-md text-xs focus:ring-2 focus:ring-blue-500"
                    />
                  </td>
                  <td className="p-2 text-center">
                    <input
                      type="number"
                      min="1"
                      required
                      value={item.quantity}
                      onChange={(e) => handleItemChange(index, 'quantity', Number(e.target.value))}
                      className="w-16 px-2 py-1.5 text-center bg-white border border-slate-300 rounded-md text-xs focus:ring-2 focus:ring-blue-500"
                    />
                  </td>
                  <td className="p-2 text-right">
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      required
                      value={item.unitPrice}
                      onChange={(e) => handleItemChange(index, 'unitPrice', Number(e.target.value))}
                      className="w-24 px-2 py-1.5 text-right bg-white border border-slate-300 rounded-md text-xs focus:ring-2 focus:ring-blue-500"
                    />
                  </td>
                  <td className="p-2 text-right font-bold text-slate-900">
                    {formatCurrency(item.amount)}
                  </td>
                  <td className="p-2 text-center">
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(index)}
                      className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="p-2 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
            <button
              type="button"
              onClick={handleAddItem}
              className="inline-flex items-center gap-1 px-3 py-1 text-xs font-semibold text-blue-600 hover:bg-blue-100/60 rounded-md transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Item Row
            </button>
            <span className="text-xs text-slate-500">
              Subtotal: <strong className="text-slate-800">{formatCurrency(subtotal)}</strong>
            </span>
          </div>
        </div>

        {/* Calculations: Discount, Tax & Grand Total */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-start">
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Invoice Remarks / Notes</label>
              <textarea
                rows={2}
                placeholder="Payment instructions, receipt remarks..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
              />
            </div>

            {/* Initial Payment Collection */}
            {!invoiceToEdit && (
              <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-2">
                <p className="text-xs font-bold text-emerald-900">Record Initial Payment Now</p>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[11px] text-slate-600 block mb-0.5">Paid Amount (₹)</label>
                    <input
                      type="number"
                      min="0"
                      max={grandTotal}
                      value={initialPayment}
                      onChange={(e) => setInitialPayment(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 bg-white border border-emerald-300 rounded-md text-xs font-bold text-emerald-800"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-600 block mb-0.5">Method</label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value as any)}
                      className="w-full px-2.5 py-1.5 bg-white border border-emerald-300 rounded-md text-xs"
                    >
                      <option value="Cash">Cash</option>
                      <option value="UPI">UPI</option>
                      <option value="Card">Card</option>
                      <option value="Bank">Bank Transfer</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>Subtotal:</span>
              <span className="font-semibold text-slate-800">{formatCurrency(subtotal)}</span>
            </div>

            <div className="flex items-center justify-between text-slate-600">
              <span>Discount (₹):</span>
              <input
                type="number"
                min="0"
                value={discountAmount}
                onChange={(e) => setDiscountAmount(Number(e.target.value))}
                className="w-24 px-2 py-1 text-right bg-white border border-slate-300 rounded text-xs"
              />
            </div>

            <div className="flex items-center justify-between text-slate-600">
              <span>Tax (%):</span>
              <input
                type="number"
                min="0"
                max="100"
                value={taxPercent}
                onChange={(e) => setTaxPercent(Number(e.target.value))}
                className="w-20 px-2 py-1 text-right bg-white border border-slate-300 rounded text-xs"
              />
            </div>

            <div className="flex justify-between text-sm font-bold text-slate-900 pt-2 border-t border-slate-300">
              <span>Grand Total:</span>
              <span>{formatCurrency(grandTotal)}</span>
            </div>

            <div className="flex justify-between text-slate-700">
              <span>Amount Paid:</span>
              <span className="font-semibold text-emerald-700">{formatCurrency(initialPaid)}</span>
            </div>

            <div className="flex justify-between font-bold text-sm pt-1">
              <span className={balanceDue > 0 ? 'text-rose-600' : 'text-slate-800'}>Balance Due:</span>
              <span className={balanceDue > 0 ? 'text-rose-600' : 'text-slate-800'}>
                {formatCurrency(balanceDue)}
              </span>
            </div>

            <div className="pt-2 text-[11px] text-slate-500 italic border-t border-slate-200">
              In words: {numberToWords(grandTotal)}
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-3 border-t">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 text-sm font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-xs disabled:opacity-50"
          >
            {loading ? 'Saving...' : invoiceToEdit ? 'Save Invoice' : 'Generate Tax Invoice'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
