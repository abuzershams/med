import React, { useState, useEffect } from 'react';
import {
  Receipt,
  Plus,
  Search,
  Filter,
  DollarSign,
  AlertCircle,
  CheckCircle2,
  Clock,
  Printer,
  CreditCard,
  Edit,
  Trash2,
  XCircle,
  Calendar,
} from 'lucide-react';
import { db } from '../../db/database';
import { useClinic } from '../../context/ClinicContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { StatCard } from '../../components/common/StatCard';
import { StatusBadge } from '../../components/common/Badge';
import { Pagination } from '../../components/common/Pagination';
import { EmptyState, LoadingSpinner } from '../../components/common/EmptyState';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { InvoiceEditorModal } from './InvoiceEditorModal';
import { PaymentModal } from './PaymentModal';
import { PrintPreviewModal } from '../../print/PrintPreviewModal';
import { InvoicePrint } from '../../print/InvoicePrint';
import { generateInvoicePDF } from '../../print/pdfGenerator';
import { logActivity } from '../../services/auditService';
import type { Invoice, InvoiceStatus } from '../../types';

export const InvoicesPage: React.FC = () => {
  const { settings, formatCurrency, formatDate } = useClinic();
  const { user } = useAuth();
  const { success, error } = useToast();

  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters & Search
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateRange, setDateRange] = useState<string>('all'); // 'today', 'month', 'all'
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Modals state
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [payingInvoice, setPayingInvoice] = useState<Invoice | null>(null);

  // Print Preview
  const [isPrintOpen, setIsPrintOpen] = useState(false);
  const [printingInvoice, setPrintingInvoice] = useState<Invoice | null>(null);

  // Confirm delete or cancel
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [invoiceToDelete, setInvoiceToDelete] = useState<Invoice | null>(null);
  const [isCancelOpen, setIsCancelOpen] = useState(false);
  const [invoiceToCancel, setInvoiceToCancel] = useState<Invoice | null>(null);

  const loadInvoices = async () => {
    setLoading(true);
    try {
      const list = await db.invoices.reverse().sortBy('date');
      setInvoices(list);
    } catch (err) {
      console.error(err);
      error('Failed to load invoices');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, []);

  // Filter invoices
  const todayStr = new Date().toISOString().split('T')[0];
  const thisMonthStr = todayStr.substring(0, 7);

  const filteredInvoices = invoices.filter((inv) => {
    const matchesSearch =
      inv.invoiceNumber.toLowerCase().includes(search.toLowerCase()) ||
      inv.patientName.toLowerCase().includes(search.toLowerCase()) ||
      (inv.doctorName && inv.doctorName.toLowerCase().includes(search.toLowerCase()));

    const matchesStatus = statusFilter === 'all' || inv.status.toLowerCase() === statusFilter.toLowerCase();

    let matchesDate = true;
    if (dateRange === 'today') {
      matchesDate = inv.date === todayStr;
    } else if (dateRange === 'month') {
      matchesDate = inv.date.startsWith(thisMonthStr);
    }

    return matchesSearch && matchesStatus && matchesDate;
  });

  // Calculate summary metrics
  const totalBilled = invoices
    .filter((i) => i.status !== 'cancelled')
    .reduce((sum, i) => sum + i.grandTotal, 0);

  const totalCollected = invoices
    .filter((i) => i.status !== 'cancelled')
    .reduce((sum, i) => sum + i.paidAmount, 0);

  const totalDue = invoices
    .filter((i) => i.status !== 'cancelled')
    .reduce((sum, i) => sum + i.dueAmount, 0);

  const pendingCount = invoices.filter((i) => i.status === 'pending' || i.status === 'partial').length;

  // Pagination
  const totalItems = filteredInvoices.length;
  const startIndex = (currentPage - 1) * pageSize;
  const paginatedInvoices = filteredInvoices.slice(startIndex, startIndex + pageSize);

  const handleCancelInvoice = async () => {
    if (!invoiceToCancel || !invoiceToCancel.id) return;
    try {
      await db.invoices.update(invoiceToCancel.id, {
        status: 'cancelled',
        dueAmount: 0,
      });
      await logActivity(
        user?.name || 'User',
        user?.role || 'staff',
        'CANCEL_INVOICE',
        'billing',
        `Cancelled invoice #${invoiceToCancel.invoiceNumber}`
      );
      success('Invoice cancelled successfully');
      loadInvoices();
    } catch (err) {
      console.error(err);
      error('Failed to cancel invoice');
    } finally {
      setIsCancelOpen(false);
      setInvoiceToCancel(null);
    }
  };

  const handleDeleteInvoice = async () => {
    if (!invoiceToDelete || !invoiceToDelete.id) return;
    try {
      // Also delete linked payments
      const payments = await db.payments.where('invoiceId').equals(invoiceToDelete.id).toArray();
      for (const p of payments) {
        if (p.id) await db.payments.delete(p.id);
      }
      await db.invoices.delete(invoiceToDelete.id);
      await logActivity(
        user?.name || 'User',
        user?.role || 'admin',
        'DELETE_INVOICE',
        'billing',
        `Deleted invoice #${invoiceToDelete.invoiceNumber} and related payments`
      );
      success('Invoice deleted');
      loadInvoices();
    } catch (err) {
      console.error(err);
      error('Failed to delete invoice');
    } finally {
      setIsDeleteOpen(false);
      setInvoiceToDelete(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Billing & Invoices</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Create patient invoices, record payments, manage dues and print receipts
          </p>
        </div>
        <button
          onClick={() => {
            setEditingInvoice(null);
            setIsEditorOpen(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm shadow-sm shadow-blue-500/20 transition-all self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Create Invoice
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Billed"
          value={formatCurrency(totalBilled)}
          subtitle="All active invoices"
          icon={Receipt}
          colorScheme="blue"
        />
        <StatCard
          title="Collected"
          value={formatCurrency(totalCollected)}
          subtitle="Total payments received"
          icon={CheckCircle2}
          colorScheme="emerald"
        />
        <StatCard
          title="Outstanding Dues"
          value={formatCurrency(totalDue)}
          subtitle="Pending receivables"
          icon={AlertCircle}
          colorScheme="rose"
        />
        <StatCard
          title="Unsettled Invoices"
          value={pendingCount}
          subtitle="Pending or partial status"
          icon={Clock}
          colorScheme="amber"
        />
      </div>

      {/* Filters Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by invoice #, patient name, doctor..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-9 pr-4 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 text-sm rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-none focus:border-blue-500"
          >
            <option value="all">All Statuses</option>
            <option value="paid">Paid</option>
            <option value="partial">Partial</option>
            <option value="pending">Pending</option>
            <option value="cancelled">Cancelled</option>
          </select>

          {/* Date Filter */}
          <select
            value={dateRange}
            onChange={(e) => {
              setDateRange(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 text-sm rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-none focus:border-blue-500"
          >
            <option value="all">All Time</option>
            <option value="today">Today</option>
            <option value="month">This Month</option>
          </select>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {loading ? (
          <div className="p-12 flex justify-center">
            <LoadingSpinner size="lg" message="Loading invoices..." />
          </div>
        ) : filteredInvoices.length === 0 ? (
          <EmptyState
            icon={Receipt}
            title="No invoices found"
            description={
              search || statusFilter !== 'all' || dateRange !== 'all'
                ? 'Try adjusting your search query or filters.'
                : 'No invoices have been created yet. Click "Create Invoice" to begin billing.'
            }
            actionLabel={!search && statusFilter === 'all' ? 'Create Invoice' : undefined}
            onAction={
              !search && statusFilter === 'all'
                ? () => {
                    setEditingInvoice(null);
                    setIsEditorOpen(true);
                  }
                : undefined
            }
          />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-semibold text-slate-500 tracking-wider">
                  <tr>
                    <th className="px-5 py-3.5">Invoice #</th>
                    <th className="px-4 py-3.5">Date</th>
                    <th className="px-4 py-3.5">Patient</th>
                    <th className="px-4 py-3.5">Doctor</th>
                    <th className="px-4 py-3.5 text-right">Grand Total</th>
                    <th className="px-4 py-3.5 text-right">Paid</th>
                    <th className="px-4 py-3.5 text-right">Balance Due</th>
                    <th className="px-4 py-3.5 text-center">Status</th>
                    <th className="px-5 py-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {paginatedInvoices.map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-3.5 font-semibold text-blue-600">
                        {inv.invoiceNumber}
                      </td>
                      <td className="px-4 py-3.5 text-slate-500">
                        {formatDate(inv.date)}
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-medium text-slate-900">{inv.patientName}</div>
                        <div className="text-xs text-slate-400">{inv.patientCode}</div>
                      </td>
                      <td className="px-4 py-3.5 text-slate-700">
                        {inv.doctorName || '—'}
                      </td>
                      <td className="px-4 py-3.5 text-right font-semibold text-slate-900">
                        {formatCurrency(inv.grandTotal)}
                      </td>
                      <td className="px-4 py-3.5 text-right text-emerald-600 font-medium">
                        {formatCurrency(inv.paidAmount)}
                      </td>
                      <td className="px-4 py-3.5 text-right font-medium">
                        {inv.dueAmount > 0 ? (
                          <span className="text-rose-600 font-semibold">{formatCurrency(inv.dueAmount)}</span>
                        ) : (
                          <span className="text-slate-400">₹0</span>
                        )}
                      </td>
                      <td className="px-4 py-3.5 text-center">
                        <StatusBadge status={inv.status} />
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Print / View */}
                          <button
                            onClick={() => {
                              setPrintingInvoice(inv);
                              setIsPrintOpen(true);
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                            title="Print / View Invoice"
                          >
                            <Printer className="w-4 h-4" />
                          </button>

                          {/* Record Payment if due */}
                          {inv.dueAmount > 0 && inv.status !== 'cancelled' && (
                            <button
                              onClick={() => {
                                setPayingInvoice(inv);
                                setIsPaymentOpen(true);
                              }}
                              className="p-1.5 rounded-lg text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 transition-colors"
                              title="Record Payment"
                            >
                              <CreditCard className="w-4 h-4" />
                            </button>
                          )}

                          {/* Edit if unpaid or partial */}
                          {inv.status !== 'cancelled' && (
                            <button
                              onClick={() => {
                                setEditingInvoice(inv);
                                setIsEditorOpen(true);
                              }}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                              title="Edit Invoice"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                          )}

                          {/* Cancel */}
                          {inv.status !== 'cancelled' && (
                            <button
                              onClick={() => {
                                setInvoiceToCancel(inv);
                                setIsCancelOpen(true);
                              }}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              title="Cancel Invoice"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          )}

                          {/* Delete (Admin only) */}
                          {user?.role === 'admin' && (
                            <button
                              onClick={() => {
                                setInvoiceToDelete(inv);
                                setIsDeleteOpen(true);
                              }}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              title="Delete Invoice"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="p-4 border-t border-slate-200">
              <Pagination
                currentPage={currentPage}
                totalItems={totalItems}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={(newSize) => {
                  setPageSize(newSize);
                  setCurrentPage(1);
                }}
              />
            </div>
          </>
        )}
      </div>

      {/* Invoice Editor Modal */}
      {isEditorOpen && (
        <InvoiceEditorModal
          isOpen={isEditorOpen}
          onClose={() => {
            setIsEditorOpen(false);
            setEditingInvoice(null);
          }}
          invoiceToEdit={editingInvoice}
          onSaved={() => {
            loadInvoices();
          }}
        />
      )}

      {/* Payment Modal */}
      {isPaymentOpen && payingInvoice && (
        <PaymentModal
          isOpen={isPaymentOpen}
          onClose={() => {
            setIsPaymentOpen(false);
            setPayingInvoice(null);
          }}
          invoice={payingInvoice}
          onPaymentSuccess={() => {
            loadInvoices();
          }}
        />
      )}

      {/* Print Preview Modal */}
      {isPrintOpen && printingInvoice && (
        <PrintPreviewModal
          isOpen={isPrintOpen}
          onClose={() => {
            setIsPrintOpen(false);
            setPrintingInvoice(null);
          }}
          title={`Invoice ${printingInvoice.invoiceNumber}`}
          onGeneratePdf={() => generateInvoicePDF(printingInvoice, settings)}
        >
          <InvoicePrint invoice={printingInvoice} settings={settings} />
        </PrintPreviewModal>
      )}

      {/* Cancel Confirmation */}
      <ConfirmDialog
        isOpen={isCancelOpen}
        title="Cancel Invoice"
        message={`Are you sure you want to cancel invoice #${invoiceToCancel?.invoiceNumber}? It will be marked as Cancelled and dues will be zeroed.`}
        confirmLabel="Yes, Cancel Invoice"
        variant="warning"
        onConfirm={handleCancelInvoice}
        onCancel={() => {
          setIsCancelOpen(false);
          setInvoiceToCancel(null);
        }}
      />

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={isDeleteOpen}
        title="Delete Invoice"
        message={`Are you sure you want to permanently delete invoice #${invoiceToDelete?.invoiceNumber} and all its payment records? This action cannot be undone.`}
        confirmLabel="Delete Invoice"
        variant="danger"
        onConfirm={handleDeleteInvoice}
        onCancel={() => {
          setIsDeleteOpen(false);
          setInvoiceToDelete(null);
        }}
      />
    </div>
  );
};
