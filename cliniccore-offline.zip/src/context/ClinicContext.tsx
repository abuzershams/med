import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { db } from '../db/database';
import type { ClinicSettings } from '../types';

interface ClinicContextValue {
  settings: ClinicSettings | null;
  loading: boolean;
  reloadSettings: () => Promise<void>;
  formatCurrency: (amount: number | undefined | null) => string;
  formatDate: (dateStr: string | undefined | null) => string;
  formatDateTime: (isoStr: string | undefined | null) => string;
}

const ClinicContext = createContext<ClinicContextValue | undefined>(undefined);

export const ClinicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<ClinicSettings | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const reloadSettings = useCallback(async () => {
    try {
      const s = await db.clinic_settings.toCollection().first();
      setSettings(s || null);
    } catch {
      setSettings(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    reloadSettings();
  }, [reloadSettings]);

  const formatCurrency = useCallback(
    (amount: number | undefined | null) => {
      const val = typeof amount === 'number' && !isNaN(amount) ? amount : 0;
      const symbol = settings?.currencySymbol || '₹';
      return `${symbol}${val.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    },
    [settings?.currencySymbol]
  );

  const formatDate = useCallback((dateStr: string | undefined | null) => {
    if (!dateStr) return '-';
    // Expecting YYYY-MM-DD or ISO string
    try {
      const parts = dateStr.split('T')[0].split('-');
      if (parts.length === 3) {
        const [year, month, day] = parts;
        return `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${year}`;
      }
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return dateStr;
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const year = d.getFullYear();
      return `${day}/${month}/${year}`;
    } catch {
      return dateStr;
    }
  }, []);

  const formatDateTime = useCallback((isoStr: string | undefined | null) => {
    if (!isoStr) return '-';
    try {
      const d = new Date(isoStr);
      if (isNaN(d.getTime())) return isoStr;
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const year = d.getFullYear();
      let hours = d.getHours();
      const minutes = String(d.getMinutes()).padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12 || 12;
      return `${day}/${month}/${year} ${hours}:${minutes} ${ampm}`;
    } catch {
      return isoStr;
    }
  }, []);

  return (
    <ClinicContext.Provider
      value={{
        settings,
        loading,
        reloadSettings,
        formatCurrency,
        formatDate,
        formatDateTime,
      }}
    >
      {children}
    </ClinicContext.Provider>
  );
};

export function useClinic(): ClinicContextValue {
  const context = useContext(ClinicContext);
  if (!context) {
    throw new Error('useClinic must be used within a ClinicProvider');
  }
  return context;
}
