import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { db } from '../db/database';
import type { User, UserRole } from '../types';
import { hasAdminAccount, loginUser, hasPermission } from '../services/authService';
import { logActivity } from '../services/auditService';
import { useToast } from './ToastContext';
import { useClinic } from './ClinicContext';

interface AuthContextValue {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  hasAdmin: boolean;
  login: (username: string, password: string) => Promise<User>;
  setSessionUser: (user: User) => void;
  logout: () => Promise<void>;
  checkAdminStatus: () => Promise<boolean>;
  checkPermission: (module: Parameters<typeof hasPermission>[1]) => boolean;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [hasAdmin, setHasAdmin] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(true);
  const { warning } = useToast();
  const { settings } = useClinic();
  const lastActivityRef = useRef<number>(Date.now());

  const checkAdminStatus = useCallback(async () => {
    try {
      const exists = await hasAdminAccount();
      setHasAdmin(exists);
      return exists;
    } catch {
      setHasAdmin(false);
      return false;
    }
  }, []);

  // Initialize session
  useEffect(() => {
    async function init() {
      setLoading(true);
      const adminExists = await checkAdminStatus();

      // Check stored session
      const storedUserId = sessionStorage.getItem('clinic_current_user_id');
      if (storedUserId && adminExists) {
        try {
          const u = await db.users.get(Number(storedUserId));
          if (u && (u.active === true || (u as any).status === 'active')) {
            setUser(u);
          } else {
            sessionStorage.removeItem('clinic_current_user_id');
          }
        } catch {
          sessionStorage.removeItem('clinic_current_user_id');
        }
      }
      setLoading(false);
    }
    init();
  }, [checkAdminStatus]);

  const setSessionUser = useCallback((u: User) => {
    setUser(u);
    setHasAdmin(true);
    if (u.id) {
      sessionStorage.setItem('clinic_current_user_id', String(u.id));
    }
    lastActivityRef.current = Date.now();
  }, []);

  const login = useCallback(async (username: string, password: string) => {
    const loggedUser = await loginUser(username, password);
    setUser(loggedUser);
    setHasAdmin(true);
    sessionStorage.setItem('clinic_current_user_id', String(loggedUser.id));
    lastActivityRef.current = Date.now();
    return loggedUser;
  }, []);

  const logout = useCallback(async () => {
    if (user) {
      await logActivity(user.username, user.role, 'User Logout', 'Auth', 'Manual user logout');
    }
    setUser(null);
    sessionStorage.removeItem('clinic_current_user_id');
  }, [user]);

  const refreshUser = useCallback(async () => {
    if (user?.id) {
      const updated = await db.users.get(user.id);
      if (updated) {
        setUser(updated);
      }
    }
  }, [user?.id]);

  const checkPermission = useCallback(
    (module: Parameters<typeof hasPermission>[1]) => {
      if (!user) return false;
      return hasPermission(user.role, module);
    },
    [user]
  );

  // Idle timeout detector
  useEffect(() => {
    if (!user) return;

    const timeoutMinutes = settings?.idleTimeoutMinutes || 30;
    const timeoutMs = timeoutMinutes * 60 * 1000;

    const updateActivity = () => {
      lastActivityRef.current = Date.now();
    };

    window.addEventListener('mousemove', updateActivity, { passive: true });
    window.addEventListener('mousedown', updateActivity, { passive: true });
    window.addEventListener('keydown', updateActivity, { passive: true });
    window.addEventListener('touchstart', updateActivity, { passive: true });
    window.addEventListener('scroll', updateActivity, { passive: true });

    const interval = setInterval(() => {
      const idleTime = Date.now() - lastActivityRef.current;
      if (idleTime >= timeoutMs) {
        warning(`Session expired due to ${timeoutMinutes} minutes of inactivity.`, 'Auto Logged Out');
        logout();
      }
    }, 15000); // Check every 15s

    return () => {
      window.removeEventListener('mousemove', updateActivity);
      window.removeEventListener('mousedown', updateActivity);
      window.removeEventListener('keydown', updateActivity);
      window.removeEventListener('touchstart', updateActivity);
      window.removeEventListener('scroll', updateActivity);
      clearInterval(interval);
    };
  }, [user, settings?.idleTimeoutMinutes, logout, warning]);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: Boolean(user),
        loading,
        hasAdmin,
        login,
        setSessionUser,
        logout,
        checkAdminStatus,
        checkPermission,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
